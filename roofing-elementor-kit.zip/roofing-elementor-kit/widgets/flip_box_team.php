<?php

use Elementor\Controls_Manager;

class Flip_Box_Team extends \Elementor\Widget_Base {

    public function get_name() {
        return 'flip-box-team';
    }

    public function get_title() {
        return __('Flip Box Team', 'roofing-elementor-kit');
    }

    public function get_icon() {
        return 'eicon-flip-box';
    }

    protected function register_controls() {
        $this->start_controls_section(
            'layout_section',
            [
                'label' => __('Layout', 'roofing-elementor-kit'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'layout_title',
            [
                'label' => __('Section Title', 'roofing-elementor-kit'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'label_block' => true,
                'default' => esc_html__('We have an expert team at fixing your roofs.', 'roofing-elementor-kit'),
            ]
        );

        $this->add_control(
            'layout_subtitle',
            [
                'label' => __('Section Subtitle', 'roofing-elementor-kit'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'label_block' => true,
                'default' => esc_html__('Our Roof Experts Team', 'roofing-elementor-kit'),
            ]
        );
        
        $this->end_controls_section();

        $this->start_controls_section(
            'front_content_section',
            [
                'label' => __('Front', 'roofing-elementor-kit'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'member_image',
            [
                'label' => esc_html__('Team Member Image', 'roofing-elementor-kit'),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $repeater->add_control(
            'member_name',
            [
                'label' => esc_html__('Name', 'roofing-elementor-kit'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Robert Downey', 'roofing-elementor-kit'),
                'placeholder' => esc_html__('Type the team member name here', 'roofing-elementor-kit'),
            ]
        );

        $repeater->add_control(
            'member_designation',
            [
                'label' => esc_html__('Designation', 'roofing-elementor-kit'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('CEO and Founder', 'roofing-elementor-kit'),
                'placeholder' => esc_html__('Type the team member designation here', 'roofing-elementor-kit'),
            ]
        );

        $repeater->add_control(
            'Fb',
            [
                'label' => esc_html__('Facebook', 'roofing-elementor-kit'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Fb', 'roofing-elementor-kit'),
                'placeholder' => esc_html__('Type the Social text here', 'roofing-elementor-kit'),
            ]
        );

        $repeater->add_control(
			'fb_link',
			[
				'label' => esc_html__( 'Fb Link', 'roofing-elementor-kit' ),
				'type' => \Elementor\Controls_Manager::URL,
				'options' => [ 'url', 'is_external', 'nofollow' ],
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
					
				],
				'label_block' => true,
			]
		);
        $repeater->add_control(
            'twiter',
            [
                'label' => esc_html__('Twiter', 'roofing-elementor-kit'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('X', 'roofing-elementor-kit'),
                'placeholder' => esc_html__('Type the Social text here', 'roofing-elementor-kit'),
            ]
        );

        $repeater->add_control(
			'twitter_link',
			[
				'label' => esc_html__( 'Twitter Link', 'roofing-elementor-kit' ),
				'type' => \Elementor\Controls_Manager::URL,
				'options' => [ 'url', 'is_external', 'nofollow' ],
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
					
				],
				'label_block' => true,
			]
		);
        $repeater->add_control(
            'linkdin',
            [
                'label' => esc_html__('Linkdin', 'roofing-elementor-kit'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('LIN', 'roofing-elementor-kit'),
                'placeholder' => esc_html__('Type the Social text here', 'roofing-elementor-kit'),
            ]
        );

        $repeater->add_control(
			'linkdin_link',
			[
				'label' => esc_html__( 'Linkdin Link', 'roofing-elementor-kit' ),
				'type' => \Elementor\Controls_Manager::URL,
				'options' => [ 'url', 'is_external', 'nofollow' ],
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
					
				],
				'label_block' => true,
			]
		);
        $repeater->add_control(
            'instagram',
            [
                'label' => esc_html__('Instagram', 'roofing-elementor-kit'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('IG', 'roofing-elementor-kit'),
                'placeholder' => esc_html__('Type the Social text here', 'roofing-elementor-kit'),
            ]
        );

        $repeater->add_control(
			'instagram_link',
			[
				'label' => esc_html__( 'Instagram Link', 'roofing-elementor-kit' ),
				'type' => \Elementor\Controls_Manager::URL,
				'options' => [ 'url', 'is_external', 'nofollow' ],
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
					
				],
				'label_block' => true,
			]
		);

        $this->add_control(
            'flipbox_members',
            [
                'label' => __('Team Members', 'roofing-elementor-kit'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'member_name' => __('Robert Downey', 'roofing-elementor-kit'),
                        'member_designation' => __('CEO and Founder', 'roofing-elementor-kit'),
                    ],
                ],
                'title_field' => '{{{ member_name }}}',
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
     $settings = $this->get_settings_for_display();
        ?>
        <?php if(!empty($settings)){ ?>
        <div class="elementor-element elementor-element-1e4995a sr_home_flipbox_sec sr_team_sec e-flex e-con-boxed e-con e-parent e-lazyloaded"data-id="1e4995a" data-element_type="container"data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                <div class="e-con-inner">
                    <div class="elementor-element elementor-element-38bb3b6 e-con-full e-flex e-con e-child team-inner-sec" data-id="38bb3b6"
                        data-element_type="container">
                        <div class="elementor-element elementor-element-7e41ab4 sr-team-heading e-con-full e-flex e-con e-child" data-id="7e41ab4"
                            data-element_type="container">
                            <div class="elementor-element elementor-element-3f17deb elementor-widget elementor-widget-heading"
                                data-id="3f17deb" data-element_type="widget" data-widget_type="heading.default">
                                <div class="elementor-widget-container">
                                    <h4 class="elementor-heading-title elementor-size-default"><?php echo $settings['layout_subtitle']; ?></h4>
                                </div>
                            </div>
                            <div class="elementor-element elementor-element-0521414 elementor-widget__width-initial elementor-widget elementor-widget-heading"
                                data-id="0521414" data-element_type="widget" data-widget_type="heading.default">
                                <div class="elementor-widget-container">
                                    <h2 class="elementor-heading-title elementor-size-default"><?php echo $settings['layout_title']; ?></h2>
                                </div>
                            </div>
                        </div>
                        <div class="sr-team-slider-wraper">
                            <div class="sr-team-slider">
                            <?php  foreach ($settings['flipbox_members'] as $flipbox_member){ ?>
                            
                                <div class="elementor-element elementor-element-47fc11b e-con-full sr_flipbox_row e-flex e-con e-child"
                                    data-id="47fc11b" data-element_type="container">
                                    <div class="elementor-element elementor-element-b4d8092 elementor-flip-box--effect-slide elementor-flip-box--direction-up elementor-widget elementor-widget-flip-box"
                                        data-id="b4d8092" data-element_type="widget" data-widget_type="flip-box.default">
                                        <div class="elementor-widget-container">
                                            <link rel="stylesheet"
                                                href="https://wordpress-887291-4463701.cloudwaysapps.com/wp-content/uploads/elementor/css/custom-pro-widget-flip-box.min.css?ver=1719926317">
                                            <div class="elementor-flip-box" tabindex="0">
                                                <div class="elementor-flip-box__layer elementor-flip-box__front">
                                                    <div class="elementor-flip-box__layer__overlay">
                                                        <div class="elementor-flip-box__layer__inner">
                                                            <div class="elementor-flip-box__image">
                                                                <img decoding="async" width="390" height="433"
                                                                    src="<?php echo $flipbox_member['member_image']['url']; ?>"
                                                                    class="attachment-full size-full wp-image-697" alt=""
                                                                    srcset="<?php echo $flipbox_member['member_image']['url']; ?> 390w, <?php echo $flipbox_member['member_image']['url']; ?> 270w"
                                                                    sizes="(max-width: 390px) 100vw, 390px">
                                                            </div>
                                                            <div class="sr_team_name_designation">
                                                                <h3 class="elementor-flip-box__layer__title"><?php echo esc_html($flipbox_member['member_name']); ?></h3>
                                                                <h4 class="elementor-flip-box__layer__designation"><?php echo esc_html($flipbox_member['member_designation']); ?></h4>
                                                           </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="elementor-flip-box__layer elementor-flip-box__back">
                                                    <div class="elementor-flip-box__layer__overlay">
                                                        <div class="elementor-flip-box__layer__inner">
                                                            <h3 class="elementor-flip-box__layer__title"><?php echo esc_html($flipbox_member['member_name']); ?></h3>

                                                            <div class="elementor-flip-box__layer__description"><?php echo esc_html($flipbox_member['member_designation']); ?></div>
                                                            <div class="sr-social-wrapper">
                                                                <div class="sr-social-fb">
                                                                <a href="<?php echo $flipbox_member['fb_link']['url']; ?>" target="<?php echo $flipbox_member['fb_link']['is_external'] ? '_blank' : '_self'; ?>"  class="elementor-flip-box__button elementor-button elementor-size-sm"><?php echo $flipbox_member['Fb']; ?></a>
                                                                </div>
                                                                <div class="sr-social-twitter">
                                                                    <a href="<?php echo $flipbox_member['twitter_link']['url']; ?>" target="<?php echo $flipbox_member['twitter_link']['is_external'] ? '_blank' : '_self'; ?>" class="elementor-flip-box__button elementor-button elementor-size-sm"><?php echo $flipbox_member['twiter']; ?></a>
                                                                </div>
                                                                <div class="sr-social-linkdin">
                                                                    <a href="<?php echo $flipbox_member['linkdin_link']['url']; ?>" target="<?php echo $flipbox_member['linkdin_link']['is_external'] ? '_blank' : '_self'; ?>" class="elementor-flip-box__button elementor-button elementor-size-sm"><?php echo $flipbox_member['linkdin']; ?></a>
                                                                </div>
                                                                <div class="sr-social-ig">
                                                                    <a href="<?php echo $flipbox_member['instagram_link']['url']; ?>" target="<?php echo $flipbox_member['instagram_link']['is_external'] ? '_blank' : '_self'; ?>" class="elementor-flip-box__button elementor-button elementor-size-sm"><?php echo $flipbox_member['instagram']; ?></a>
                                                                </div>
                                                                
                                                           </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                        
                            <?php } ?>
                            </div>
                        </div>
                    </div>
                </div>
        </div> 
        <?php } ?>
        <?php
        
    }
}