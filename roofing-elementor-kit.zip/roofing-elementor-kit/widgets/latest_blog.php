<?php
use Elementor\Controls_Manager;

class latest_blog extends \Elementor\Widget_Base {

    public function get_name() {
        return 'Latest Blog';
    }

    public function get_title() {
        return __('Latest Blog', 'roofing-elementor-kit');
    }

    public function get_icon() {
        return 'eicon-posts-grid';
    }

    protected function _register_controls() {

        $this->start_controls_section(
            'section',
            [
                'label' => __('Layout', 'roofing-elementor-kit'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'section_title',
            [
                'label' => __('Section Title', 'roofing-elementor-kit'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'label_block' => true,
                'default' => esc_html__('Stay updated with Superior Roofing News & Blogs', 'roofing-elementor-kit'),
            ]
        );

        $this->add_control(
            'section_subtitle',
            [
                'label' => __('Section SubTitle', 'roofing-elementor-kit'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'label_block' => true,
                'default' => esc_html__('Our News and blogs', 'roofing-elementor-kit'),
            ]
        );

        $this->add_control(
            'button_text',
            [
                'label' => esc_html__( 'Button Text', 'roofing-elementor-kit' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__( 'explore all blogs', 'roofing-elementor-kit' ),
                'placeholder' => esc_html__( 'Type your Button text here', 'roofing-elementor-kit' ),
            ]
        );

        $this->add_control(
            'button_link',
            [
                'label' => esc_html__( 'Button Url', 'roofing-elementor-kit' ),
                'type' => \Elementor\Controls_Manager::URL,
                'options' => [ 'url', 'is_external', 'nofollow' ],
                'default' => [
                    'url' => '',
                    'is_external' => true,
                    'nofollow' => true,
                ],
                'label_block' => true,
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'content_section',
            [
                'label' => __('Query', 'roofing-elementor-kit'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'post',
            [
                'label' => __('All Blogs', 'roofing-elementor-kit'),
                'type' => Controls_Manager::SELECT2,
                'multiple' => true,
                'options' => $this->titles(),
            ]
        );

        $this->add_control(
            'order',
            [
                'label' => __('Order', 'roofing-elementor-kit'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'asc' => __('Ascending', 'roofing-elementor-kit'),
                    'desc' => __('Descending', 'roofing-elementor-kit'),
                ],
                'default' => 'desc',
            ]
        );

        $this->add_control(
            'orderby',
            [
                'label' => esc_html__('Order by', 'roofing-elementor-kit'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'post_date' => esc_html__('Date', 'roofing-elementor-kit'),
                    'post_title' => esc_html__('Title', 'roofing-elementor-kit'),
                    'menu_order' => esc_html__('Menu Order', 'roofing-elementor-kit'),
                    'modified' => esc_html__('Last Modified', 'roofing-elementor-kit'),
                    'comment_count' => esc_html__('Comment Count', 'roofing-elementor-kit'),
                    'rand' => esc_html__('Random', 'roofing-elementor-kit'),
                ],
                'default' => 'post_date',
            ]
        );

        $this->add_control(
            'posts_per_page',
            [
                'label' => esc_html__('Posts Per Page', 'roofing-elementor-kit'),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 100,
                'step' => 1,
                'default' => 5,
            ]
        );

        $this->end_controls_section();
    }

    protected function titles() {
        $options = [];
        $args = [
            'post_type' => 'post',
            'posts_per_page' => -1, 
            'post_status' => 'publish',
        ];
        $posts = get_posts($args);

        foreach ($posts as $post) {
            $options[$post->ID] = $post->post_title;
        }
        return $options;
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $post_ids = $settings['post'];
        $order = $settings['order'];
        $orderby = $settings['orderby'];
        $posts_per_page = $settings['posts_per_page'];

        $args = [
            'post_type' => 'post',
            'post__in' => $post_ids,
            'orderby' => $orderby,
            'order' => $order,
            'posts_per_page' => $posts_per_page,
        ];
        $query = new \WP_Query($args);
        ?>
        <script src="https://unpkg.com/swiper/swiper-bundle.js"></script>
        <div class="sr_news_blogs">
            <div class="news_blogs_title_btn_sec">
                <div class="blog_title_sec">
                    <h5 class="blog_small_heading"><?php echo esc_html($settings['section_subtitle']); ?></h5>
                    <h2 class="blog_large_heading"><?php echo esc_html($settings['section_title']); ?></h2>
                </div>
                <div class="all_blogs_btn">
                    <a href="<?php echo esc_url($settings['button_link']['url']); ?>" class="sr_custom_btn" <?php echo $settings['button_link']['is_external'] ? 'target="_blank"' : ''; ?> <?php echo $settings['button_link']['nofollow'] ? 'rel="nofollow"' : ''; ?>>
                        <?php echo esc_html($settings['button_text']); ?>
                        <span><img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/button_dots.svg" alt="button_dots"></span>
                    </a>
                </div>
            </div>

            <div class="blog_inner_section">
                <div class="browse-arrow">
                    <div class="swiper-button-prev thumbs-prev left-arrow-blog">
                        <img decoding="async" src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/arrow-left.svg" alt="left-arrow-">
                    </div>
                    <div class="swiper-button-next thumbs-next right-arrow-blog">
                        <img decoding="async" src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/arrow-right.svg" alt="right-arrow">
                    </div>
                </div>
        
                <div class="blog_grid_box swiper-wrapper">
                    <?php if ($query->have_posts()) : ?>
                        <?php while ($query->have_posts()) : $query->the_post(); ?>
                          <?php $thumb = get_the_post_thumbnail_url($query->ID); ?>
                            <div class="single_blog swiper-slide" style="background-image: url('<?php echo $thumb ?>')">
                                <div class="date_year">
                                    <span class="date_month"><?php echo get_the_date('d M,'); ?></span>
                                    <span class="year"><?php echo get_the_date('Y'); ?></span>
                                </div>
                                <div class="blog_bottom_info">
                                <div class="roffing_category_tag">
                                      <?php
                                        $categories = get_the_category();
                                        foreach ($categories as $category) { ?>
                                    <div class="roffing_post_category">
                                        
                                            <a href="<?php echo esc_url(get_category_link($category->term_id)); ?>"><span class="category"><?php echo esc_html($category->name); ?></span></a>
                                        
                                    </div>
                               <?php }?>
                                       <?php $tags = get_the_tags();
                                        foreach ($tags as $tag) { ?>
                                        <div class="category_tag">
                                            <a href="<?php echo esc_url(get_category_link($tag->term_id)); ?>"><span class="category"><?php echo esc_html($tag->name); ?></span></a>';
                                       </div>
                                <?php } ?>
                                </div>
                                    <div class="blog_title_sec">
                                        <a href="<?php the_permalink(); ?>">
                                            <h3 class="blog_title"><?php the_title(); ?></h3>
                                        </a>
                                    </div>
                                </div>
                                <a href="<?php the_permalink(); ?>" class="blog_cta_box">
                                    <div class="blog_cta">
                                        <img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/blog_cta_arrow.svg" alt="blog_cta_btn_icon">
                                    </div>
                                </a>
                            </div>
                        <?php endwhile; ?>
                        <?php wp_reset_postdata(); ?>
                    <?php else : ?>
                        <p><?php esc_html_e('No posts found', 'roofing-elementor-kit'); ?></p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php
            }
}
?>
