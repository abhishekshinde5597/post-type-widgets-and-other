<?php

use Elementor\Controls_Manager;

class timeline_slider extends \Elementor\Widget_Base {

    public function get_name() {
        return 'Timeline-slider';
    }

    public function get_title() {
        return __('Timeline-slider', 'roofing-elementor-kit');
    }

    public function get_icon() {
        return 'eicon-flip-box';
    }

    protected function register_controls() {
        $this->start_controls_section(
            'content_section',
            [
                'label' => __('Timeline Section', 'roofing-elementor-kit'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'timeline_title',
            [
                'label' => __(' Title', 'roofing-elementor-kit'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'label_block' => true,
                'default' => esc_html__('Our Beginning', 'roofing-elementor-kit'),
            ]
        );

        $repeater->add_control(
            'timeline_subtitle',
            [
                'label' => __('Description', 'roofing-elementor-kit'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'label_block' => true,
                'default' => esc_html__('Lorem Ipsum is simply', 'roofing-elementor-kit'),
            ]
        );

        $repeater->add_control(
			'due_date',
			[
				'label' => esc_html__( 'Due Date', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::DATE_TIME,
			]
		);


        $this->add_control(
            'timeline',
            [
                'label' => __('Testimonials', 'roofing-elementor-kit'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'timeline_title' => __('Our Beginning', 'roofing-elementor-kit'),
                        'timeline_subtitle' => __('Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum is simply dummy text of the printing.', 'roofing-elementor-kit'),
                    ],
                ],
                'title_field' => '{{{ timeline_title }}}',
            ]
        );

        $this->end_controls_section();
    }


    protected function render() {
        $settings = $this->get_settings_for_display();
        ?>
        <div class="sr_timeline_slider_sec">
            <div class="sr_timeline_slider_inner swiper-wrapper">
                <?php foreach ( $settings['timeline'] as $item ) : ?>
                    <div class="sr_single_timeline_slide swiper-slide">
                        <div class="sr_timeline_content">
                            <div class="sr_timeline_date">
                                <?php 
                                $due_date = !empty( $item['due_date'] ) ? $item['due_date'] : '';
                                $formatted_date = '';
    
                                if ( $due_date ) {
                                    $date = new \DateTime($due_date);
                                    $formatted_date = $date->format('F j, Y');
                                }
                                ?>
                                <h3 class="timeline_date"><?php echo esc_html( $formatted_date ); ?></h3>
                            </div>
                            <div class="timeline_content_area">
                                <div class="sr_timeline_title_text">
                                    <h3 class="timeline_title"><?php echo esc_html( $item['timeline_title'] ); ?></h3>
                                </div>
                                <div class="sr_timeline_text">
                                    <p class="timeline_text"><?php echo esc_html( $item['timeline_subtitle'] ); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
            <div class="slider__controls">
                <div class="slider__pagination"></div>
                <div class="slider__button-next"></div>
                <div class="slider__button-prev"></div>
            </div>
        </div>
        <?php
    }
    
    
}