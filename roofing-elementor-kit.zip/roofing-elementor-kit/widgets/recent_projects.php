<?php
use Elementor\Controls_Manager;

class recent_projects extends \Elementor\Widget_Base {

    public function get_name() {
        return 'Recent Projects';
    }

    public function get_title() {
        return __('Recent Projects', 'roofing-elementor-kit');
    }

    public function get_icon() {
        return 'eicon-posts-grid';
    }

    protected function _register_controls() {
        $this->start_controls_section(
            'section_content',
            [
                'label' => __('Layout', 'roofing-elementor-kit'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'section_title',
            [
                'label' => esc_html__('Section Title', 'roofing-elementor-kit'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Check our recently best roofing projects', 'roofing-elementor-kit'),
                'placeholder' => esc_html__('Type your Section Title here', 'roofing-elementor-kit'),
            ]
        );

        $this->add_control(
            'section_subtitle',
            [
                'label' => esc_html__('Section SubTitle', 'roofing-elementor-kit'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Recent Projects', 'roofing-elementor-kit'),
                'placeholder' => esc_html__('Type your Section SubTitle here', 'roofing-elementor-kit'),
            ]
        );
        
        $this->add_control(
			'project_button_text',
			[
				'label' => esc_html__( 'Button Text', 'roofing-elementor-kit' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'View All', 'textdomain' ),
				'placeholder' => esc_html__( 'Type your title here', 'textdomain' ),
			]
		);

        $this->add_control(
			'project_button_link',
			[
				'label' => esc_html__( 'Link', 'roofing-elementor-kit' ),
				'type' => \Elementor\Controls_Manager::URL,
				'options' => [ 'url', 'is_external', 'nofollow' ],
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
					
				],
				'label_block' => true,
			]
		);

        $this->end_controls_section();

        $this->start_controls_section(
            'content_section',
            [
                'label' => __('Query', 'roofing-elementor-kit'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );


        $this->add_control(
            'post',
            [
                'label' => __('All Projects', 'roofing-elementor-kit'),
                'type' => Controls_Manager::SELECT2,
                'multiple' => true,
                'options' => $this->titles(),
            ]
        );

        $this->add_control(
            'order',
            [
                'label' => __('Order', 'roofing-elementor-kit'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'asc' => __('Ascending', 'roofing-elementor-kit'),
                    'desc' => __('Descending', 'roofing-elementor-kit'),
                ],
                'default' => 'asc',
            ]
        );

        $this->add_control(
            'orderby',
            [
                'label' => esc_html__('Order by', 'roofing-elementor-kit'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'post_date' => esc_html__('Date', 'roofing-elementor-kit'),
                    'post_title' => esc_html__('Title', 'roofing-elementor-kit'),
                    'menu_order' => esc_html__('Menu Order', 'roofing-elementor-kit'),
                    'modified' => esc_html__('Last Modified', 'roofing-elementor-kit'),
                    'comment_count' => esc_html__('Comment Count', 'roofing-elementor-kit'),
                    'rand' => esc_html__('Random', 'roofing-elementor-kit'),
                ],
                'default' => 'post_title', // Default selected option
            ]
        );

        $this->add_control(
            'post_per_page',
            [
                'label' => esc_html__('Post Per Page', 'roofing-elementor-kit'),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 100,
                'step' => 1,
                'default' => 5,
            ]
        );

        $this->end_controls_section();
        $this->start_controls_section(
			'style_section',
			[
				'label' => esc_html__( 'Style Section', 'roofing-elementor-kit' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'content_typography',
				'selector' => '{{WRAPPER}} .button-text',
			]
		);



        $this->add_responsive_control(
            'title_padding',
            [
                'label' => esc_html__( 'Padding', 'roofing-elementor-kit' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                
                'devices' => [ 'desktop', 'tablet', 'mobile' ,'laptop','tablet_landscape','mobile_landscape'],
                'default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px', // Default unit
                ],
                'tablet_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px', // Default unit for tablet
                ],
                'mobile_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px', // Default unit for mobile
                ],
                'laptop_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px',
                ],
                'tablet_landscape_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px',
                ],
                'mobile_landscape_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px',
                ],
                
                'selectors' => [
                    '{{WRAPPER}} .sr_circle-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'content_align',
            [
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'label' => esc_html__( 'Alignment', 'roofing-elementor-kit' ),
                'options' => [
                    'left' => [
                        'title' => esc_html__( 'Left', 'roofing-elementor-kit' ),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__( 'Center', 'roofing-elementor-kit' ),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__( 'Right', 'roofing-elementor-kit' ),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile', 'laptop', 'tablet_landscape', 'mobile_landscape' ],
                'prefix_class' => 'content-align-%s',
            ]
        );
        

        $this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'border',
				'selector' => '{{WRAPPER}} .sr_circle-button::before',
			]
		);

        $this->add_control(
            'border_color',
            [
                'label' => esc_html__( 'Button Border Color', 'roofing-elementor-kit' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .sr_circle-button::before' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'buttonbg_color',
            [
                'label' => esc_html__( 'Button Background Color', 'roofing-elementor-kit' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .sr_circle-button' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'button_text_color',
            [
                'label' => esc_html__( 'Button text Color', 'roofing-elementor-kit' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .sr_circle-button a ' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->end_controls_section();
        
    }

    protected function titles() {
        $options = [];
        $args = [
            'post_type' => 'projects',
            'posts_per_page' => -1, 
            'post_status' => 'publish',
        ];
        $posts = get_posts($args);

        foreach ($posts as $post) {
            $options[$post->ID] = $post->post_title;
        }
        return $options;
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $post_ids = $settings['post'];
        //print_r($post_ids);
        
        $args = [
            'post_type' => 'projects',
            'posts_per_page' => $settings['post_per_page'],
            'post__in' => $post_ids,
            'order' => $settings['order'],
            'orderby' => $settings['orderby'],
            'post_status' => 'publish'
        ];

        $query = new \WP_Query($args);
        
                if ($query->have_posts()) {
                ?>
                    <div class="sr_recent_project">
                        <div class="recent_project_inner">
                            <div class="project_title_sec">
                                <?php if($settings['section_subtitle']){ ?>
                                <h5 class="project_small_heading"><?php echo $settings['section_subtitle']; ?></h5>
                                <?php } ?>
                                <?php if($settings['section_title']){ ?>
                                <h2 class="project_large_heading"><?php echo $settings['section_title']; ?></h2>
                                <?php } ?>
                            </div>
                            <div class="recent_project_grid">
                                <?php 
                                while ($query->have_posts()) {
                                    $query->the_post(); 
                                    $category = get_the_terms(get_the_ID(), 'roofing');      
                                    ?>
                                    <div class="single_project">
                                        <?php if (has_post_thumbnail()) { ?>

                                            <div class="project_featured_image">
                                                <a href="<?php echo esc_url(get_permalink()); ?>">
                                                    <img src="<?php echo esc_url(get_the_post_thumbnail_url()); ?>" alt="<?php echo esc_attr(get_the_title()); ?>">
                                                </a>
                                            </div>

                                        <?php } else { ?> 

                                            <div class="project_featured_image">
                                                <a href="<?php echo esc_url(get_permalink()); ?>">
                                                    <img src="<?php echo site_url(); ?>/wp-content/uploads/2024/07/recent_project_1.png" alt="<?php echo esc_attr(get_the_title()); ?>">
                                                </a>
                                            </div>

                                        <?php } ?>

                                        <div class="project_info">
                                            <div class="project_category_title">
                                                <?php if (!empty($category)) { ?>

                                                    <div class="project_category_titlecategory">
                                                    <?php foreach ($category as $cat) {
                                                        $category_name = esc_html($cat->name);
                                                        ?>
                                                        <a href="<?php echo esc_url(get_category_link($cat->term_id)); ?>"><h5><?php echo $category_name; ?></h5></a>
                                                        <?php } ?>
                                                    </div>

                                                <?php } ?>

                                                 <a href="<?php echo esc_url(get_permalink()); ?>">
                                                    <div class="project_title">
                                                        <h4><?php echo esc_html(get_the_title()); ?></h4>
                                                    </div>
                                                </a>
                                            
                                            </div>
                                            <a href="<?php echo esc_url(get_permalink()); ?>" class="project_cta_link">
                                                <div class="project_cta">
                                                    <img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/project_cta_icon.svg" alt="project_cta_btn_icon">
                                                </div>
                                            </a>
                                        </div>

                                    </div>  
                                <?php
                                }
                                ?>
                            </div>   
                            <?php $content_align = $settings['content_align'];?>
                            <a href="<?php echo esc_url($settings['project_button_link']['url']); ?>" target="<?php echo esc_url($settings['project_button_link']['is_external']) ? '_blank' : '_self'; ?>"> 
                                <div class="sr_circle-button content-align-<?php echo esc_attr( $content_align ); ?>">
                                    <span class="button-text"><?php echo esc_html($settings['project_button_text']); ?></span>
                                    <img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/custom_circle_btn.svg" alt="Icon" class="button-icon">
                                </div>
                            </a>
                            <style>
                            .content-align-left {
                                text-align: left;
                                display: inline-block;
                            }

                            .content-align-center {
                                text-align: center;
                                display: block;
                                margin-left: auto;
                                margin-right: auto;
                            }

                            .content-align-right {
                                text-align: right;
                                display: inline-block;
                                float: right;
                            }
                            </style>

                        </div>
                    </div>
                <?php
            } else {
                ?><p>No recent projects found</p><?php
            }
        wp_reset_postdata();
    }
}
?>
