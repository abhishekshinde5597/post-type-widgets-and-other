<?php

use Elementor\Controls_Manager;

class client_testimonial extends \Elementor\Widget_Base {

    public function get_name() {
        return 'Client Testimonials';
    }

    public function get_title() {
        return __('Client Testimonials', 'roofing-elementor-kit');
    }

    public function get_icon() {
        return 'eicon-testimonial';
    }

    protected function register_controls() {
        $this->start_controls_section(
            'content_section',
            [
                'label' => __('Testimonials Section', 'roofing-elementor-kit'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'section_title',
            [
                'label' => __('Section Title', 'roofing-elementor-kit'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'label_block' => true,
                'default' => esc_html__('Few words from our client', 'roofing-elementor-kit'),
            ]
        );

        $repeater->add_control(
            'section_subtitle',
            [
                'label' => __('Section SubTitle', 'roofing-elementor-kit'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'label_block' => true,
                'default' => esc_html__('Clients Awesome Feedbacks', 'roofing-elementor-kit'),
            ]
        );
        
        $repeater->add_control(

            'section_subtitle',
            [
                'label' => __('Section SubTitle', 'roofing-elementor-kit'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'label_block' => true,
                'default' => esc_html__('Clients Awesome Feedbacks', 'roofing-elementor-kit'),
            ]
        );
        

        $repeater->add_control(
            'client_image',
            [
                'label' => esc_html__('Thumbnail Image', 'roofing-elementor-kit'),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $repeater->add_control(
            'profile_image',
            [
                'label' => esc_html__('Profile Image', 'roofing-elementor-kit'),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $repeater->add_control(
            'client_name',
            [
                'label' => esc_html__('Client Name', 'roofing-elementor-kit'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Alexa Christian', 'roofing-elementor-kit'),
                'placeholder' => esc_html__('Type your Client Name here', 'roofing-elementor-kit'),
            ]
        );

        $repeater->add_control(
            'city',
            [
                'label' => esc_html__('City', 'roofing-elementor-kit'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Chicago', 'roofing-elementor-kit'),
                'placeholder' => esc_html__('Type your Client City here', 'roofing-elementor-kit'),
            ]
        );

        $repeater->add_control(
            'review_tagline',
            [
                'label' => __('Review Tagline', 'roofing-elementor-kit'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'label_block' => true,
                'default' => esc_html__('Exceptional service from start to finish!', 'roofing-elementor-kit'),
            ]
        );

        $repeater->add_control(
            'review_description',
            [
                'label' => __('Review Description', 'roofing-elementor-kit'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'label_block' => true,
                'default' => esc_html__('Lorem Ipsum is simply dummy text', 'roofing-elementor-kit'),
                'placeholder' => esc_html__('Type your description here', 'roofing-elementor-kit'),
            ]
        );

        $repeater->add_control(
            'review_rating',
            [
                'label' => __('Rating', 'roofing-elementor-kit'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    '1' => '1 Star',
                    '2' => '2 Stars',
                    '3' => '3 Stars',
                    '4' => '4 Stars',
                    '5' => '5 Stars',
                ],
                'default' => '5',
            ]
        );

        $this->add_control(
            'testimonials',
            [
                'label' => __('Testimonials', 'roofing-elementor-kit'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'client_name' => __('Alexa Christian', 'roofing-elementor-kit'),
                        'review_description' => __('Lorem Ipsum is simply dummy text', 'roofing-elementor-kit'),
                    ],
                ],
                'title_field' => '{{{ client_name }}}',
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        ?>
            <?php if(!empty($settings['testimonials'])){ ?>

            <div class="sr_testimonial_slider">
                <div class="sr_testimonial_inner">
                    
                    <div class="testimonial-arrow">
                        <div class="swiper-button-next thumbs-next right-arrow-testimonial">
                            <img decoding="async" src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/arrow-right.svg" alt="right-arrow">
                        </div>
                        <div class="swiper-button-prev thumbs-prev left-arrow-testimonial">
                            <img decoding="async" src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/arrow-left.svg" alt="left-arrow-">
                        </div>
                    </div>

                    <div class="testimonial_slider swiper-wrapper">
                        <?php foreach($settings['testimonials'] as $sr_testimonials){?>
                            <div class="testimonial_single_slide swiper-slide">
                                <div class="testimonial_wrapper">
                                    <div class="client_image">
                                        <img src="<?php echo esc_url($sr_testimonials['client_image']['url']); ?>" alt="client_image">
                                    </div>
                                    <div class="testimonial_content_side">
                                        <div class="testimonial_content_area">
                                            <h5 class="feedback_block_title"><?php echo esc_html($sr_testimonials['section_subtitle']); ?></h5>
                                            <h2 class="client_words"><?php echo esc_html($sr_testimonials['section_title']); ?></h2>
                                        </div>
                                        <div class="feedback_content_box">
                                            <div class="testimonial_icon_rating_box">
                                                <img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/Quote.svg" alt="quote" class="quote_img">
                                               <?php if ( ! empty( $sr_testimonials['review_rating'] ) ) { ?>
                                               <span class='rating_img'>
                                                <?php
                                                for ($i = 1; $i <= 5; $i++) {
                                                    if ($i <= $sr_testimonials['review_rating']) {
                                                        echo "<span class='fa fa-star checked'></span>";
                                                    }
                                                }
                                                ?>
                                                </span>
                                                <?php } ?>
                                                <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
                                                    <style>
                                                        .checked {
                                                        color: #F0C325;
                                                    }
                                                </style>
                                                
                                            </div>
                                            <div class="feedback_text_block">
                                                <h4 class="feedback_title"><?php echo esc_html($sr_testimonials['review_tagline']); ?></h4>
                                                <p class="feeback_content"><?php echo esc_html($sr_testimonials['review_description']); ?></p>
                                            </div>
                                            <div class="client_detail_box">
                                                <div class="profile_img_box">
                                                    <img src="<?php echo esc_url($sr_testimonials['profile_image']['url']); ?>" alt="profile_img_box">
                                                </div>
                                                <div class="client_name_city">
                                                    <h3 class="clientname"><?php echo esc_html($sr_testimonials['client_name']); ?></h3>
                                                    <p class="client_city"><?php echo esc_html($sr_testimonials['city']); ?></p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>    
                                </div>
                            </div>
                        <?php } ?>
                    </div>

                </div>
            </div>
            
            <?php } ?>
        <?php
        
        
       
    }
}
?>
