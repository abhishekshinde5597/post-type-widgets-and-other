<?php
use Elementor\Controls_Manager;
class sr_button extends \Elementor\Widget_Base {
    
    public function get_name() {
        return 'Sr Button';
    }

    public function get_title() {
        return __('Sr Button', 'roofing-elementor-kit');
    }

    public function get_icon() {
        return 'eicon-dual-button';
    }

    protected function _register_controls() {
        $this->start_controls_section(
            'content_section',
            [
                'label' => __('Button', 'roofing-elementor-kit'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );  
        $this->add_control(
			'sr_button_text',
			[
				'label' => esc_html__( 'Button Text', 'roofing-elementor-kit' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'View all', 'roofing-elementor-kit' ),
				'placeholder' => esc_html__( 'Type your Button text here', 'roofing-elementor-kit' ),
			]
		);

        $this->add_control(
			'sr_button_link',
			[
				'label' => esc_html__( 'Button Link', 'roofing-elementor-kit' ),
				'type' => \Elementor\Controls_Manager::URL,
				'options' => [ 'url', 'is_external', 'nofollow' ],
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
					// 'custom_attributes' => '',
				],
				'label_block' => true,
			]
		);

       
        $this->end_controls_section();


        $this->start_controls_section(
			'style_section',
			[
				'label' => esc_html__( 'Style Section', 'roofing-elementor-kit' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'content_typography',
				'selector' => '{{WRAPPER}} .button-text',
			]
		);



        $this->add_responsive_control(
            'title_padding',
            [
                'label' => esc_html__( 'Padding', 'roofing-elementor-kit' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                
                'devices' => [ 'desktop', 'tablet', 'mobile' ,'laptop','tablet_landscape','mobile_landscape'],
                'default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px', // Default unit
                ],
                'tablet_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px', // Default unit for tablet
                ],
                'mobile_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px', // Default unit for mobile
                ],
                'laptop_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px',
                ],
                'tablet_landscape_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px',
                ],
                'mobile_landscape_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px',
                ],
                
                'selectors' => [
                    '{{WRAPPER}} .sr_circle-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'content_align',
            [
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'label' => esc_html__( 'Alignment', 'roofing-elementor-kit' ),
                'options' => [
                    'left' => [
                        'title' => esc_html__( 'Left', 'roofing-elementor-kit' ),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__( 'Center', 'roofing-elementor-kit' ),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__( 'Right', 'roofing-elementor-kit' ),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile', 'laptop', 'tablet_landscape', 'mobile_landscape' ],
                'prefix_class' => 'content-align-%s',
            ]
        );
        

        $this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'border',
				'selector' => '{{WRAPPER}} .sr_circle-button::before',
			]
		);

        $this->add_control(
            'border_color',
            [
                'label' => esc_html__( 'Button Border Color', 'roofing-elementor-kit' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .sr_circle-button::before' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'buttonbg_color',
            [
                'label' => esc_html__( 'Button Background Color', 'roofing-elementor-kit' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .sr_circle-button' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'button_text_color',
            [
                'label' => esc_html__( 'Button text Color', 'roofing-elementor-kit' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .sr_circle-button a ' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        ?>

        <?php if(!empty($settings)){ ?>
           <?php $content_align = $settings['content_align'];?>
            <a href="<?php echo esc_url($settings['sr_button_link']['url']); ?>" target="<?php echo esc_url($settings['sr_button_link']['is_external']) ? '_blank' : '_self'; ?>"> 
                <div class="sr_circle-button content-align-<?php echo esc_attr( $content_align ); ?>">
                    <span class="button-text"><?php echo esc_html($settings['sr_button_text']); ?></span>
                    <img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/custom_circle_btn.svg" alt="Icon" class="button-icon">
                </div>
            </a>
        <?php } ?>

        <?php
        
    }   
}
?>
    <style>
    .content-align-left {
        text-align: left;
        display: inline-block;
    }

    .content-align-center {
        text-align: center;
        display: block;
        margin-left: auto;
        margin-right: auto;
    }

    .content-align-right {
        text-align: right;
        display: inline-block;
        float: right;
    }
    </style>


   <?php






