<?php
use Elementor\Controls_Manager;

class blog_listing extends \Elementor\Widget_Base {

    public function get_name() {
        return 'Blogs';
    }

    public function get_title() {
        return __('Blogs', 'roofing-elementor-kit');
    }

    public function get_icon() {
        return 'eicon-archive-posts';
    }

    protected function _register_controls() {

        $this->start_controls_section(
            'content_section',
            [
                'label' => __('Query', 'roofing-elementor-kit'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

    
        $this->add_control(
            'order',
            [
                'label' => __('Order', 'roofing-elementor-kit'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'asc' => __('Ascending', 'roofing-elementor-kit'),
                    'desc' => __('Descending', 'roofing-elementor-kit'),
                ],
                'default' => 'desc',
            ]
        );

        $this->add_control(
            'orderby',
            [
                'label' => esc_html__('Order by', 'roofing-elementor-kit'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'post_date' => esc_html__('Date', 'roofing-elementor-kit'),
                    'post_title' => esc_html__('Title', 'roofing-elementor-kit'),
                    'menu_order' => esc_html__('Menu Order', 'roofing-elementor-kit'),
                    'modified' => esc_html__('Last Modified', 'roofing-elementor-kit'),
                    'comment_count' => esc_html__('Comment Count', 'roofing-elementor-kit'),
                    'rand' => esc_html__('Random', 'roofing-elementor-kit'),
                ],
                'default' => 'post_date',
            ]
        );

        $this->add_control(
            'posts_per_page',
            [
                'label' => esc_html__('Posts Per Page', 'roofing-elementor-kit'),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 100,
                'step' => 1,
                'default' => 5,
            ]
        );

        $this->end_controls_section();
    }


    protected function render() {
        $settings = $this->get_settings_for_display();
        $order = $settings['order'];
        $orderby = $settings['orderby'];
        $posts_per_page = $settings['posts_per_page'];
        $paged = isset($_POST['page']) ? intval($_POST['page']) : 1;
        //$category = get_query_var('category');
        $category = get_term( get_query_var('cat'), 'category' ); 
        $tag_id = get_query_var('tag');
        $search = $_GET['s'];
        if (is_category( $category )  ) {

            $args = [
                'post_type'      => 'post',
                'orderby'        => $orderby,
                'order'          => $order,
                'posts_per_page' => $posts_per_page,
                'paged'          => 1,
                'tax_query'      => [
                    [
                        'taxonomy' => 'category',
                        'field'    => 'slug',
                        'terms'    => $category,
                    ],
                ],
            ];

        } else if(is_search($search)){

            $args = [
                'post_type' => 'post',
                'orderby' => $orderby,
                'order' => $order,
                'posts_per_page' => $posts_per_page,
                'paged'          => $paged,
                's' => $search
            ];
    
            
        } else if(is_tag($tag_id)) {

        $args = [
            'post_type' => 'post',
            'orderby' => $orderby,
            'order' => $order,
            'posts_per_page' => $posts_per_page,
            'paged'          => $paged,
            'tax_query'      => [
                [
                    'taxonomy' => 'post_tag',
                    'field'    => 'slug',
                    'terms'    => $tag_id,
                ],
            ],
        ];

        
        } else {

            $args = [
                'post_type' => 'post',
                'orderby' => $orderby,
                'order' => $order,
                'posts_per_page' => $posts_per_page,
                'paged'          => $paged,
            ];

        }
    
        $blog_query = new \WP_Query($args);
        ?>
      <div class="loader" style="display: none;"></div>
       <div class="sr_news_blogs sr_blog_listing">
            <div class="blog_inner_section">
                <div class="blog_grid_box">
                    <?php if ($blog_query->have_posts()) : ?>
                    <?php while ($blog_query->have_posts()) : $blog_query->the_post(); ?>
                    <?php $thumb = get_the_post_thumbnail_url($blog_query->ID); ?>
                        <div class="single_blog"  style="background-image: url('<?php echo $thumb ?>')">
                            <img src="<?php echo get_stylesheet_directory_uri();?>/assets/images/blog_hover.svg" alt="Overlay Image" class="sr_overlay-image">
                            <div class="date_year">
                                <span class="date_month"><?php echo get_the_date('d M,'); ?></span>
                                <span class="year"><?php echo get_the_date('Y'); ?></span>
                            </div>
                            <div class="blog_bottom_info">
                                    <div class="roffing_category_tag">
                                           <?php
                                            $categories = get_the_category();
                                            foreach ($categories as $category) { ?>
                                            <div class="roffing_post_category">
                                            
                                              <a href="<?php echo esc_url(get_category_link($category->term_id)); ?>"><span class="category"><?php echo esc_html($category->name); ?></span></a>
                                           
                                        </div>
                                   <?php } ?>
                                   
                                      <?php  $tags = get_the_tags();
                                        foreach ($tags as $tag) { ?>
                                        <div class="category_tag">
                                                <a href="<?php echo esc_url(get_category_link($tag->term_id)); ?>"><span class="category"><?php echo  esc_html($tag->name); ?></span></a>
                                        </div>
                                        <?php } ?>
                                </div>
                                <div class="blog_title_sec">
                                    <a href="<?php the_permalink(); ?>">
                                        <h3 class="blog_title"><?php the_title(); ?></h3>
                                    </a>
                                </div>
                            </div>
                            <a href="<?php the_permalink(); ?>" class="blog_cta_box">
                                <div class="blog_cta">
                                    <img src="<?php echo get_stylesheet_directory_uri();?>/assets/images/blog_cta_arrow.svg" alt="blog_cta_btn_icon">
                                </div>
                            </a>
                        </div>
                        <?php endwhile; ?>
                        <?php wp_reset_postdata(); ?>
                    <?php else : ?>
                            <p><?php esc_html_e('No posts found', 'roofing-elementor-kit'); ?></p>
                    <?php endif; ?> 
                </div> 
                <span class="pagination-data" data-orderby="<?php echo esc_attr($orderby); ?>" data-order="<?php echo esc_attr($order); ?>" data-page="<?php echo esc_attr($posts_per_page); ?>"></span>
                <?php
                    $total_pages = $blog_query->max_num_pages;
                    if ($total_pages > 1) {
                        echo'<div class="blog-pagination">';
                                global $wp_query;
                                $big = 999999999; // need an unlikely integer
                                echo paginate_links( array(
                                'base'    => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
                            'current' => $paged,
                            'prev_text'    => __('Prev'),
                            'next_text'    => __('Next'),
                            'prev_next'   => TRUE,
                            'total'   => $blog_query->max_num_pages
                                ) );
                        echo'</div>';
                        }
                    ?>          
            </div>   
       </div>

        <?php
            }
}
?>
