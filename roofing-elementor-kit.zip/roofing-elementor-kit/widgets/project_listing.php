<?php
use Elementor\Controls_Manager;

class project_listing extends \Elementor\Widget_Base {

    public function get_name() {
        return 'Project';
    }

    public function get_title() {
        return __('projects', 'roofing-elementor-kit');
    }

    public function get_icon() {
        return 'eicon-archive-posts';
    }

    protected function _register_controls() {

        $this->start_controls_section(
            'content_section',
            [
                'label' => __('Query', 'roofing-elementor-kit'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

    
        $this->add_control(
            'projects_order',
            [
                'label' => __('Order', 'roofing-elementor-kit'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'asc' => __('Ascending', 'roofing-elementor-kit'),
                    'desc' => __('Descending', 'roofing-elementor-kit'),
                ],
                'default' => 'desc',
            ]
        );

        $this->add_control(
            'projects_orderby',
            [
                'label' => esc_html__('Order by', 'roofing-elementor-kit'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'post_date' => esc_html__('Date', 'roofing-elementor-kit'),
                    'post_title' => esc_html__('Title', 'roofing-elementor-kit'),
                    'menu_order' => esc_html__('Menu Order', 'roofing-elementor-kit'),
                    'modified' => esc_html__('Last Modified', 'roofing-elementor-kit'),
                    'comment_count' => esc_html__('Comment Count', 'roofing-elementor-kit'),
                    'rand' => esc_html__('Random', 'roofing-elementor-kit'),
                ],
                'default' => 'post_date',
            ]
        );

        $this->add_control(
            'projects_posts_per_page',
            [
                'label' => esc_html__('Posts Per Page', 'roofing-elementor-kit'),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 100,
                'step' => 1,
                'default' => 5,
            ]
        );

        $this->end_controls_section();
    }


    protected function render() {
        $settings = $this->get_settings_for_display();
        $order = $settings['projects_order'];
        $orderby = $settings['projects_orderby'];
        $posts_per_page = $settings['projects_posts_per_page'];
        $paged = isset($_POST['paged']) ? intval($_POST['paged']) : 1;
        $category = get_query_var('roofing');

        if ( $category ) {

            $args = [
                'post_type'      => 'projects',
                'orderby'        => $orderby,
                'order'          => $order,
                'posts_per_page' => $posts_per_page,
                'paged'          => 1,
                'tax_query'      => [
                    [
                        'taxonomy' => 'roofing',
                        'field'    => 'slug',
                        'terms'    => $category,
                    ],
                ],
            ];

        } else {

        $args = [
            'post_type' => 'projects',
            'orderby' => $orderby,
            'order' => $order,
            'posts_per_page' => $posts_per_page,
            'paged'          => 1,
        ];
       }
        $project_query = new \WP_Query($args);
        ?>
            <div class="loader" style="display: none;"></div>
         
            <div class="filter-container">
                   <?php  $roofing = get_terms('roofing'); ?>
                    <a href="#" class="filter active" data-title="">All Roofing</a>
                    <?php foreach($roofing as $category){ ?>
                        <a href="#" class="filter" data-title ="<?php echo $category->slug; ?>"><?php echo $category->name; ?></a>
                    <?php } ?>
              </div>
             
          
            <div class="sr_recent_project sr_recent_project_gridbox">
                <div class="recent_project_inner">
                    <div class="recent_project_grid">
                         <?php while ($project_query->have_posts()) { ?>
                            <?php $project_query->the_post(); ?>
                            <?php $categories = get_the_terms(get_the_ID(), 'roofing'); ?> 
                            <div class="single_project">
                                <?php if (has_post_thumbnail()) { ?>

                                <div class="project_featured_image">
                                    <a href="<?php echo esc_url(get_permalink()); ?>">
                                    <img src="<?php echo esc_url(get_the_post_thumbnail_url()); ?>" alt="<?php echo esc_attr(get_the_title()); ?>">
                                    </a>
                                </div>

                                <?php } else { ?>

                                    <div class="project_featured_image">
                                        <a href="<?php echo esc_url(get_permalink()); ?>">
                                        <img src="<?php echo site_url(); ?>/wp-content/uploads/2024/07/recent_project_1.png" alt="<?php echo esc_attr(get_the_title()); ?>">
                                        </a>
                                    </div>

                                <?php } ?>
                                    

                                <div class="project_info">
                                    <div class="project_category_title">
                                        <?php if (!empty($categories)) { ?>
                                        <?php foreach ($categories as $cat) { ?>
                                            <?php $category_name = esc_html($cat->name); ?>
                                            <div class="project_category_titlecategory">
                                            <a href="<?php echo esc_url(get_category_link($cat->term_id)); ?>"><h5><?php echo esc_html($category_name); ?></h5></a>
                                            </div>
                                            <?php } ?>

                                        <?php } ?>

                                        <a href="<?php echo esc_url(get_permalink()); ?>">
                                            <div class="project_title">
                                                <h4><?php echo esc_html(get_the_title()); ?></h4>
                                            </div>
                                        </a>

                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                    </div>
                    <span class="pagination-data" data-orderby="<?php echo esc_attr($orderby); ?>" data-order="<?php echo esc_attr($order); ?>" data-page="<?php echo esc_attr($posts_per_page); ?>"></span>
                    <?php
                    $total_pages = $project_query->max_num_pages;
                    if ($total_pages > 1) {
                        echo'<div class="project-pagination">';
                                global $wp_query;
                                $big = 999999999; // need an unlikely integer
                                echo paginate_links( array(
                                'base'    => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
                            'current' => $paged,
                            'prev_text'    => __('Prev'),
                            'next_text'    => __('Next'),
                            'prev_next'   => TRUE,
                            'total'   => $project_query->max_num_pages
                                ) );
                        echo'</div>';
                        }
                    ?>   
                </div>
            </div>
            
        <?php
            }
}
?>
