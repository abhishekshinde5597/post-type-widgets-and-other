<?php
/**
 * Plugin Name: Roofing-Elementor-Kit
 * Description: Widgets   
 * Version:     1.0.0
 * Author:      roofing-elementor-kit
 * Author URI: 
 * Text Domain: roofing-elementor-kit
 */

 function register_post_widgets($widgets_manager)
{

    require_once(__DIR__ . '/widgets/recent_projects.php');
    require_once(__DIR__ . '/widgets/client_testimonial.php');
    require_once(__DIR__ . '/widgets/latest_blog.php');
    require_once(__DIR__ . '/widgets/flip_box_team.php');
    require_once(__DIR__ . '/widgets/sr_button.php');
    require_once(__DIR__ . '/widgets/blog_listing.php');
    require_once(__DIR__ . '/widgets/project_listing.php');
    require_once(__DIR__ . '/widgets/timeline_slider.php');


    $widgets_manager->register(new \recent_projects());
    $widgets_manager->register(new \client_testimonial());
    $widgets_manager->register(new \latest_blog());
    $widgets_manager->register(new \flip_box_team());
    $widgets_manager->register(new \sr_button());
    $widgets_manager->register(new \blog_listing());
    $widgets_manager->register(new \project_listing());
    $widgets_manager->register(new \timeline_slider());

    
}
add_action('elementor/widgets/register', 'register_post_widgets');

/**bloglisting-ajax call */
function add_this_script_footer(){ 
    ?>
    <script>
    jQuery(document).ready(function($) {
        var page = 1

        //**jQuery for blogs post pagination */
        jQuery(document).on('click', '.blog-pagination .page-numbers', function (e) {
            var orderby = jQuery('.pagination-data').data('orderby');
            var post_per_page = jQuery('.pagination-data').data('page');
            var order = jQuery('.pagination-data').data('order');
            e.preventDefault();


            
            var page = 1;
            if (!isNaN(parseInt(jQuery(this).text()))) {
                page = parseInt(jQuery(this).text());
            } else if (jQuery(this).hasClass('next')) {
               
                page = parseInt(jQuery('.blog-pagination .current').text()) + 1;
            } else if (jQuery(this).hasClass('prev')) {
                page = parseInt(jQuery('.blog-pagination .current').text()) - 1;
                // alert(jQuery('.pagination .current').text());
            }
            // if (page) {
            //     bloglistingajax('',page,orderby,post_per_page,order);
            // }
                var currentUrl = window.location.href;
                if (currentUrl.includes("/category/")) {
                var categoryRegex = /\/category\/([^\/?]+)/;
                var matches = currentUrl.match(categoryRegex);
                var categorySlug = matches && matches[1];
                bloglistingajax('',categorySlug,page,orderby,post_per_page,order);

              } else if(currentUrl.includes("/tag/")) {
                var categoryRegex = /\/tag\/([^\/?]+)/;
                var matches = currentUrl.match(categoryRegex);
                var tag = matches && matches[1];
                bloglistingajax(tag,categorySlug,page,orderby,post_per_page,order);

              }else {
                bloglistingajax('','',page,orderby,post_per_page,order);
              }
            
        });
        
        //**jQuery ajax call back function for filter */
        function bloglistingajax(tag,categorySlug,page,orderby,post_per_page,order) {
            jQuery('.loader').show();
            jQuery.ajax({
                url: '<?php echo admin_url('admin-ajax.php'); ?>',
                type: 'POST',
                data: {
                    action: 'blog_listing_ajax',
                    page : page,
                    orderby :orderby ,
                    post_per_page : post_per_page,
                    order : order,
                    categorySlug:categorySlug,
                    tag:tag
                },
                success: function(response) {
                    jQuery('.sr_news_blogs').html(response);
                    jQuery('.loader').hide();
                
                },
                error: function(xhr, status, error) {
                    console.log(xhr.responseText); // Log error response
                }
            });
        }

        //**jQuery ajax call for project posttype */
        jQuery(document).on('click','.filter', function(e){
            e.preventDefault();
            var currntpage = 1;
            var catgoryval = jQuery('a.filter.active').data('title');
            var orderby = jQuery('.pagination-data').data('orderby');
            var post_per_pages = jQuery('.pagination-data').data('page');
            var order = jQuery('.pagination-data').data('order');
            project_listing_ajax(catgoryval,currntpage,orderby,post_per_pages,order);
        });

             var currentUrl = window.location.href;
            if (currentUrl.includes("/roofing/")) {
            var categoryRegex = /\/roofing\/([^\/?]+)/;
            var matches = currentUrl.match(categoryRegex);
            var categorySlug = matches && matches[1];
    
            jQuery('.filter.active').removeClass('active');
            jQuery('.filter[data-title="' + categorySlug + '"]').addClass('active');
              } 
        
        //**jQuery pagination for project post type: page numbers */
        jQuery(document).on('click', '.project-pagination .page-numbers', function (e) {
            var orderby = jQuery('.pagination-data').data('orderby');
            var post_per_pages = jQuery('.pagination-data').data('page');
            var order = jQuery('.pagination-data').data('order');
            var catgoryval = jQuery('a.filter.active').data('title');
            e.preventDefault();
            // alert(this);
            var currntpage  = 1;
            if (!isNaN(parseInt(jQuery(this).text()))) {
                currntpage  = parseInt(jQuery(this).text());
            } else if (jQuery(this).hasClass('next')) {
               
                currntpage  = parseInt(jQuery('.project-pagination .current').text()) + 1;
            } else if (jQuery(this).hasClass('prev')) {
                currntpage  = parseInt(jQuery('.project-pagination .current').text()) - 1;
                // alert(jQuery('.pagination .current').text());
            }
            if (currntpage ) {
                project_listing_ajax(catgoryval,currntpage,orderby,post_per_pages,order);
            }
        });

        //*ajax filter call back function*/
        function project_listing_ajax(catgoryval,currntpage,orderby,post_per_pages,order) {
            jQuery('.loader').show();
            jQuery.ajax({
                url: '<?php echo admin_url('admin-ajax.php'); ?>',
                type: 'POST',
                data: {
                    action: 'project_listing_ajax',
                    catgoryval : catgoryval,
                    page : currntpage,
                    orderby :orderby ,
                    post_per_page : post_per_pages,
                    order : order
                },
                success: function(response) {
                    jQuery('.sr_recent_project').html(response);
                    jQuery('.loader').hide();
                
                },
                error: function(xhr, status, error) {
                    console.log(xhr.responseText); // Log error response
                }
            });
        }
    
     });
    </script>
    <?php 
    }    
add_action('wp_footer', 'add_this_script_footer'); 

//*ajax ajax action for project listing */ */
add_action('wp_ajax_project_listing_ajax','project_listing_ajax');
add_action('wp_ajax_nopriv_project_listing_ajax','project_listing_ajax');

function project_listing_ajax(){

    ob_start();
    $currentPage = !empty($_POST['page']) ? $_POST['page'] : 1;
    $orderby = !empty($_POST['orderby']) ? $_POST['orderby'] : '';
    $post_per_pages = !empty($_POST['post_per_page']) ? $_POST['post_per_page'] : '';
    $order = !empty($_POST['order']) ? $_POST['order'] : '';
    $category = !empty($_POST['catgoryval']) ? $_POST['catgoryval'] : '';
    
    $args = [
        'post_type' => 'projects',
        'orderby' => $orderby,
        'order' => $order,
        'posts_per_page' => $post_per_pages,
        'paged'  => $currentPage,

    ];

    if ($category ) {
        $args['tax_query'] = array(
          array(
            'taxonomy' => 'roofing',
            'field' => 'slug',
            'terms' => $category,
          ),
        );
      }

    $project_query = new \WP_Query($args);
         ?>
        <div class="recent_project_inner">
            <div class="recent_project_grid">
                <?php while ($project_query->have_posts()) { ?>
                <?php $project_query->the_post(); ?>
                <?php $categories = get_the_terms(get_the_ID(), 'roofing'); ?> 
                <div class="single_project">
                    <?php if (has_post_thumbnail()) { ?>

                    <div class="project_featured_image">
                        <a href="<?php echo esc_url(get_permalink()); ?>">
                        <img src="<?php echo esc_url(get_the_post_thumbnail_url()); ?>" alt="<?php echo esc_attr(get_the_title()); ?>">
                        </a>
                    </div>

                    <?php } else { ?>

                        <div class="project_featured_image">
                            <a href="<?php echo esc_url(get_permalink()); ?>">
                            <img src="<?php echo site_url(); ?>/wp-content/uploads/2024/07/recent_project_1.png" alt="<?php echo esc_attr(get_the_title()); ?>">
                            </a>
                        </div>

                    <?php } ?>
                        

                    <div class="project_info">
                        <div class="project_category_title">
                            <?php if (!empty($categories)) { ?>
                            <?php foreach ($categories as $cat) { ?>
                                <?php $category_name = esc_html($cat->name); ?>
                                <div class="project_category_titlecategory">
                                <a href="<?php echo esc_url(get_category_link($cat->term_id)); ?>"> <h5><?php echo esc_html($category_name); ?></h5></a>
                                </div>
                                <?php } ?>

                            <?php } ?>

                            <a href="<?php echo esc_url(get_permalink()); ?>">
                                <div class="project_title">
                                    <h4><?php echo esc_html(get_the_title()); ?></h4>
                                </div>
                            </a>

                        </div>
                    </div>
                </div>
                <?php } ?>
            </div>
            <span class="pagination-data" data-orderby="<?php echo esc_attr($orderby); ?>" data-order="<?php echo esc_attr($order); ?>" data-page="<?php echo esc_attr($post_per_pages); ?>"></span>
            <?php
            $total_pages = $project_query->max_num_pages;
            if ($total_pages > 1) {
                echo'<div class="project-pagination">';                    
                      global $wp_query;
                        $big = 999999999; // need an unlikely integer
                        echo paginate_links( array(
                        'base'    => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
                        'current' => $currentPage,
                        'prev_text'    => __('Prev'),
                    'next_text'    => __('Next'),
                    'prev_next'   => TRUE,
                    'total'   => $project_query->max_num_pages
                        ) );
                echo'</div>';
                }
            ?>   
        </div>
    
    <?php
    wp_reset_postdata();
    die();
    return ob_get_clean();
}

//*ajax ajax action for Blog listing */ */
add_action('wp_ajax_blog_listing_ajax','blog_listing_ajax');
add_action('wp_ajax_nopriv_blog_listing_ajax','blog_listing_ajax');

function blog_listing_ajax(){

    ob_start();
    $tag = !empty($_POST['tag']) ? $_POST['tag'] : '';
    $category = !empty($_POST['categorySlug']) ? $_POST['categorySlug'] : '';
    $currentPage = !empty($_POST['page']) ? $_POST['page'] : 1;
    $orderby = !empty($_POST['orderby']) ? $_POST['orderby'] : '';
    $post_per_page = !empty($_POST['post_per_page']) ? $_POST['post_per_page'] : '';
    $order = !empty($_POST['order']) ? $_POST['order'] : '';
    
    

    $args = [
        'post_type' => 'post',
        'orderby' => $orderby,
        'order' => $order,
        'posts_per_page' => $post_per_page,
        'paged'  => $currentPage,
    ];

    if (!empty($category)) {
        $args['tax_query'] = [
            [
                'taxonomy' => 'category',
                'field'    => 'slug',
                'terms'    => $category,
            ],
        ];
    }
    if (!empty($tag)) {
        $args['tax_query'] = [
            [
                'taxonomy' => 'post_tag',
                'field'    => 'slug',
                'terms'    => $tag,
            ],
        ];
    }

   
    $blog_query = new \WP_Query($args);
    // echo"<pre>";
    // print_r($blog_query);
    // echo"</pre>";
    // exit();
     ?>
        <div class="blog_inner_section">
                <div class="blog_grid_box">
                    <?php if ($blog_query->have_posts()) : ?>
                    <?php while ($blog_query->have_posts()) : $blog_query->the_post(); ?>
                    <?php $thumb = get_the_post_thumbnail_url($blog_query->ID); ?>
                        <div class="single_blog"  style="background-image: url('<?php echo $thumb ?>')">
                            <img src="<?php echo get_stylesheet_directory_uri();?>/assets/images/blog_hover.svg" alt="Overlay Image" class="sr_overlay-image">
                            <div class="date_year">
                                <span class="date_month"><?php echo get_the_date('d M,'); ?></span>
                                <span class="year"><?php echo get_the_date('Y'); ?></span>
                            </div>
                                <div class="blog_bottom_info">
                                    <div class="roffing_category_tag">
                                    <div class="roffing_post_category">
                                            <?php
                                            $categories = get_the_category();
                                            foreach ($categories as $category) {
                                                echo '<a href="' . esc_url(get_category_link($category->term_id)) . '"><span class="category">' . esc_html($category->name) . '</span></a>';
                                            }
                                            ?>
                                        </div>
                                        <div class="category_tag">
                                            <?php
                                            $tags = get_the_tags();
                                            foreach ($tags as $tag) {
                                                echo '<a href="' . esc_url(get_category_link($tag->term_id)) . '"><span class="category">' . esc_html($tag->name) . '</span></a>';
                                            }
                                            ?>
                                        </div>
                                </div>
                                <div class="blog_title_sec">
                                    <a href="<?php the_permalink(); ?>">
                                        <h3 class="blog_title"><?php the_title(); ?></h3>
                                    </a>
                                </div>
                            </div>
                            <a href="<?php the_permalink(); ?>" class="blog_cta_box">
                                <div class="blog_cta">
                                    <img src="<?php echo get_stylesheet_directory_uri();?>/assets/images/blog_cta_arrow.svg" alt="blog_cta_btn_icon">
                                </div>
                            </a>
                        </div>
                        <?php endwhile; ?>
                        <?php wp_reset_postdata(); ?>
                    <?php else : ?>
                            <p><?php esc_html_e('No posts found', 'roofing-elementor-kit'); ?></p>
                    <?php endif; ?>
                    
                </div> 
                <span class="pagination-data" data-orderby="<?php echo esc_attr($orderby); ?>" data-order="<?php echo esc_attr($order); ?>" data-page="<?php echo esc_attr($post_per_page); ?>"></span>
                    <?php
                        $total_pages = $blog_query->max_num_pages;
                        if ($total_pages > 1) {
                            echo'<div class="blog-pagination">';
                                    global $wp_query;
                                    $big = 999999999; // need an unlikely integer
                                    echo paginate_links( array(
                                    'base'    => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
                                'current' => $currentPage,
                                'prev_text'    => __('Prev'),
                                'next_text'    => __('Next'),
                                'prev_next'   => TRUE,
                                'total'   => $blog_query->max_num_pages
                                    ) );
                            echo'</div>';
                            }
                        ?>          
        </div>
    <?php
    wp_reset_postdata();
    die();
    return ob_get_clean();
}
