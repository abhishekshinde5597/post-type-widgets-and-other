<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class breadcrumb extends \Elementor\Widget_Base {

    public function get_name() {
        return 'Element_Breadcrumb';
    }

    public function get_title() {
        return __( 'Element Breadcrumb', 'Elementor-Widgets-Kit' );
    }

    public function get_icon() {
        return 'eicon-bullet-list';
    }

    public function get_categories() {
        return [ 'basic' ];
    }

    protected function register_controls() {

        $this->start_controls_section(
            'content_section',
            [
                'label' => __( 'Breadcrumb Items', 'Elementor-Widgets-Kit' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'page_name',
            [
                'label' => __( 'Page Name', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __( 'Page Title', 'Elementor-Widgets-Kit' ),
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'page_url',
            [
                'label' => __( 'Page URL', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::URL,
                'placeholder' => __( 'https://your-link.com', 'Elementor-Widgets-Kit' ),
                'show_external' => true,
                'default' => [
                    'url' => '',
                    'is_external' => false,
                ],
            ]
        );

        $this->add_control(
            'breadcrumb_group',
            [
                'label' => __( 'Breadcrumb Items', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'page_name' => __( 'Home', 'Elementor-Widgets-Kit' ),
                        'page_url' => [ 'url' => site_url() ],
                    ],
                ],
                'title_field' => '{{{ page_name }}}',
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $breadcrumb_group = $settings['breadcrumb_group'];
    
        if ( ! empty( $breadcrumb_group ) ) {
            $breadcrumbs = array();
    
            echo '<p class="aquatech-breadcrumb">';
            foreach ( $breadcrumb_group as $index => $breadcrumb ) {
                $page_name = $breadcrumb['page_name'];
                $page_url = ! empty( $breadcrumb['page_url']['url'] ) ? esc_url( $breadcrumb['page_url']['url'] ) : get_permalink();
                $page_url2 = ! empty( $breadcrumb['page_url']['url'] ) ? esc_url( $breadcrumb['page_url']['url'] ) :"";
                // Add breadcrumb item to the schema data
                $breadcrumbs[] = array(
                    '@type' => 'ListItem',
                    'position' => $index + 1,
                    'name' => $page_name,
                    'item' => $page_url
                );
    
                // Render the breadcrumb
                if ( ! empty( $page_url2 ) ) {
                    echo '<a href="' . $page_url2 . '">' . esc_html( $page_name ) . '</a>';
                } else {
                    // If no URL, just display the page name without an anchor
                   
                    echo ' <span class="last"> '. esc_html( $page_name ) .' </span> ';
                }
    
                // Add a separator except for the last item
                if ( $index < count( $breadcrumb_group ) - 1 ) {
                    echo ' <span class="separator"> > </span> ';
                }
            }
            echo '</p>';
    
            // Output the Schema.org structured data script
            echo '<script type="application/ld+json">';
            echo json_encode([
                '@context' => 'https://schema.org',
                '@type' => 'BreadcrumbList',
                'itemListElement' => $breadcrumbs
            ], JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
            echo '</script>';
        }
    }
    
}
