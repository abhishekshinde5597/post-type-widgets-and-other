<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class nosexpertise_slider extends \Elementor\Widget_Base {

    public function get_name() {
        return 'Element-Slide';
    }

    public function get_title() {
        return esc_html__( 'Element-Slide', 'Elementor-Widgets-Kit' );
    }

    public function get_style_depends() {
		return [ 'nos-expertise-style' ];
	}
    
    public function get_icon() {
        return 'eicon-slider-push';
    }

    public function get_keywords() {
        return [ 'card', 'service', 'highlight', 'essential' ];
    }

    protected function register_controls() {
        $this->start_controls_section(
            'content_section',
            [
                'label' => esc_html__( 'Content Section', 'Elementor-Widgets-Kit' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );
    
        $repeater = new \Elementor\Repeater();
    
        $repeater->add_control(
            'slider_title',
            [
                'label' => esc_html__( 'Title', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__( 'title' , 'Elementor-Widgets-Kit' ),
                'placeholder' => 'Add Your Title Here',
                'label_block' => true,
            ]
        );
    
        $repeater->add_control(
            'slider_content',
            [
                'label' => esc_html__( 'Content', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::WYSIWYG,
                'default' => esc_html__( 'Description' , 'Elementor-Widgets-Kit' ),
                'placeholder' => 'Add Your Content Here',
                'label_block' => true,
            ]
        );
    
        $repeater->add_control(
            'slider_link',
            [
                'label' => esc_html__( 'Link', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::URL,
                'options' => [ 'url', 'is_external', 'nofollow' ],
                'default' => [
                    'url' => '',
                    'is_external' => true,
                    'nofollow' => true,
                ],
                'label_block' => true,
            ]
        );
    
        $repeater->add_control(
            'slider_button',
            [
                'label' => esc_html__( 'Button Text', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__( 'title' , 'Elementor-Widgets-Kit' ),
                'placeholder' => 'title',
                'label_block' => true,
            ]
        );
    
        $repeater->add_control(
            'image',
            [
                'label' => esc_html__( 'Image', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
            ]
        );
    
        $this->add_control(
            'expertise_list',
            [
                'label' => esc_html__( ' List', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'slider_title' => esc_html__( 'Title', 'Elementor-Widgets-Kit' ),
                        'slider_content' => esc_html__( 'Description', 'Elementor-Widgets-Kit' ),
                    ],
                    [
                        'slider_title' => esc_html__( 'Title',  'Elementor-Widgets-Kit' ),
                        'slider_content' => esc_html__( 'Description', 'Elementor-Widgets-Kit' ),
                    ],
                ],
                'title_field' => '{{{ slider_title }}}',
            ]
        );
    
        $this->end_controls_section();
    
        // Slider Settings Section
        $this->start_controls_section(
            'slider_settings_section',
            [
                'label' => esc_html__( 'Slider Settings', 'Elementor-Widgets-Kit' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );
    
        $this->add_control(
            'slides_to_show',
            [
                'label' => esc_html__( 'Slides to Show', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 3,
                'min' => 1,
                'max' => 10,
            ]
        );
    
        $this->add_control(
            'slides_to_scroll',
            [
                'label' => esc_html__( 'Slides to Scroll', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 1,
                'min' => 1,
                'max' => 10,
            ]
        );
    
        $this->add_control(
            'autoplay',
            [
                'label' => esc_html__( 'Autoplay', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Yes', 'Elementor-Widgets-Kit' ),
                'label_off' => esc_html__( 'No', 'Elementor-Widgets-Kit' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );
    
        $this->add_control(
            'autoplay_speed',
            [
                'label' => esc_html__( 'Autoplay Speed', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 3000,
                'min' => 1000,
                'step' => 500,
                'condition' => [
                    'autoplay' => 'yes',
                ],
            ]
        );
    
        $this->add_control(
            'infinite',
            [
                'label' => esc_html__( 'Infinite Loop', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Yes', 'Elementor-Widgets-Kit' ),
                'label_off' => esc_html__( 'No', 'Elementor-Widgets-Kit' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );
    
        $this->add_control(
            'dots',
            [
                'label' => esc_html__( 'Dots Navigation', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Yes', 'Elementor-Widgets-Kit' ),
                'label_off' => esc_html__( 'No', 'Elementor-Widgets-Kit' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );
    
        $this->add_control(
            'arrows',
            [
                'label' => esc_html__( 'Arrows Navigation', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Yes', 'Elementor-Widgets-Kit' ),
                'label_off' => esc_html__( 'No', 'Elementor-Widgets-Kit' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );
    
        $this->add_control(
            'slides_to_show_tablet',
            [
                'label' => esc_html__( 'Slides to Show (Tablet)', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 2,
                'min' => 1,
                'max' => 10,
            ]
        );
    
        $this->add_control(
            'slides_to_show_mobile',
            [
                'label' => esc_html__( 'Slides to Show (Mobile)', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 1,
                'min' => 1,
                'max' => 10,
            ]
        );
    
        $this->add_control(
            'slides_to_show_upto1440',
            [
                'label' => esc_html__( 'Slides to Show (UP 1441)', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 1,
                'min' => 1,
                'max' => 10,
            ]
        );


        $this->add_responsive_control(
            'slider_alignment',
            [
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'label' => esc_html__( 'Arrow Alignment', 'Elementor-Widgets-Kit' ),
                'options' => [
                    'left' => [
                        'title' => esc_html__( 'Left', 'Elementor-Widgets-Kit' ),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__( 'Center', 'Elementor-Widgets-Kit' ),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__( 'Right', 'Elementor-Widgets-Kit' ),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile', 'laptop', 'tablet_landscape', 'mobile_landscape' ],
                'prefix_class' => 'content-align-%s',
            ]
        );

        $this->end_controls_section();
        $this->start_controls_section(
			'title_section',
			[
				'label' => esc_html__( 'Title', 'Elementor-Widgets-Kit' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

         $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'selector' => '{{WRAPPER}} .production-post-type-title',
			]
		);

        
        $this->add_responsive_control(
            'title_padding',
            [
                'label' => esc_html__( 'Padding', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                
                'devices' => [ 'desktop', 'tablet', 'mobile' ,'laptop','tablet_landscape','mobile_landscape'],
                'default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px', // Default unit
                ],
                'tablet_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px', // Default unit for tablet
                ],
                'mobile_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px', // Default unit for mobile
                ],
                'laptop_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px',
                ],
                'tablet_landscape_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px',
                ],
                'mobile_landscape_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px',
                ],
                
                'selectors' => [
                    '{{WRAPPER}} .production-post-type-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'title_text_color',
            [
                'label' => esc_html__( 'Text Color', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .production-post-type-title ' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
			'description_section',
			[
				'label' => esc_html__( 'Description', 'Elementor-Widgets-Kit' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'content_typography',
				'selector' => '{{WRAPPER}} .production-post-type-content',
			]
		);

        $this->add_responsive_control(
            'description_padding',
            [
                'label' => esc_html__( 'Padding', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                
                'devices' => [ 'desktop', 'tablet', 'mobile' ,'laptop','tablet_landscape','mobile_landscape'],
                'default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px', // Default unit
                ],
                'tablet_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px', // Default unit for tablet
                ],
                'mobile_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px', // Default unit for mobile
                ],
                'laptop_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px',
                ],
                'tablet_landscape_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px',
                ],
                'mobile_landscape_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px',
                ],
                
                'selectors' => [
                    '{{WRAPPER}} .production-post-type-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'content_text_color',
            [
                'label' => esc_html__( 'Text Color', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .production-post-type-content ' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();

        

        $this->start_controls_section(
			'butoon_style_section',
			[
				'label' => esc_html__( 'Button', 'Elementor-Widgets-Kit' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'content_typography',
				'selector' => '{{WRAPPER}} .btn',
			]
		);

        $this->add_responsive_control(
            'title_padding',
            [
                'label' => esc_html__( 'Padding', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                
                'devices' => [ 'desktop', 'tablet', 'mobile' ,'laptop','tablet_landscape','mobile_landscape'],
                'default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px', // Default unit
                ],
                'tablet_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px', // Default unit for tablet
                ],
                'mobile_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px', // Default unit for mobile
                ],
                'laptop_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px',
                ],
                'tablet_landscape_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px',
                ],
                'mobile_landscape_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px',
                ],
                
                'selectors' => [
                    '{{WRAPPER}} .btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'content_align',
            [
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'label' => esc_html__( 'Alignment', 'Elementor-Widgets-Kit' ),
                'options' => [
                    'left' => [
                        'title' => esc_html__( 'Left', 'Elementor-Widgets-Kit' ),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__( 'Center', 'Elementor-Widgets-Kit' ),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__( 'Right', 'Elementor-Widgets-Kit' ),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile', 'laptop', 'tablet_landscape', 'mobile_landscape' ],
                'prefix_class' => 'content-align-%s',
            ]
        );
        

        $this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'border',
				'selector' => '{{WRAPPER}} .btn',
			]
		);

        $this->add_control(
            'border_color',
            [
                'label' => esc_html__( 'Button Border Color', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .btn::before' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'buttonbg_color',
            [
                'label' => esc_html__( 'Button Background Color', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .btn' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'button_text_color',
            [
                'label' => esc_html__( 'Button text Color', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .btn ' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'btn_typography',
				'selector' => '{{WRAPPER}} .btn',
			]
		);

        $this->add_responsive_control(
            'btn_padding',
            [
                'label' => esc_html__( 'Padding', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                
                'devices' => [ 'desktop', 'tablet', 'mobile' ,'laptop','tablet_landscape','mobile_landscape'],
                'default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px', // Default unit
                ],
                'tablet_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px', // Default unit for tablet
                ],
                'mobile_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px', // Default unit for mobile
                ],
                'laptop_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px',
                ],
                'tablet_landscape_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px',
                ],
                'mobile_landscape_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px',
                ],
                
                'selectors' => [
                    '{{WRAPPER}} .btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        

         // Style Tab
         $this->start_controls_section(
            'style_section',
            [
                'label' => __( 'Image', 'Elementor-Widgets-Kit' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
    
        
       
        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'box_shadow',
                'selector' => '{{WRAPPER}} .slider-image',
            ]
        );
    
        
        $this->add_responsive_control(
            'nosslider_image_max_width',
            [
                'label' => esc_html__( 'Max Width', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 5,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 100,
                ],
                'selectors' => [
                    '{{WRAPPER}} .slider-image' => 'max-width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
			'slider_image_width',
			[
				'label' => esc_html__( 'Width', 'Elementor-Widgets-Kit' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => '%',
					'size' => 50,
				],
				'selectors' => [
					'{{WRAPPER}} .slider-image' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

        $this->add_responsive_control(
			'slider_image_height',
			[
				'label' => esc_html__( 'Height', 'Elementor-Widgets-Kit' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => '%',
					'size' => 50,
				],
				'selectors' => [
					'{{WRAPPER}} .slider-image' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

         $this->add_control(
            'nosslider_image_object_fit',
            [
                'label' => esc_html__( 'Object Fit', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'fill' => esc_html__( 'Fill', 'Elementor-Widgets-Kit' ),
                    'cover' => esc_html__( 'Cover', 'Elementor-Widgets-Kit' ),
                    'contain' => esc_html__( 'Contain', 'Elementor-Widgets-Kit' ),
                    'none' => esc_html__( 'None', 'Elementor-Widgets-Kit' ),
                    'scale-down' => esc_html__( 'Scale Down', 'Elementor-Widgets-Kit' ),
                ],
                'default' => 'cover',
                'selectors' => [
                    '{{WRAPPER}} .slider-image' => 'object-fit: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'nosslider_image_border_radius',
            [
                'label' => esc_html__( 'Border Radius', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em', 'rem' ],
                'selectors' => [
                    '{{WRAPPER}} .slider-image' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'nosslider_image_flex_direction',
            [
                'label' => 'Flex Direction',
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'row' => 'Row',
                    'row-reverse' => 'Row Reverse',
                    'column' => 'Column',
                    'column-reverse' => 'Column Reverse',
                ],
                'default' => 'row',
            ]
        );

        $this->add_control(
            'flex_direction_tablet',
            [
                'label' => 'Flex Direction (Tablet)',
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'row' => 'Row',
                    'row-reverse' => 'Row Reverse',
                    'column' => 'Column',
                    'column-reverse' => 'Column Reverse',
                ],
                'default' => 'column',
                'condition' => [
                    'flex_direction!' => 'row',
                ],
                'selectors' => [
                    '@media (max-width: 1024px)' => 'nosslider_image_flex_direction: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'flex_direction_mobile',
            [
                'label' => 'Flex Direction (Mobile)',
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'row' => 'Row',
                    'row-reverse' => 'Row Reverse',
                    'column' => 'Column',
                    'column-reverse' => 'Column Reverse',
                ],
                'default' => 'column',
                'condition' => [
                    'flex_direction!' => 'column',
                ],
                'selectors' => [
                    '@media (max-width: 767px)' => 'nosslider_image_flex_direction: {{VALUE}};',
                ],
            ]
        );
    
        $this->end_controls_section();

    
    }
    
    protected function render() {
        $settings = $this->get_settings_for_display();
        $unique_id = uniqid('slider_'); // Generate a unique ID for each slider instance
        ?>
        <div class="itech-production-post-slider" id="<?php echo esc_attr($unique_id); ?>">
        <?php foreach($settings['expertise_list'] as $item): ?>
                  <?php 
                     $image_align = $settings['nosslider_image_flex_direction'];
                    ?>
            <div class="production-post-type-item <?php echo 'image-position-' . esc_attr( $image_align ); ?>">
                <?php if(!empty($item['image']['url'])): ?>
                    <figure class="production-post-type-thumbnail">
                        <img src="<?php echo esc_url($item['image']['url']); ?>" class=" slider-image" alt="<?php echo esc_attr($item['slider_title']); ?>">
                    </figure>
                <?php endif; ?>
                <div class="production-content-wrapper">
                    <div class="post-content-wrapper" data-mcs-theme="minimal-dark">
                    <?php if(!empty($item['slider_title'])): ?>
                        <a href="<?php echo esc_url($item['slider_link']['url']); ?>"><div class="production-post-type-title mob"><?php echo esc_html($item['slider_title']); ?></div></a>
                    <?php endif; ?>
                    
                    <?php if(!empty($item['slider_content'])): ?>
                        <div class="production-post-type-content"><?php echo $item['slider_content']; ?></div>
                    <?php endif; ?>
                    <?php if(!empty($item['slider_link']['url'])): ?>
                        <?php $content_align = $settings['content_align'];?>
                        <a href="<?php echo esc_url($item['slider_link']['url']); ?>" class="btn" content-align-<?php echo esc_attr( $content_align ); ?>>
                            <?php echo esc_html($item['slider_button']); ?>
                        </a>
                    <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
    <script type="text/javascript">
        jQuery(document).ready(function($) {
           
                // Check if the screen width is less than 768px (adjust as needed)
                if (jQuery(window).width() < 768) {
                    jQuery('.post-content-wrapper').addClass('mCustomScrollbar');
                }
  
            var sliderId = '<?php echo esc_js($unique_id); ?>';
            var sliderWrapper = jQuery('#' + sliderId).closest('.post-content-wrapper');

            // var arrowAlignment = '<?php// echo $settings['arrow_alignment']; ?>'; 
            // console.log(arrowAlignment);
            // if (arrowAlignment === 'left') {
            //     sliderWrapper.addClass('arrows-align-left');
            // } else if (arrowAlignment === 'right') {
            //     sliderWrapper.addClass('arrows-align-right');
            // } else {
            //     sliderWrapper.addClass('arrows-align-center');
            // }
            jQuery('#' + sliderId).slick({
                slidesToShow: <?php echo $settings['slides_to_show']; ?>,
                rtl: false,
                centerMode: false,
                slidesToScroll: <?php echo $settings['slides_to_scroll']; ?>,
                autoplay: <?php echo $settings['autoplay'] === 'yes' ? 'true' : 'false'; ?>,
                autoplaySpeed: <?php echo $settings['autoplay_speed']; ?>,
                infinite: <?php echo $settings['infinite'] === 'yes' ? 'true' : 'false'; ?>,
                dots: <?php echo $settings['dots'] === 'yes' ? 'true' : 'false'; ?>,
                arrows: <?php echo $settings['arrows'] === 'yes' ? 'true' : 'false'; ?>,
                prevArrow: '<img class="nosexpertise-arrow-left <?php echo $settings['slider_alignment']; ?>" src="/wp-content/plugins/elementor-widgets-kit/assets/images/Group 208.svg">',
                nextArrow: '<img class="nosexpertise-arrow-right <?php echo $settings['slider_alignment']; ?>" src="/wp-content/plugins/elementor-widgets-kit/assets/images/Group 207.svg">',
                
                
                responsive: [
                    {
                        breakpoint: 1600,
                        settings: {
                            slidesToShow: <?php echo $settings['slides_to_show_upto1440']; ?>,
                            slidesToScroll: 1,
                            dots: true,
                        }
                    },
                    {
                        breakpoint: 1024,
                        settings: {
                            slidesToShow: <?php echo $settings['slides_to_show_tablet']; ?>,
                            slidesToScroll: 1,
                            dots: true,
                        }
                    },
                    {
                        breakpoint: 600,
                        settings: {
                            slidesToShow: <?php echo $settings['slides_to_show_mobile']; ?>,
                            slidesToScroll: 1,
                        }
                    }
                ]
            });
        });
    </script>
       
      
          
        <?php
    }
    
    
}


