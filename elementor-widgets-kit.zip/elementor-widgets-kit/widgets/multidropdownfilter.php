<?php
class multidropdownfilter extends \Elementor\Widget_Base
{
    public function get_name()
    {
        return 'Element-Multidropdown-Filter';
    }

    public function get_title()
    {
        return esc_html__('Element-Multidropdown-Filter', 'Elementor-Widgets-Kit');
    }

    public function get_icon()
    {
        return 'eicon-taxonomy-filter';
    }

    public function get_style_depends() {
		return [ 'post-category-filter-style' ];
	}

    public function get_categories()
    {
        return ['basic'];
    }


    protected function register_controls()
    {

        $this->start_controls_section(
            'dynamic_categories_section',
            [
                'label' => __('Dynamic Categories', 'Elementor-Widgets-Kit'),
            ]
        );


        $this->add_control(
            'dynamic_categories1',
            [
                'label' => __('Applications', 'Elementor-Widgets-Kit'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'placeholder' => __('Enter categories for dropdown 1, separated by commas', 'Elementor-Widgets-Kit'),
                'label_block' => true,

            ]
        );

        $this->add_control(
            'dynamic_categories2',
            [
                'label'       => __('Sectors', 'Elementor-Widgets-Kit'),
                'type'        => \Elementor\Controls_Manager::TEXTAREA,
                'placeholder' => __('Enter categories for dropdown 2, separated by commas', 'Elementor-Widgets-Kit'),
                'label_block' => true,
            ]
        );

        $this->end_controls_section();
        
        $this->start_controls_section(
            'multidropdown_filter',
            [
                'label' => __('MutliDropdown Filter ', 'Elementor-Widgets-Kit'),
            ]
        );

        $this->add_control(
            'filter_loadmore_post_button',
            [
                'label' => esc_html__( 'Load more', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__( 'Load more' , 'Elementor-Widgets-Kit' ),
                'placeholder' => 'Button Text Load More',
                'label_block' => true,
            ]
        );

        $this->add_control(
            'filter_no_post_found',
            [
                'label' => esc_html__( 'No Post Found', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__( 'No Post Found' , 'Elementor-Widgets-Kit' ),
                'placeholder' => 'Button Text No Post Found',
                'label_block' => true,
            ]
        );

        

        $this->add_control(
            'filter_post_per_page',
            [
                'label' => esc_html__( 'Post Per Page ', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => esc_html__( '3' , 'Elementor-Widgets-Kit' ),
                'placeholder' => 'Post Per Page',
                'label_block' => true,
            ]
        );

        $this->add_control(
            'filter_all',
            [
                'label' => esc_html__( 'All Text', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__( 'All' , 'Elementor-Widgets-Kit' ),
                'placeholder' => 'All',
                'label_block' => true,
            ]
        );

        $this->add_control(
            'filter_placeholder',
            [
                'label' => esc_html__( 'Dropdown 1 Placeholder', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__( 'Filtrer par applications' , 'Elementor-Widgets-Kit' ),
                'placeholder' => 'Place your placeholder text here',
                'label_block' => true,
            ]
        );

        $this->add_control(
            'filter_placeholder2',
            [
                'label' => esc_html__( 'Dropdown 2 Placeholder', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__( 'Filtrer par secteurs' , 'Elementor-Widgets-Kit' ),
                'placeholder' => 'Place your placeholder text here',
                'label_block' => true,
            ]
        );


        // $this->add_control(
        //     'filter_dropdown1',
        //     [
        //         'label' => esc_html__( 'Filtrer Dropdown1', 'Elementor-Widgets-Kit' ),
        //         'type' => \Elementor\Controls_Manager::TEXT,
        //         'default' => esc_html__( 'Filtrer par applications' , 'Elementor-Widgets-Kit' ),
        //         'placeholder' => 'Filtrer Dropdown1',
        //         'label_block' => true,
        //     ]
        // );

        // $this->add_control(
        //     'filter_dropdown2',
        //     [
        //         'label' => esc_html__( 'Filtrer Dropdown2', 'Elementor-Widgets-Kit' ),
        //         'type' => \Elementor\Controls_Manager::TEXT,
        //         'default' => esc_html__( 'Filtrer par secteurs' , 'Elementor-Widgets-Kit' ),
        //         'placeholder' => 'Filtrer Dropdown2',
        //         'label_block' => true,
        //     ]
        // );
        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'filter_post_title',
            [
                'label'       => __('Title', 'Elementor-Widgets-Kit'),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'default'     => __('Title', 'Elementor-Widgets-Kit'),
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'filter_post_Description',
            [
                'label'       => __('Description', 'Elementor-Widgets-Kit'),
                'type'        => \Elementor\Controls_Manager::TEXTAREA,
                'default'     => __('Description', 'Elementor-Widgets-Kit'),
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'filter_post_image',
            [
                'label' => esc_html__( 'Image', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
            ]
        );
    

        $repeater->add_control(
            'filter_post_button',
            [
                'label' => esc_html__( 'Button Text', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__( 'title' , 'Elementor-Widgets-Kit' ),
                'placeholder' => 'title',
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'filter_post_link',
            [
                'label' => esc_html__( 'Link', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::URL,
                'options' => [ 'url', 'is_external', 'nofollow' ],
                'default' => [
                    'url' => '',
                    'is_external' => true,
                    'nofollow' => true,
                ],
                'label_block' => true,
            ]
        );
    

        $repeater->add_control(
            'Category1',
            [
                'label'       => __('Application', 'Elementor-Widgets-Kit'),
                'type'        => \Elementor\Controls_Manager::TEXTAREA,
                'default'     => __('Category1', 'Elementor-Widgets-Kit'),
                'placeholder' => 'Enter Category with comma ,',
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'Category2',
            [
                'label'       => __('Sector', 'Elementor-Widgets-Kit'),
                'type'        => \Elementor\Controls_Manager::TEXTAREA,
                'default'     => __('Category2', 'Elementor-Widgets-Kit'),
                'placeholder' => 'Enter Category with comma ,',
                'label_block' => true,
            ]
        );

        $this->add_control(
            'repeater',
            [
                'label'      => __('Filter Data', 'Elementor-Widgets-Kit'),
                'type'       => \Elementor\Controls_Manager::REPEATER,
                'fields'     => $repeater->get_controls(),
                'default'    => [
                    [
                        'filter_post_title'      => __('varruction d’une usine à recyclage', 'Elementor-Widgets-Kit'),
                        'Category1'  => __('Sector 1', 'Elementor-Widgets-Kit'),
                        'Category2'  => __('Category A', 'Elementor-Widgets-Kit'),
                        
                    ],
                ],
                'title_field' => '{{{ filter_post_title }}}',
            ]
        );

        

        $this->end_controls_section();

        $this->start_controls_section(
			'title_section',
			[
				'label' => esc_html__( 'Title', 'Elementor-Widgets-Kit' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

         $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'selector' => '{{WRAPPER}} .title',
			]
		);

        
        $this->add_responsive_control(
            'filter_posttitle_padding',
            [
                'label' => esc_html__( 'Padding', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                
                'devices' => [ 'desktop', 'tablet', 'mobile' ,'laptop','tablet_landscape','mobile_landscape'],
                'default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px', // Default unit
                ],
                'tablet_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px', // Default unit for tablet
                ],
                'mobile_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px', // Default unit for mobile
                ],
                'laptop_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px',
                ],
                'tablet_landscape_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px',
                ],
                'mobile_landscape_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px',
                ],
                
                'selectors' => [
                    '{{WRAPPER}} .title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'filter_posttitle_text_color',
            [
                'label' => esc_html__( 'Text Color', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .title ' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
			'filter_posttitle_text_width',
			[
				'label' => esc_html__( 'Width', 'Elementor-Widgets-Kit' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => '%',
					'size' => 50,
				],
				'selectors' => [
					'{{WRAPPER}} .title' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
        $this->end_controls_section();

        $this->start_controls_section(
			'filter_postdescription_section',
			[
				'label' => esc_html__( 'Description', 'Elementor-Widgets-Kit' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'content_typography',
				'selector' => '{{WRAPPER}} .description',
			]
		);

        $this->add_responsive_control(
            'filter_postdescription_padding',
            [
                'label' => esc_html__( 'Padding', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                
                'devices' => [ 'desktop', 'tablet', 'mobile' ,'laptop','tablet_landscape','mobile_landscape'],
                'default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px', // Default unit
                ],
                'tablet_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px', // Default unit for tablet
                ],
                'mobile_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px', // Default unit for mobile
                ],
                'laptop_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px',
                ],
                'tablet_landscape_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px',
                ],
                'mobile_landscape_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px',
                ],
                
                'selectors' => [
                    '{{WRAPPER}} .description' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'filter_postcontent_text_color',
            [
                'label' => esc_html__( 'Text Color', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .description ' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();

        

        $this->start_controls_section(
			'filter_postbutoon_style_section',
			[
				'label' => esc_html__( 'Button', 'Elementor-Widgets-Kit' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'content_typography',
				'selector' => '{{WRAPPER}} .link',
			]
		);

        $this->add_responsive_control(
            'filter_posttitle_padding',
            [
                'label' => esc_html__( 'Padding', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                
                'devices' => [ 'desktop', 'tablet', 'mobile' ,'laptop','tablet_landscape','mobile_landscape'],
                'default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px', // Default unit
                ],
                'tablet_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px', // Default unit for tablet
                ],
                'mobile_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px', // Default unit for mobile
                ],
                'laptop_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px',
                ],
                'tablet_landscape_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px',
                ],
                'mobile_landscape_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px',
                ],
                
                'selectors' => [
                    '{{WRAPPER}} .link' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'filter_postcontent_align',
            [
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'label' => esc_html__( 'Alignment', 'Elementor-Widgets-Kit' ),
                'options' => [
                    'left' => [
                        'title' => esc_html__( 'Left', 'Elementor-Widgets-Kit' ),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__( 'Center', 'Elementor-Widgets-Kit' ),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__( 'Right', 'Elementor-Widgets-Kit' ),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile', 'laptop', 'tablet_landscape', 'mobile_landscape' ],
                'prefix_class' => 'content-align-%s',
            ]
        );
        
        $this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'border',
				'selector' => '{{WRAPPER}} .link',
			]
		);


        $this->add_control(
            'filter_postborder_color',
            [
                'label' => esc_html__( 'Button Border Color', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .link::before' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'filter_postbuttonbg_color',
            [
                'label' => esc_html__( 'Button Background Color', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .link' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'filter_postbutton_text_color',
            [
                'label' => esc_html__( 'Button text Color', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .link ' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'btn_typography',
				'selector' => '{{WRAPPER}} .link',
			]
		);

        $this->add_responsive_control(
            'filter_postbtn_padding',
            [
                'label' => esc_html__( 'Padding', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                
                'devices' => [ 'desktop', 'tablet', 'mobile' ,'laptop','tablet_landscape','mobile_landscape'],
                'default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px', // Default unit
                ],
                'tablet_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px', // Default unit for tablet
                ],
                'mobile_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px', // Default unit for mobile
                ],
                'laptop_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px',
                ],
                'tablet_landscape_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px',
                ],
                'mobile_landscape_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px',
                ],
                
                'selectors' => [
                    '{{WRAPPER}} .link' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
      

        $this->end_controls_section();

        

         // Style Tab
         $this->start_controls_section(
            'style_section',
            [
                'label' => __( 'Image', 'Elementor-Widgets-Kit' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
    
        
       
        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'box_shadow',
                'selector' => '{{WRAPPER}} .filter-post-image',
            ]
        );
    
        
        $this->add_responsive_control(
            'filter_postimage_max_width',
            [
                'label' => esc_html__( 'Max Width', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 5,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 100,
                ],
                'selectors' => [
                    '{{WRAPPER}} .filter-post-image' => 'max-width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
			'filter_postimage_width',
			[
				'label' => esc_html__( 'Width', 'Elementor-Widgets-Kit' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => '%',
					'size' => 50,
				],
				'selectors' => [
					'{{WRAPPER}} .filter-post-image' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

        $this->add_responsive_control(
			'filter_postimage_height',
			[
				'label' => esc_html__( 'Height', 'Elementor-Widgets-Kit' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => '%',
					'size' => 50,
				],
				'selectors' => [
					'{{WRAPPER}} .filter-post-image' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

         $this->add_control(
            'filter_postimage_object_fit',
            [
                'label' => esc_html__( 'Object Fit', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'fill' => esc_html__( 'Fill', 'Elementor-Widgets-Kit' ),
                    'cover' => esc_html__( 'Cover', 'Elementor-Widgets-Kit' ),
                    'contain' => esc_html__( 'Contain', 'Elementor-Widgets-Kit' ),
                    'none' => esc_html__( 'None', 'Elementor-Widgets-Kit' ),
                    'scale-down' => esc_html__( 'Scale Down', 'Elementor-Widgets-Kit' ),
                ],
                'default' => 'cover',
                'selectors' => [
                    '{{WRAPPER}} .filter-post-image' => 'object-fit: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'filter_postimage_border_radius',
            [
                'label' => esc_html__( 'Border Radius', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em', 'rem' ],
                'selectors' => [
                    '{{WRAPPER}} .filter-post-image' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

       
        $this->end_controls_section();
    
    }

    protected function render()
{
    $settings = $this->get_settings_for_display();
    $category1_values = explode(',', $this->get_settings('dynamic_categories1'));
    $category2_values = explode(',', $this->get_settings('dynamic_categories2'));
 
    ?>

    <div class="container">
        <div class="tag-buttons-container">
            <div></div>
            <select id="categoryDropdown1" class="js-example-placeholder-single1 js-states form-control">
                <option value=""><?php //echo $settings['filter_dropdown1']; ?></option>
                <option value="all"><?php echo $settings['filter_all']; ?></option>
                <?php foreach ($category1_values as $category) : ?>
                    <option value="<?php echo esc_attr(trim($category)); ?>"><?php echo esc_html(trim($category)); ?></option>
                <?php endforeach; ?>
            </select>
            <!-- <img src="<?php //echo site_url(); ?>/wp-content/plugins/elementor-widgets-kit/assets/images/Icon(15).png"> -->
            <select id="categoryDropdown2" class="js-example-placeholder-single2 js-states form-control">
           <option value=""><?php// echo $settings['filter_dropdown2']; ?></option>
                <option value="all"><?php echo $settings['filter_all']; ?></option>
                <?php foreach ($category2_values as $category) : ?>
                    <option value="<?php echo esc_attr(trim($category)); ?>"><?php echo esc_html(trim($category)); ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="card-container">
            <?php if (!empty($settings['repeater'])) { ?>
                <?php foreach ($settings['repeater'] as $filter_data) { ?>
                    <?php
                    $categories1 = explode(',', $filter_data['Category1']);
                    $categories1_attr = implode(',', array_map('esc_html', array_map('trim', $categories1)));
                    $categories2 = explode(',', $filter_data['Category2']);
                    $categories2_attr = implode(',', array_map('esc_html', array_map('trim', $categories2)));
                    ?>
                    <div class="card" data-category1="<?php echo $categories1_attr; ?>" data-category2="<?php echo $categories2_attr; ?>">
                    <?php if(!empty($filter_data['filter_post_link']['url']) && $filter_data['filter_post_image']['url']){ ?> 
                    <a href="<?php echo esc_url($filter_data['filter_post_link']['url']); ?>"><img src="<?php echo esc_url($filter_data['filter_post_image']['url']); ?>" class="filter-post-image" alt="Image"></a>
                    <?php } else { ?> 
                        <img src="<?php echo esc_url($filter_data['filter_post_image']['url']); ?>" class="filter-post-image" alt="Image">
                        <?php } ?>
                        <div class="sector-main">
                                <div class="sector">
                                    <?php
                                    $categories2 = explode(',', $filter_data['Category2']);
                                    
                                    foreach ($categories2 as $category) {
                                        echo '<div class="sector-item">' . esc_html(trim($category)) . '</div>';
                                    }
                                   
                                    ?>
                                </div>
                                <div class="sector sector-app">
                                    <?php
                                    foreach ($categories1 as $category) {
                                        
                                        echo '<div class="application-item">' . esc_html(trim($category)) . '</div>';
                                    }
                                    ?>
                                </div>
                            </div>
                        <div class="card-content">  
                            <?php if(!empty($filter_data['filter_post_title']) && $filter_data['filter_post_link']['url']){ ?> 
                            <a href="<?php echo esc_url($filter_data['filter_post_link']['url']); ?>" class="link"><div class="title"><?php echo esc_html($filter_data['filter_post_title']); ?></div></a>
                            <?php } else { ?>
                              <div class="title"><?php echo esc_html($filter_data['filter_post_title']); ?></div>  
                           <?php } ?>
                            <?php if(!empty($filter_data['filter_post_Description'])){ ?> 
                            <div class="description"><?php echo esc_html($filter_data['filter_post_Description']); ?></div>
                            <?php } ?>
                            <?php if(!empty($filter_data['filter_post_button'])  &&  $filter_data['filter_post_link']['url']){ ?> 
                            <a href="<?php echo esc_url($filter_data['filter_post_link']['url']); ?>" class="link">
                                <?php echo esc_html($filter_data['filter_post_button']); ?>
                            </a>
                            <?php } ?>
                        </div>
                    </div>
                <?php } ?>
            <?php } ?>
        </div>
        <button id="loadMoreButton"><?php echo esc_html($settings['filter_loadmore_post_button']); ?></button>
    </div>
    
    <script>
        
        jQuery(document).ready(function ($) {
            var postBlocksContainer = jQuery(".card-container");
            var categoryDropdown1 = jQuery("#categoryDropdown1");
            var categoryDropdown2 = jQuery("#categoryDropdown2");
            var loadMoreButton = jQuery("#loadMoreButton");
            var postBlocks = jQuery(".card");

            var selectedCategory1 = "all";
            var selectedCategory2 = "all";
            var currentPage = 1;
            var itemsPerPage = <?php echo $settings['filter_post_per_page']; ?>

            function filterPosts() {
                currentPage = 1; // Reset current page when changing categories

                postBlocksContainer.html('');

                var filteredPostBlocks = postBlocks.filter(function () {
                    var blockCategory1 = jQuery(this).data("category1").split(',');
                    var blockCategory2 = jQuery(this).data("category2").split(',');

                    var matchCategory1 = selectedCategory1 === "all" || blockCategory1.includes(selectedCategory1);
                    var matchCategory2 = selectedCategory2 === "all" || blockCategory2.includes(selectedCategory2);

                    return matchCategory1 && matchCategory2;
                });

                showPostsForPage(currentPage, filteredPostBlocks);
                updateLoadMoreButton(filteredPostBlocks);
            }

            function showPostsForPage(pageNumber, postBlocks) {
                var startIndex = (pageNumber - 1) * itemsPerPage;
                var endIndex = Math.min(startIndex + itemsPerPage, postBlocks.length);

                for (var i = startIndex; i < endIndex; i++) {
                    postBlocksContainer.append(postBlocks.eq(i).clone());
                }
            }

            function updateLoadMoreButton(filteredPostBlocks) {
                var visiblePostCount = filteredPostBlocks.length;

                if (visiblePostCount <= currentPage * itemsPerPage) {
                    loadMoreButton.hide();
                } else {
                    loadMoreButton.show();
                }
            }

            function loadMorePosts() {
                currentPage++;
                var filteredPostBlocks = postBlocks.filter(function () {
                    var blockCategory1 = jQuery(this).data("category1").split(',');
                    var blockCategory2 = jQuery(this).data("category2").split(',');

                    var matchCategory1 = selectedCategory1 === "all" || blockCategory1.includes(selectedCategory1);
                    var matchCategory2 = selectedCategory2 === "all" || blockCategory2.includes(selectedCategory2);

                    return matchCategory1 && matchCategory2;
                });

                showPostsForPage(currentPage, filteredPostBlocks);
                updateLoadMoreButton(filteredPostBlocks);
            }

            categoryDropdown1.on("change", function () {
                // categoryDropdown1.Class('active');
                selectedCategory1 = jQuery(this).val();
                filterPosts();
                       
                if (jQuery('.card-container').is(':empty')) {
                jQuery('.card-container').append('<?php echo $settings['filter_no_post_found']; ?>');
                 }
            });

            categoryDropdown2.on("change", function () {
                selectedCategory2 = jQuery(this).val();
                filterPosts();     
                if (jQuery('.card-container').is(':empty')) {
                jQuery('.card-container').append('<?php echo $settings['filter_no_post_found']; ?>');
                }
            });

            loadMoreButton.on("click", loadMorePosts);
            filterPosts();


            jQuery(".js-example-placeholder-single1").select2({
                placeholder: "<?php echo $settings['filter_placeholder']; ?>",
                //allowClear: true,
                //minimumResultsForSearch: Infinity
                
             });
            jQuery(".js-example-placeholder-single2").select2({
                placeholder: "<?php echo $settings['filter_placeholder2']; ?>",
                //allowClear: true,
                //minimumResultsForSearch: Infinity
            });

        });
    </script>
   
    <?php
}



    
}

