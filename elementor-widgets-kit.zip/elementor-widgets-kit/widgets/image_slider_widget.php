<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class image_slider_widget extends \Elementor\Widget_Base {

    public function get_name() {
        return 'element-vertical-image-slider';
    }

    public function get_title() {
        return __( 'Element Vertical Image Slider', 'Elementor-Widgets-Kit' );
    }

    public function get_icon() {
        return 'eicon-navigation-vertical';
    }

    public function get_categories() {
        return [ 'basic' ];
    }

    protected function _register_controls() {

        $this->start_controls_section(
			'content_section_title',
			[
				'label' => esc_html__( 'Title & Subtitle', 'elementor-currency-control' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

        $this->add_control(
            'vertical_slider_title1',
            [
                'label' => __( 'Title', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => __( 'Default Title', 'Elementor-Widgets-Kit' ),
                'placeholder' => __( 'Enter title text here', 'Elementor-Widgets-Kit' ),
            ]
        );

        $this->add_control(
            'vertical_slider_subtitle1',
            [
                'label' => __( 'Subtitle', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => __( 'Default Subtitle', 'Elementor-Widgets-Kit' ),
                'placeholder' => __( 'Enter subtitle text here', 'Elementor-Widgets-Kit' ),
            ]
        );

        $this->end_controls_section();


        // Content Section
        $this->start_controls_section(
            'content_section',
            [
                'label' => esc_html__( 'Content Section', 'Elementor-Widgets-Kit' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new \Elementor\Repeater();

       

        $repeater->add_control(
            'vertical_slider_image',
            [
                'label' => esc_html__( 'Image', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
            ]
        );
    

        $this->add_control(
            'slider_contents',
            [
                'label' => __( 'Slider Items', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'vertical_slider_title' => __( 'Title 1', 'Elementor-Widgets-Kit' ),
                        'vertical_slider_subtitle' => __( 'Subtitle 1', 'Elementor-Widgets-Kit' ),
                    ],
                    [
                        'vertical_slider_title' => __( 'Title 2', 'Elementor-Widgets-Kit' ),
                        'vertical_slider_subtitle' => __( 'Subtitle 2', 'Elementor-Widgets-Kit' ),
                    ],
                ],
                'title_field' => '{{{ vertical_slider_title }}}',
            ]
        );

        $this->end_controls_section();

        // Slider Settings Section
        $this->start_controls_section(
            'slider_settings_section',
            [
                'label' => esc_html__( 'Slider Settings', 'Elementor-Widgets-Kit' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'vertical_slides_to_show',
            [
                'label' => esc_html__( 'Slides to Show', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 3,
                'min' => 1,
                'max' => 10,
            ]
        );

        $this->add_control(
            'vertical_slides_to_scroll',
            [
                'label' => esc_html__( 'Slides to Scroll', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 1,
                'min' => 1,
                'max' => 10,
            ]
        );

        $this->add_control(
            'vertical_autoplay',
            [
                'label' => esc_html__( 'Autoplay', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Yes', 'Elementor-Widgets-Kit' ),
                'label_off' => esc_html__( 'No', 'Elementor-Widgets-Kit' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'vertical_autoplay_speed',
            [
                'label' => esc_html__( 'Autoplay Speed', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 3000,
                'min' => 1000,
                'step' => 500,
                'condition' => [
                    'vertical_autoplay' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'vertical_infinite',
            [
                'label' => esc_html__( 'Infinite Loop', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Yes', 'Elementor-Widgets-Kit' ),
                'label_off' => esc_html__( 'No', 'Elementor-Widgets-Kit' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'vertical_dots',
            [
                'label' => esc_html__( 'Dots Navigation', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Yes', 'Elementor-Widgets-Kit' ),
                'label_off' => esc_html__( 'No', 'Elementor-Widgets-Kit' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'vertical_arrows',
            [
                'label' => esc_html__( 'Arrows Navigation', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Yes', 'Elementor-Widgets-Kit' ),
                'label_off' => esc_html__( 'No', 'Elementor-Widgets-Kit' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'vertical_slides_to_show_tablet',
            [
                'label' => esc_html__( 'Slides to Show (Tablet)', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 2,
                'min' => 1,
                'max' => 10,
            ]
        );

        $this->add_control(
            'vertical_slides_to_show_mobile',
            [
                'label' => esc_html__( 'Slides to Show (Mobile)', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 1,
                'min' => 1,
                'max' => 10,
            ]
        );

        $this->end_controls_section();


        $this->start_controls_section(
			'title_section',
			[
				'label' => esc_html__( 'Title', 'Elementor-Widgets-Kit' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

         $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'selector' => '{{WRAPPER}} .aquaitech-slider-title',
			]
		);

        
        $this->add_responsive_control(
            'title_padding',
            [
                'label' => esc_html__( 'Padding', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                
                'devices' => [ 'desktop', 'tablet', 'mobile' ,'laptop','tablet_landscape','mobile_landscape'],
                'default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px', // Default unit
                ],
                'tablet_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px', // Default unit for tablet
                ],
                'mobile_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px', // Default unit for mobile
                ],
                'laptop_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px',
                ],
                'tablet_landscape_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px',
                ],
                'mobile_landscape_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px',
                ],
                
                'selectors' => [
                    '{{WRAPPER}} .aquaitech-slider-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
			'slider_title_width',
			[
				'label' => esc_html__( 'Width', 'Elementor-Widgets-Kit' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => '%',
					'size' => 50,
				],
				'selectors' => [
					'{{WRAPPER}} .aquaitech-slider-title' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

        $this->add_control(
            'title_text_color',
            [
                'label' => esc_html__( 'Text Color', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .aquaitech-slider-title ' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
			'description_section',
			[
				'label' => esc_html__( 'Subtitle', 'Elementor-Widgets-Kit' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'content_typography',
				'selector' => '{{WRAPPER}} .aquaitech-slider-subtitle',
			]
		);

        $this->add_responsive_control(
            'description_padding',
            [
                'label' => esc_html__( 'Padding', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                
                'devices' => [ 'desktop', 'tablet', 'mobile' ,'laptop','tablet_landscape','mobile_landscape'],
                'default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px', // Default unit
                ],
                'tablet_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px', // Default unit for tablet
                ],
                'mobile_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px', // Default unit for mobile
                ],
                'laptop_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px',
                ],
                'tablet_landscape_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px',
                ],
                'mobile_landscape_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px',
                ],
                
                'selectors' => [
                    '{{WRAPPER}} .aquaitech-slider-subtitle' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
			'slider_subtitle_width',
			[
				'label' => esc_html__( 'Width', 'Elementor-Widgets-Kit' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => '%',
					'size' => 50,
				],
				'selectors' => [
					'{{WRAPPER}} .aquaitech-slider-subtitle' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

        $this->add_control(
            'content_text_color',
            [
                'label' => esc_html__( 'Text Color', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .aquaitech-slider-subtitle' => 'color: {{VALUE}};',
                ],
            ]
        );

        


        
        $this->end_controls_section();
           // Style Tab
           $this->start_controls_section(
            'style_section',
            [
                'label' => __( 'Image', 'Elementor-Widgets-Kit' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
    
        
       
        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'box_shadow',
                'selector' => '{{WRAPPER}} .aqua-item',
            ]
        );
        
        
        $this->add_responsive_control(
            'slider_image_max_width',
            [
                'label' => esc_html__( 'Max Width', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 5,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 100,
                ],
                'selectors' => [
                    '{{WRAPPER}} .aqua-item' => 'max-width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        
        $this->add_responsive_control(
			'slider_image_width',
			[
				'label' => esc_html__( 'Width', 'Elementor-Widgets-Kit' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => '%',
					'size' => 50,
				],
				'selectors' => [
					'{{WRAPPER}} .aqua-item' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

        $this->add_responsive_control(
			'slider_image_height',
			[
				'label' => esc_html__( 'Height', 'Elementor-Widgets-Kit' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => '%',
					'size' => 50,
				],
				'selectors' => [
					'{{WRAPPER}} .aqua-item' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

        // $this->add_control(
        //     'slider_image_object_fit',
        //     [
        //         'label' => esc_html__( 'Object Fit', 'Elementor-Widgets-Kit' ),
        //         'type' => \Elementor\Controls_Manager::SELECT,
        //         'options' => [
        //             'fill' => esc_html__( 'Fill', 'Elementor-Widgets-Kit' ),
        //             'cover' => esc_html__( 'Cover', 'Elementor-Widgets-Kit' ),
        //             'contain' => esc_html__( 'Contain', 'Elementor-Widgets-Kit' ),
        //             'none' => esc_html__( 'None', 'Elementor-Widgets-Kit' ),
        //             'scale-down' => esc_html__( 'Scale Down', 'Elementor-Widgets-Kit' ),
        //         ],
        //         'default' => 'cover',
        //         'selectors' => [
        //             '{{WRAPPER}} .aqua-item' => 'object-fit: {{VALUE}};',
        //         ],
        //     ]
        // );

        $this->add_control(
            'slider_image_background_size',
            [
                'label' => esc_html__( 'Background Size', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'auto' => esc_html__( 'Auto', 'Elementor-Widgets-Kit' ),
                    'cover' => esc_html__( 'Cover', 'Elementor-Widgets-Kit' ),
                    'contain' => esc_html__( 'Contain', 'Elementor-Widgets-Kit' ),
                ],
                'default' => 'cover',
                'selectors' => [
                    '{{WRAPPER}} .aqua-item' => 'background-size: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'slider_image_background_repeat',
            [
                'label' => esc_html__( 'Background Repeat', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'no-repeat' => esc_html__( 'No Repeat', 'Elementor-Widgets-Kit' ),
                    'repeat' => esc_html__( 'Repeat', 'Elementor-Widgets-Kit' ),
                    'repeat-x' => esc_html__( 'Repeat Horizontally', 'Elementor-Widgets-Kit' ),
                    'repeat-y' => esc_html__( 'Repeat Vertically', 'Elementor-Widgets-Kit' ),
                ],
                'default' => 'no-repeat',
                'selectors' => [
                    '{{WRAPPER}} .aqua-item' => 'background-repeat: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'slider_image_max_width',
            [
                'label' => esc_html__( 'Max Width', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 5,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 100,
                ],
                'selectors' => [
                    '{{WRAPPER}} .aqua-item' => 'max-width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $unique_id = uniqid('igslider_');
        ?>
        <div class="aquaslider" id="<?php echo esc_attr($unique_id); ?>">
            <?php foreach ( $settings['slider_contents'] as $item ) : ?>
               <?php  $bgimg = $item['vertical_slider_image']['url']; ?>
                <div class="aqua-item" style="background-image: url('<?php echo $bgimg ?>')">
                </div>
            <?php endforeach; ?>
        </div>
             <div class="aquaitech-titlesubtitle-main">
             <div class="aquaitech-titlesubtitle-wrap">
                    <?php if(!empty( $settings['vertical_slider_title1'])){ ?>
                        <div class="aquaitech-slider-title-wrap">
                            <h1 class="aquaitech-slider-title"><?php echo esc_html( $settings['vertical_slider_title1'] ); ?></h1>
                        </div>
                    <?php } ?>

                    <?php if(!empty( $settings['vertical_slider_subtitle1'])){ ?>
                     <div class="aquaitech-slider-subtitle-wrap">
                        <p class="aquaitech-slider-subtitle"><?php echo esc_html( $settings['vertical_slider_subtitle1'] ); ?></p>
                        <?php } ?>
                    </div>
            </div>
            </div>
        <script type="text/javascript">
        jQuery(document).ready(function($) {
            var sliderId = '<?php echo esc_js($unique_id); ?>';
            jQuery('#' + sliderId).slick({
                slidesToShow: <?php echo $settings['vertical_slides_to_show']; ?>,
                slidesToScroll: <?php echo $settings['vertical_slides_to_scroll']; ?>,
                autoplay: <?php echo $settings['vertical_autoplay'] === 'yes' ? 'true' : 'false'; ?>,
                autoplaySpeed: <?php echo $settings['vertical_autoplay_speed']; ?>,
                infinite: <?php echo $settings['vertical_infinite'] === 'yes' ? 'true' : 'false'; ?>,
                dots: <?php echo $settings['vertical_dots'] === 'yes' ? 'true' : 'false'; ?>,
                vertical: false,
                verticalSwiping: false,
                arrows: <?php echo $settings['vertical_arrows'] === 'yes' ? 'true' : 'false'; ?>,
                responsive: [
                    {
                        breakpoint: 1024,
                        settings: {
                            slidesToShow: <?php echo $settings['vertical_slides_to_show_tablet']; ?>,
                            slidesToScroll: 1,
                            dots: true,
                        }
                    },
                    {
                        breakpoint: 600,
                        settings: {
                            slidesToShow: <?php echo $settings['vertical_slides_to_show_mobile']; ?>,
                            slidesToScroll: 1,
                            vertical: false, // Override to horizontal on mobile
                            verticalSwiping: false, // Override to horizontal on mobile
                        }
                    }
                ]
            });
        });
        </script>
        <?php
    }
}
