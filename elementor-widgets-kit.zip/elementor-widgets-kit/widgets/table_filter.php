<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class table_filter extends \Elementor\Widget_Base {

    public function get_name() {
        return 'Element-Data-Table';
    }

    public function get_title() {
        return __( 'Element-Data-Table', 'plugin-name' );
    }

    public function get_icon() {
        return 'eicon-table';
    }

    public function get_categories() {
        return [ 'basic' ];
    }

    protected function _register_controls() {
        // Table Headers
        $this->start_controls_section(
            'table_headers_section',
            [
                'label' => __( 'Table Headers', 'plugin-name' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'header_text',
            [
                'label' => __( 'Header Text', 'plugin-name' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __( 'Header', 'plugin-name' ),
                'placeholder' => __( 'Enter header text', 'plugin-name' ),
            ]
        );

        $this->add_control(
            'table_headers',
            [
                'label' => __( 'Table Headers', 'plugin-name' ),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [ 'header_text' => __( 'Column 1', 'plugin-name' ) ],
                    [ 'header_text' => __( 'Column 2', 'plugin-name' ) ],
                ],
                'title_field' => '{{{ header_text }}}',
            ]
        );

     

        $this->end_controls_section();

        $this->start_controls_section(
            'dynamic_categories_section',
            [
                'label' => __('Dynamic Categories', 'Elementor-Widgets-Kit'),
            ]
        );

        $this->add_control(
            'dynamic_categories1',
            [
                'label' => __('Applications', 'Elementor-Widgets-Kit'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'placeholder' => __('Enter categories for dropdown 1, separated by commas', 'Elementor-Widgets-Kit'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'dynamic_categories2',
            [
                'label'       => __('Sectors', 'Elementor-Widgets-Kit'),
                'type'        => \Elementor\Controls_Manager::TEXTAREA,
                'placeholder' => __('Enter categories for dropdown 2, separated by commas', 'Elementor-Widgets-Kit'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'filter_loadmore_post_button',
            [
                'label' => esc_html__( 'Load more', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__( 'Load more' , 'Elementor-Widgets-Kit' ),
                'placeholder' => 'Button Text Load More',
                'label_block' => true,
            ]
        );

        $this->add_control(
            'filter_no_post_found',
            [
                'label' => esc_html__( 'No Post Found', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__( 'No Post Found' , 'Elementor-Widgets-Kit' ),
                'placeholder' => 'Button Text No Post Found',
                'label_block' => true,
            ]
        );

        $this->add_control(
            'filter_post_per_page',
            [
                'label' => esc_html__( 'Post Per Page ', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 3,
                'placeholder' => 'Post Per Page',
                'label_block' => true,
            ]
        );
        $this->add_control(
            'filter_all',
            [
                'label' => esc_html__( 'All Text', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__( 'All' , 'Elementor-Widgets-Kit' ),
                'placeholder' => 'All',
                'label_block' => true,
            ]
        );

        $this->add_control(
            'filter_placeholder',
            [
                'label' => esc_html__( 'Dropdown 1 Placeholder', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__( 'Filtrer par applications' , 'Elementor-Widgets-Kit' ),
                'placeholder' => 'Place your placeholder text here',
                'label_block' => true,
            ]
        );

        $this->add_control(
            'filter_placeholder2',
            [
                'label' => esc_html__( 'Dropdown 2 Placeholder', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__( 'Filtrer par secteurs' , 'Elementor-Widgets-Kit' ),
                'placeholder' => 'Place your placeholder text here',
                'label_block' => true,
            ]
        );


        // $this->add_control(
        //     'filter_dropdown1',
        //     [
        //         'label' => esc_html__( 'Filter Dropdown 1', 'Elementor-Widgets-Kit' ),
        //         'type' => \Elementor\Controls_Manager::TEXT,
        //         'default' => esc_html__( 'Filter by applications' , 'Elementor-Widgets-Kit' ),
        //         'placeholder' => 'Filter Dropdown 1',
        //         'label_block' => true,
        //     ]
        // );

        // $this->add_control(
        //     'filter_dropdown2',
        //     [
        //         'label' => esc_html__( 'Filter Dropdown 2', 'Elementor-Widgets-Kit' ),
        //         'type' => \Elementor\Controls_Manager::TEXT,
        //         'default' => esc_html__( 'Filter by sectors' , 'Elementor-Widgets-Kit' ),
        //         'placeholder' => 'Filter Dropdown 2',
        //         'label_block' => true,
        //     ]
        // );

        $this->end_controls_section();

        // Table Cells
        $this->start_controls_section(
            'table_cells_section',
            [
                'label' => __( 'Table Cells', 'plugin-name' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'row_index',
            [
                'label' => __( 'Row Index', 'plugin-name' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 1,
                'min' => 1,
                'step' => 1,
            ]
        );

        $repeater->add_control(
            'column_index',
            [
                'label' => __( 'Column Index', 'plugin-name' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 1,
                'min' => 1,
                'step' => 1,
            ]
        );

        $repeater->add_control(
            'cell_text',
            [
                'label' => __( 'Cell Text', 'plugin-name' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __( 'Cell Content', 'plugin-name' ),
                'placeholder' => __( 'Enter cell content', 'plugin-name' ),
            ]
        );

        $repeater->add_control(
            'table_post_link',
            [
                'label' => esc_html__( 'Link', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::URL,
                'options' => [ 'url', 'is_external', 'nofollow' ],
                'default' => [
                    'url' => '',
                    'is_external' => true,
                    'nofollow' => true,
                ],
                'label_block' => true,
            ]
        );
        
        $repeater->add_control(
            'Category1',
            [
                'label'       => __('Application', 'Elementor-Widgets-Kit'),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'default'     => __('Category1', 'Elementor-Widgets-Kit'),
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'Category2',
            [
                'label'       => __('Sector', 'Elementor-Widgets-Kit'),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'default'     => __('Category2', 'Elementor-Widgets-Kit'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'table_cells',
            [
                'label' => __( 'Table Cells', 'plugin-name' ),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [ 'row_index' => 1, 'column_index' => 1, 'cell_text' => __( 'Cell 1', 'plugin-name' ) ],
                    [ 'row_index' => 1, 'column_index' => 2, 'cell_text' => __( 'Cell 2', 'plugin-name' ) ],
                    [ 'row_index' => 2, 'column_index' => 1, 'cell_text' => __( 'Cell 3', 'plugin-name' ) ],
                ],
                'title_field' => '{{{ cell_text }}} -> Raw {{{ row_index }}}',
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $category1_values = explode(',', $this->get_settings('dynamic_categories1'));
        $category2_values = explode(',', $this->get_settings('dynamic_categories2'));
        $headers = $settings['table_headers'];
        $cells = $settings['table_cells'];
        $num_columns = count($headers);
       // echo  $num_columns;
        // Organize cells into rows
        $rows = [];
        foreach ($cells as $cell) {
            $row_index = $cell['row_index'];
            if (!isset($rows[$row_index])) {
                $rows[$row_index] = [];
            }
            $rows[$row_index][$cell['column_index']] = $cell;

        }
        // echo"<pre>";
        // print_r($rows);
        // echo"</pre>";
        ?>
        <div class="table-filter-wrapper">
            <div class="filter-dropdowns">
                <div></div>
                    <select id="categoryDropdown1" class="js-example-placeholder-single3 filter-dropdown">
                        <option value=""></option>
                        <option value="all"><?php echo $settings['filter_all']; ?></option>
                        <?php foreach ($category1_values as $category1): ?>
                            <option value="<?php echo trim($category1); ?>"><?php echo trim($category1); ?></option>
                        <?php endforeach; ?>
                    </select>

               
                    <select id="categoryDropdown2" class="js-example-placeholder-single4 filter-dropdown">
                    <option value=""></option>
                    <option value="all"><?php echo $settings['filter_all']; ?></option>
                        <?php foreach ($category2_values as $category2): ?>
                            <option value="<?php echo trim($category2); ?>"><?php echo trim($category2); ?></option>
                        <?php endforeach; ?>
                    </select>
               
            </div>

            <table class="custom-table">
                <thead>
                    <tr>
                        <?php foreach ($headers as $header): ?>
                            <th><?php echo $header['header_text']; ?></th>
                        <?php endforeach; ?>
                    </tr>
                </thead>
                <tbody>
                   
                    <?php foreach ($rows as $row_index => $columns): ?>
                        <tr class="table-row"
                            data-category1="<?php
                                $category1_values = [];
                                foreach ($columns as $column) {
                                    if (isset($column['Category1']) && !empty($column['Category1'])) {
                                        $category1_values = array_merge($category1_values, array_map('trim', explode(',', $column['Category1'])));
                                    }
                                }
                                echo esc_attr(implode(',', array_unique($category1_values)));?>"
                                 data-category2="<?php
                                $category2_values = [];
                                foreach ($columns as $column) {
                                    if (isset($column['Category2']) && !empty($column['Category2'])) {
                                        $category2_values = array_merge($category2_values, array_map('trim', explode(',', $column['Category2'])));
                                    }
                                }
                                echo esc_attr(implode(',', array_unique($category2_values)));
                            ?>">
                            
                            <?php for ($i = 0; $i < $num_columns; $i++): ?>
                                <td>
                                    <?php if (!empty($columns[$i + 1]['cell_text'])): ?>
                                        <span class="mobile-header-text <?php echo $headers[$i]['header_text']; ?>"><?php echo $headers[$i]['header_text']; ?>:</span>
                                        <?php if (!empty($columns[$i + 1]['table_post_link']['url'])): ?>
                                            <a href="<?php echo esc_url($columns[$i + 1]['table_post_link']['url']); ?>">
                                                <?php echo $columns[$i + 1]['cell_text']; ?>
                                            </a>
                                        <?php else: ?>
                                            <?php echo $columns[$i + 1]['cell_text']; ?>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </td>
                            <?php endfor; ?>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <button id="loadMoreButton"><?php echo esc_html($settings['filter_loadmore_post_button']); ?></button>
        </div>

        <script>
            jQuery(document).ready(function ($) {
            var postBlocksContainer = jQuery(".custom-table tbody");
            var categoryDropdown1 = jQuery("#categoryDropdown1");
            var categoryDropdown2 = jQuery("#categoryDropdown2");
            var loadMoreButton = jQuery("#loadMoreButton");
            var postBlocks = jQuery(".table-row");

            var selectedCategory1 = "all";
            var selectedCategory2 = "all";
            var currentPage = 1;
            var itemsPerPage = <?php echo $settings['filter_post_per_page']; ?>

            function filterPosts() {
                currentPage = 1; 
                postBlocksContainer.html('');

                var filteredPostBlocks = postBlocks.filter(function () {
                    var blockCategory1 = jQuery(this).data("category1").split(',');
                    var blockCategory2 = jQuery(this).data("category2").split(',');

                    var matchCategory1 = selectedCategory1 === "all" || blockCategory1.includes(selectedCategory1);
                    var matchCategory2 = selectedCategory2 === "all" || blockCategory2.includes(selectedCategory2);

                    return matchCategory1 && matchCategory2;
                });

                showPostsForPage(currentPage, filteredPostBlocks);
                updateLoadMoreButton(filteredPostBlocks);
            }

            function showPostsForPage(pageNumber, postBlocks) {
                var startIndex = (pageNumber - 1) * itemsPerPage;
                var endIndex = Math.min(startIndex + itemsPerPage, postBlocks.length);

                for (var i = startIndex; i < endIndex; i++) {
                    postBlocksContainer.append(postBlocks.eq(i).clone());
                }
            }

            function updateLoadMoreButton(filteredPostBlocks) {
                var visiblePostCount = filteredPostBlocks.length;

                if (visiblePostCount <= currentPage * itemsPerPage) {
                    loadMoreButton.hide();
                } else {
                    loadMoreButton.show();
                }
            }

            function loadMorePosts() {
                currentPage++;
                var filteredPostBlocks = postBlocks.filter(function () {
                    var blockCategory1 = jQuery(this).data("category1").split(',');
                    var blockCategory2 = jQuery(this).data("category2").split(',');

                    var matchCategory1 = selectedCategory1 === "all" || blockCategory1.includes(selectedCategory1);
                    var matchCategory2 = selectedCategory2 === "all" || blockCategory2.includes(selectedCategory2);

                    return matchCategory1 && matchCategory2;
                });

                showPostsForPage(currentPage, filteredPostBlocks);
                updateLoadMoreButton(filteredPostBlocks);
            }

            categoryDropdown1.on("change", function () {
                selectedCategory1 = jQuery(this).val();
                filterPosts();
                       
                if (jQuery('.custom-table tbody').is(':empty')) {
                    jQuery('.custom-table tbody').append('<?php echo $settings['filter_no_post_found']; ?>');
                 }
            });

            categoryDropdown2.on("change", function () {
                selectedCategory2 = jQuery(this).val();
                filterPosts();     
                if (jQuery('.custom-table tbody').is(':empty')) {

                jQuery('.custom-table tbody').append('<?php echo $settings['filter_no_post_found']; ?>');

                }
            });

            loadMoreButton.on("click", loadMorePosts);
            filterPosts();
            
            jQuery(".js-example-placeholder-single3").select2({
                placeholder: "<?php echo $settings['filter_placeholder']; ?>",
                //allowClear: true,
                //minimumResultsForSearch: Infinity
                
             });
            jQuery(".js-example-placeholder-single4").select2({
                placeholder: "<?php echo $settings['filter_placeholder2']; ?>",
                //allowClear: true,
                //minimumResultsForSearch: Infinity
            });

        });

            
        </script>
        <?php
    }

}
