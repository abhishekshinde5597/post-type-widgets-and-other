<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class category_widget extends \Elementor\Widget_Base {

    public function get_name() {
        return 'Element-Sector';
    }

    public function get_title() {
        return __( 'Element-Sector', 'Elementor-Widgets-Kit' );
    }

    public function get_icon() {
        return 'eicon-progress-tracker';
    }

    public function get_style_depends() {
		return [ 'category-widget-style' ];
	}

    public function get_categories() {
        return [ 'basic' ];
    }

    protected function _register_controls() {

        // Content Section
        $this->start_controls_section(
            'content_section',
            [
                'label' => esc_html__( 'Content Section', 'Elementor-Widgets-Kit' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new \Elementor\Repeater();
        //**repter fields  */
        $repeater->add_control(
            'sector_post_title',
            [
                'label' => __( 'Title', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => __( 'Default Title', 'Elementor-Widgets-Kit' ),
                'placeholder' => __( 'Enter title text here', 'Elementor-Widgets-Kit' ),
            ]
        );

        $repeater->add_control(
            'sector_post_category',
            [
                'label' => __( 'Sector', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => __( 'Sector', 'Elementor-Widgets-Kit' ),
                'placeholder' => __( 'Enter Your Sector here', 'Elementor-Widgets-Kit' ),
            ]
        );

        $repeater->add_control(
            'sector_post_image',
            [
                'label' => esc_html__( 'Image', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
            ]
        );

        $repeater->add_control(
            'sector_post_button',
            [
                'label' => esc_html__( 'Button Text', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__( 'Voir le projet' , 'Elementor-Widgets-Kit' ),
                'placeholder' => 'Voir le projet',
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'sector_post_link',
            [
                'label' => esc_html__( 'Link', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::URL,
                'options' => [ 'url', 'is_external', 'nofollow' ],
                'default' => [
                    'url' => '',
                    'is_external' => true,
                    'nofollow' => true,
                ],
                'label_block' => true,
            ]
        );
    
        
        $this->add_control(
            'sector_post_contents',
            [
                'label' => __( 'items', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'sector_post_title' => __( 'Title 1', 'Elementor-Widgets-Kit' ),
                       
                    ],
                    [
                        'sector_post_title' => __( 'Title 2', 'Elementor-Widgets-Kit' ),
                        
                    ],
                ],
                'title_field' => '{{{ sector_post_title }}}',
            ]
        );

        $this->end_controls_section();
    
        //**title style controllers */
        $this->start_controls_section(
			'sector_post_title_section',
			[
				'label' => esc_html__( 'Title', 'Elementor-Widgets-Kit' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

         $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'aqua-card_title_typography',
				'selector' => '{{WRAPPER}} .aqua-card-title',
			]
		);

        
        $this->add_responsive_control(
            'sector_posttitle_padding',
            [
                'label' => esc_html__( 'Padding', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                
                'devices' => [ 'desktop', 'tablet', 'mobile' ,'laptop','tablet_landscape','mobile_landscape'],
                'default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px', // Default unit
                ],
                'tablet_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px', // Default unit for tablet
                ],
                'mobile_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px', // Default unit for mobile
                ],
                'laptop_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px',
                ],
                'tablet_landscape_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px',
                ],
                'mobile_landscape_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px',
                ],
                
                'selectors' => [
                    '{{WRAPPER}} .aqua-card-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
			'sector_posttitle_width',
			[
				'label' => esc_html__( 'Width', 'Elementor-Widgets-Kit' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => '%',
					'size' => 50,
				],
				'selectors' => [
					'{{WRAPPER}} .aqua-card-title' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

        $this->add_control(
            'sector_posttitle_text_color',
            [
                'label' => esc_html__( 'Text Color', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .aqua-card-title ' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'sector_posttitle_text_border_radius',
            [
                'label' => esc_html__( 'Border Radius', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em', 'rem' ],
                'selectors' => [
                    '{{WRAPPER}} .aqua-card-title' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();

        //**sector style controllers */
        $this->start_controls_section(
			'sector_post_sector_section',
			[
				'label' => esc_html__( 'Sector', 'Elementor-Widgets-Kit' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

         $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'aqua-card_sector_typography',
				'selector' => '{{WRAPPER}} .aqua-card-sector',
			]
		);

        
        $this->add_responsive_control(
            'sector_postsector_padding',
            [
                'label' => esc_html__( 'Padding', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                
                'devices' => [ 'desktop', 'tablet', 'mobile' ,'laptop','tablet_landscape','mobile_landscape'],
                'default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px', // Default unit
                ],
                'tablet_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px', // Default unit for tablet
                ],
                'mobile_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px', // Default unit for mobile
                ],
                'laptop_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px',
                ],
                'tablet_landscape_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px',
                ],
                'mobile_landscape_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px',
                ],
                
                'selectors' => [
                    '{{WRAPPER}} .aqua-card-sector' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
			'sector_postsector_width',
			[
				'label' => esc_html__( 'Width', 'Elementor-Widgets-Kit' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => '%',
					'size' => 50,
				],
				'selectors' => [
					'{{WRAPPER}} .aqua-card-sector' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

        $this->add_control(
            'sector_postsector_text_color',
            [
                'label' => esc_html__( 'Text Color', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .aqua-card-sector ' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->end_controls_section();

       //**link style controllers */
        $this->start_controls_section(
			'sector_post_link_section',
			[
				'label' => esc_html__( 'Button', 'Elementor-Widgets-Kit' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

         $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'aqua-card_link_typography',
				'selector' => '{{WRAPPER}} .aqua-card-link',
			]
		);

        $this->add_responsive_control(
            'sector_postlink_border_radius',
            [
                'label' => esc_html__( 'Border Radius', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em', 'rem' ],
                'selectors' => [
                    '{{WRAPPER}} .aqua-card-link' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'border',
				'selector' => '{{WRAPPER}} .aqua-card-link',
			]
		);

        $this->add_control(
            'sector_postlin_bg_color',
            [
                'label' => esc_html__( 'Button Background Color', 'textdomain' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .aqua-card-link' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'sector_postlink_hover_color',
            [
                'label' => esc_html__( 'Button Hover Color', 'textdomain' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .aqua-card-link' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'sector_postlink_text_color',
            [
                'label' => esc_html__( 'Button text Color', 'textdomain' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .aqua-card-link ' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'sector_postlink_text_hover_color',
            [
                'label' => esc_html__( 'Button text hover Color', 'textdomain' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .aqua-card-link' => 'color: {{VALUE}};',
                ],
            ]
        );
        

        $this->add_responsive_control(
            'sector_postlink_padding',
            [
                'label' => esc_html__( 'Padding', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                
                'devices' => [ 'desktop', 'tablet', 'mobile' ,'laptop','tablet_landscape','mobile_landscape'],
                'default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px', // Default unit
                ],
                'tablet_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px', // Default unit for tablet
                ],
                'mobile_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px', // Default unit for mobile
                ],
                'laptop_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px',
                ],
                'tablet_landscape_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px',
                ],
                'mobile_landscape_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px',
                ],
                
                'selectors' => [
                    '{{WRAPPER}} .aqua-card-link' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        // $this->add_responsive_control(
		// 	'sector_postlink_width',
		// 	[
		// 		'label' => esc_html__( 'Width', 'Elementor-Widgets-Kit' ),
		// 		'type' => \Elementor\Controls_Manager::SLIDER,
		// 		'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
		// 		'range' => [
		// 			'px' => [
		// 				'min' => 0,
		// 				'max' => 1000,
		// 				'step' => 5,
		// 			],
		// 			'%' => [
		// 				'min' => 0,
		// 				'max' => 100,
		// 			],
		// 		],
		// 		'default' => [
		// 			'unit' => '%',
		// 			'size' => 50,
		// 		],
		// 		'selectors' => [
		// 			'{{WRAPPER}} .aqua-card-link' => 'width: {{SIZE}}{{UNIT}};',
		// 		],
		// 	]
		// );

        $this->add_control(
            'sector_postlink_text_color',
            [
                'label' => esc_html__( 'Text Color', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .aqua-card-link ' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->end_controls_section();

        //**Image style controllers */
           $this->start_controls_section(
            'style_section',
            [
                'label' => __( 'Image', 'Elementor-Widgets-Kit' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
    
        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'box_shadow',
                'selector' => '{{WRAPPER}} .aqua-item',
            ]
        );
            
        // Add the control in your widget class
        $this->add_control(
            'sector_post_image_background_position',
            [
                'label' => __( 'Background Position', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'center center',
                'options' => [
                    'center center' => __( 'Center Center', 'Elementor-Widgets-Kit' ),
                    'center top' => __( 'Center Top', 'Elementor-Widgets-Kit' ),
                    'center bottom' => __( 'Center Bottom', 'Elementor-Widgets-Kit' ),
                    'top left' => __( 'Top Left', 'Elementor-Widgets-Kit' ),
                    'top center' => __( 'Top Center', 'Elementor-Widgets-Kit' ),
                    'top right' => __( 'Top Right', 'Elementor-Widgets-Kit' ),
                    'bottom left' => __( 'Bottom Left', 'Elementor-Widgets-Kit' ),
                    'bottom center' => __( 'Bottom Center', 'Elementor-Widgets-Kit' ),
                    'bottom right' => __( 'Bottom Right', 'Elementor-Widgets-Kit' ),
                    'left center' => __( 'Left Center', 'Elementor-Widgets-Kit' ),
                    'right center' => __( 'Right Center', 'Elementor-Widgets-Kit' ),
                ],
            ]
        );

        $this->add_responsive_control(
			'sector_post_image_width',
			[
				'label' => esc_html__( 'Width', 'Elementor-Widgets-Kit' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => '%',
					'size' => 50,
				],
				'selectors' => [
					'{{WRAPPER}} .aqua-item' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

        $this->add_responsive_control(
			'sector_post_image_height',
			[
				'label' => esc_html__( 'Height', 'Elementor-Widgets-Kit' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => '%',
					'size' => 50,
				],
				'selectors' => [
					'{{WRAPPER}} .aqua-item' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

        $this->add_responsive_control(
            'sector_post_image_max_width',
            [
                'label' => esc_html__( 'Max Width', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 5,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 100,
                ],
                'selectors' => [
                    '{{WRAPPER}} .aqua-item' => 'max-width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();
        // //**Image style controllers */
        $this->start_controls_section(
            'box_style_section',
            [
                'label' => __( 'Box', 'Elementor-Widgets-Kit' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
			'box_height',
			[
				'label' => esc_html__( 'Height', 'Elementor-Widgets-Kit' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => '%',
					'size' => 50,
				],
				'selectors' => [
					'{{WRAPPER}} .aqua-card' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

        $this->add_responsive_control(
			'box_width',
			[
				'label' => esc_html__( 'Width', 'Elementor-Widgets-Kit' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => '%',
					'size' => 50,
				],
				'selectors' => [
					'{{WRAPPER}} .aqua-card' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

        $this->add_responsive_control(
            'box_max_width',
            [
                'label' => esc_html__( 'Max Width', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 5,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 100,
                ],
                'selectors' => [
                    '{{WRAPPER}} .aqua-card' => 'max-width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'box_padding',
            [
                'label' => esc_html__( 'Padding', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                
                'devices' => [ 'desktop', 'tablet', 'mobile' ,'laptop','tablet_landscape','mobile_landscape'],
                'default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px', // Default unit
                ],
                'tablet_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px', // Default unit for tablet
                ],
                'mobile_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px', // Default unit for mobile
                ],
                'laptop_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px',
                ],
                'tablet_landscape_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px',
                ],
                'mobile_landscape_default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                    'unit' => 'px',
                ],
                
                'selectors' => [
                    '{{WRAPPER}} .aqua-card' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'box_border_radius',
            [
                'label' => esc_html__( 'Border Radius', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em', 'rem' ],
                'selectors' => [
                    '{{WRAPPER}} .aqua-card' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();
        
    }

        protected function render() {
            $settings = $this->get_settings_for_display();
           
            ?>
            <?php if(!empty($settings['sector_post_contents'])){ ?>
            <div class="card-container">
                <?php foreach($settings['sector_post_contents'] as $sectorposts ){ ?>
                    <?php $background_position = $settings['sector_post_image_background_position'];
                    $background_repeat = $settings['sector_post_image_background_repeat']; ?>
                    <?php  
                    $bgimg = isset( $sectorposts['sector_post_image']['url'] ) ? $sectorposts['sector_post_image']['url'] : '';?>
                        <?php if( $sectorposts['sector_post_title'] ||  $sectorposts['sector_post_category'] || $sectorposts['sector_post_image']['url']   ){ ?>
                        <div class="aqua-card"style="background-image: url('<?php echo esc_url( $bgimg ); ?>'); 
                                                    background-position: <?php echo esc_attr( $background_position ); ?>;" >
                            <div class="entites-content"><img decoding="async" src="/wp-content/uploads/2023/11/Group-253.svg" alt="arrow"></div>
                            <div class="aqua-card-content mob">
                                <?php if(!empty($sectorposts['sector_post_category'])){ ?>
                                <h3 class="aqua-card-sector"><?php echo esc_html($sectorposts['sector_post_category']); ?></h3>
                                <?php } ?>
                                <?php if(!empty($sectorposts['sector_post_title'])){ ?>
                                <h2 class="aqua-card-title"><?php echo esc_html($sectorposts['sector_post_title']); ?></h2>
                                <?php } ?>
                                <?php if(!empty($sectorposts['sector_post_button']) && !empty($sectorposts['sector_post_link']) ){ ?>
                                    <a href="<?php echo esc_url($sectorposts['sector_post_link']['url']); ?>" class="aqua-card-link"><?php echo esc_html($sectorposts['sector_post_button']); ?><img src="<?php echo plugin_dir_url( dirname( __FILE__ ) ) . 'assets/images/Vector 3.svg'; ?>"></a>
                                <?php } ?>
                            </div>
                        </div>
                <?php } ?>
                <?php } ?>
            </div>
            <?php } ?>
            <script type="text/javascript">
            jQuery(document).ready(function() {
                function initializeSlick() {
                    var width = jQuery(window).width();
                    
                    if (width >= 300 && width <= 767) {
                        if (!jQuery('.card-container').hasClass('slick-initialized')) {
                            jQuery('.card-container').slick({
                                prevArrow: '<img class="nosexpertise-arrow-left" src="/wp-content/plugins/elementor-widgets-kit/assets/images/Group 208.svg">',
                                nextArrow: '<img class="nosexpertise-arrow-right" src="/wp-content/plugins/elementor-widgets-kit/assets/images/Group 207.svg">',
                                responsive: [
                                    {
                                        breakpoint: 300,
                                        settings: {
                                            slidesToShow: 2.1, // Use a numeric value
                                            slidesToScroll: 1,
                                            infinite:false,
                                        }
                                    },
                                    {
                                        breakpoint: 767,
                                        settings: {
                                            slidesToShow: 2.1, // Use a numeric value
                                            slidesToScroll: 1,
                                            infinite:false,
                                        }
                                    }
                                ]
                            });
                        }
                    } else {
                        if (jQuery('.card-container').hasClass('slick-initialized')) {
                            jQuery('.card-container').slick('unslick');
                        }
                    }
                }

                // Initialize Slick on page load
                initializeSlick();

                // Re-initialize Slick on window resize
                jQuery(window).resize(function() {
                    initializeSlick();
                });
            });

            </script>
       
            <?php
        }
}
