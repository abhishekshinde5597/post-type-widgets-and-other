<?php

/**
 * Plugin Name: Elementor-Widgets-Kit
 * Description: Widgets
 * Version:     1.0.0
 * Author:      Elementor-Widgets-Kit
 * Author URI:  
 * Text Domain: Elementor-Widgets-Kit
 */


 function aquaprox_widgets($widgets_manager)
{

    require_once( __DIR__ . '/widgets/nosexpertise_slider.php' );  
    $widgets_manager->register( new \nosexpertise_slider() );

    require_once( __DIR__ . '/widgets/table_filter.php' );  
    $widgets_manager->register( new \table_filter() );

    require_once( __DIR__ . '/widgets/slider_widget.php' );  
    $widgets_manager->register( new \slider_widget() );

    require_once( __DIR__ . '/widgets/category_widget.php' );  
    $widgets_manager->register( new \category_widget() );

    require_once( __DIR__ . '/widgets/multidropdownfilter.php' );  
    $widgets_manager->register( new \multidropdownfilter() );

    require_once( __DIR__ . '/widgets/breadcrumb.php' );  
    $widgets_manager->register( new \breadcrumb() );

    require_once( __DIR__ . '/widgets/image_slider_widget.php' );  
    $widgets_manager->register( new \image_slider_widget() );
    
}
add_action('elementor/widgets/register', 'aquaprox_widgets');

// function enqueue_slick_slider() {
//     wp_enqueue_style( 'slick-slider-css', 'https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css' );
//     wp_enqueue_script( 'slick-slider-js', 'https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js', array('jquery'), '1.8.1', true );
// }
// add_action( 'wp_enqueue_scripts', 'enqueue_slick_slider' );


function register_widget_styles() {
	wp_register_style( 'nos-expertise-style', plugins_url( 'assets/css/nos-expertise-style.css', __FILE__ ) );
    wp_register_style( 'category-widget-style', plugins_url( 'assets/css/category-widget-style.css', __FILE__ ) );
    wp_register_style( 'post-category-filter-style', plugins_url( 'assets/css/post-category-filter-style.css', __FILE__ ) );
    //wp_enqueue_style( 'select2', 'https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css' );
    wp_enqueue_style( 'select2-cs', 'https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css' );
    wp_enqueue_script( 'select2-js', 'https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js' );

}
add_action( 'wp_enqueue_scripts', 'register_widget_styles' );