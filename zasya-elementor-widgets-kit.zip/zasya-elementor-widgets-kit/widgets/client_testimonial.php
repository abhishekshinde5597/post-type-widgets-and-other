<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class client_testimonial extends \Elementor\Widget_Base {

    public function get_name() {
        return 'Element-Client-Testimonial';
    }

    public function get_title() {
        return esc_html__( 'Element-Client-Testimonial', 'Zasya-Elementor-Widgets-Kit' );
    }

    public function get_style_depends() {
		return [ 'clicenttestimonialslider-style' ];
	}

    public function get_icon() {
        return 'eicon-slider-push';
    }

    public function get_keywords() {
        return [ 'card', 'service', 'highlight', 'essential' ];
    }

    protected function register_controls() {
        // Reusable repeater for testimonials
        $repeater = new \Elementor\Repeater();
    
        $repeater->add_control(
            'review_tagline',
            [
                'label' => __('Review Tagline', 'Zasya-Elementor-Widgets-Kit'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Exceptional Service!', 'Zasya-Elementor-Widgets-Kit'),
                'label_block' => true,
            ]
        );
    
        $repeater->add_control(
            'review_description',
            [
                'label' => __('Review Description', 'Zasya-Elementor-Widgets-Kit'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => esc_html__('Lorem Ipsum is simply dummy text.', 'Zasya-Elementor-Widgets-Kit'),
                'label_block' => true,
            ]
        );
    
        $repeater->add_control(
            'review_rating',
            [
                'label' => __('Rating', 'Zasya-Elementor-Widgets-Kit'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    '1' => '1 Star',
                    '2' => '2 Stars',
                    '3' => '3 Stars',
                    '4' => '4 Stars',
                    '5' => '5 Stars',
                ],
                'default' => '5',
            ]
        );
    
        // Slide Sections
        for ($i = 1; $i <= 3; $i++) {
            $this->start_controls_section(
                "content_section_client_slide{$i}",
                [
                    'label' => esc_html__("Slide {$i}", 'Zasya-Elementor-Widgets-Kit'),
                    'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
                ]
            );
    
            $this->add_control(
                "client_img_slide{$i}",
                [
                    'label' => esc_html__('Client Image', 'Zasya-Elementor-Widgets-Kit'),
                    'type' => \Elementor\Controls_Manager::MEDIA,
                ]
            );
    
            $this->add_control(
                "client_name_slide{$i}",
                [
                    'label' => esc_html__('Client Name', 'Zasya-Elementor-Widgets-Kit'),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'default' => esc_html__('John Doe', 'Zasya-Elementor-Widgets-Kit'),
                    'placeholder' => 'Enter Client Name',
                    'label_block' => true,
                ]
            );
    
            $this->add_control(
                "client_designation_slide{$i}",
                [
                    'label' => esc_html__('Client Designation', 'Zasya-Elementor-Widgets-Kit'),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'default' => esc_html__('CEO, Example Corp.', 'Zasya-Elementor-Widgets-Kit'),
                    'placeholder' => 'Enter Designation',
                    'label_block' => true,
                ]
            );
    
            $this->add_control(
                "testimonials_slide{$i}",
                [
                    'label' => esc_html__('Testimonials', 'Zasya-Elementor-Widgets-Kit'),
                    'type' => \Elementor\Controls_Manager::REPEATER,
                    'fields' => $repeater->get_controls(),
                    'default' => [
                        [
                            'review_tagline' => esc_html__('Great Service!', 'Zasya-Elementor-Widgets-Kit'),
                            'review_description' => esc_html__('Lorem Ipsum is simply dummy text.', 'Zasya-Elementor-Widgets-Kit'),
                            'review_rating' => '5',
                        ],
                    ],
                    'title_field' => '{{{ review_tagline }}}',
                ]
            );
    
            $this->end_controls_section();
        }
    }
    

    protected function render() {
        $settings = $this->get_settings_for_display();
        // echo"<pre>";
        // print_r( $settings);
        // echo"</pre>";
        ?>
        <div class="zasya-tab-slider">
            <div class="zasya-tabs">
                <?php
                // Assuming the testimonials are in separate fields like client_name_slide1, client_name_slide2, etc.
                for ($i = 1; $i <= 3; $i++):  // Adjust the range as per your slider count
                    $client_image = isset($settings['client_img_slide' . $i]['url']) ? $settings['client_img_slide' . $i]['url'] : '';
                    $client_image_alt = isset($settings['client_img_slide' . $i]['alt']) ? $settings['client_img_slide' . $i]['alt'] : '';

                    $client_name = isset($settings['client_name_slide' . $i]) ? $settings['client_name_slide' . $i] : '';
                    $client_designation = isset($settings['client_designation_slide' . $i]) ? $settings['client_designation_slide' . $i] : '';
                ?>
                    <div class="zasya-tabs-content <?php echo $i === 1 ? 'active' : ''; ?>" id="tab-<?php echo $i; ?>-slider">
                        <div class="tab-image">
                            <img src="<?php echo esc_url($client_image); ?>" alt="<?php echo esc_html($client_image_alt); ?>">
                        </div>
                        <div class="tab-title-para">
                            <h4><?php echo esc_html($client_name); ?></h4>
                            <p><?php echo esc_html($client_designation); ?></p>
                        </div>
                    </div>
                    <?php
                    // Loop through each testimonial set for the slides
                   
                        ?>
                        <div class="zasya-three-sliders swiper <?php echo $i === 1 ? 'active' : ''; ?>" id="tab-<?php echo $i; ?>-slider">
                            <div class="swiper-wrapper">
                                <?php
                                // Assuming each testimonial has a structure inside an array
                                if (isset($settings['testimonials_slide' . $i])) {
                                    foreach ($settings['testimonials_slide' . $i] as $testimonial):
                                        $review_tagline = isset($testimonial['review_tagline']) ? $testimonial['review_tagline'] : '';
                                        $review_description = isset($testimonial['review_description']) ? $testimonial['review_description'] : '';
                                    
                                        ?>
                                        <div class="swiper-slide">
                                            <div class="zasya-slider-content">
                                                <h3><?php echo esc_html($review_tagline); ?></h3>
                                                <div class="stars">
                                                    <?php 
                                                    $rating = isset($testimonial['review_rating']) ? intval($testimonial['review_rating']) : 0;
                                                    $rating = max(0, min(5, $rating));  // Ensure rating is between 0 and 5
                                                    for ($star = 1; $star <= 5; $star++):  // Use a different variable for the star loop
                                                    ?>
                                                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M22.433 10.3126L17.7612 14.8666L18.8645 21.2986C18.8881 21.4365 18.8727 21.5783 18.8199 21.7079C18.7672 21.8375 18.6792 21.9498 18.566 22.032C18.4528 22.1143 18.3188 22.1632 18.1793 22.1733C18.0397 22.1833 17.9001 22.1542 17.7762 22.0891L11.9997 19.0523L6.22396 22.0883C6.1001 22.1534 5.96049 22.1826 5.82092 22.1725C5.68135 22.1624 5.54738 22.1135 5.43416 22.0313C5.32094 21.949 5.23299 21.8368 5.18025 21.7071C5.12751 21.5775 5.11208 21.4357 5.13571 21.2978L6.23896 14.8658L1.56646 10.3126C1.46617 10.2148 1.39524 10.091 1.36169 9.95506C1.32814 9.81911 1.33332 9.67649 1.37664 9.54334C1.41995 9.41018 1.49968 9.29182 1.60679 9.20163C1.71391 9.11145 1.84413 9.05305 1.98271 9.03305L8.43946 8.09555L11.327 2.24405C11.5797 1.7318 12.4197 1.7318 12.6725 2.24405L15.56 8.09555L22.0167 9.03305C22.155 9.05358 22.2848 9.11226 22.3915 9.20251C22.4983 9.29276 22.5778 9.41099 22.621 9.54392C22.6642 9.67685 22.6696 9.81921 22.6363 9.95499C22.6031 10.0908 22.5327 10.2146 22.433 10.3126Z" 
                                                                fill="<?php echo $star <= $rating ? '#F58220' : '#ccc'; ?>"/>
                                                        </svg>
                                                    <?php endfor; ?>
                                                </div>

                                                <p><?php echo esc_html($review_description); ?></p>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                <?php } ?>
                            </div>
                            <div class="swiper-pagination"></div>
                        </div>
                 
                <?php endfor; ?>
            </div>
    
            <div class="zasya-sliders">
                    <?php
                    // Loop through each testimonial set for the slides
                    for ($i = 1; $i <= 3; $i++):  // Adjust the range as per your slider count
                        ?>
                        <div class="zasya-three-sliders swiper <?php echo $i === 1 ? 'active' : ''; ?>" id="tab-<?php echo $i; ?>-slider">
                            <div class="swiper-wrapper">
                                <?php
                                // Assuming each testimonial has a structure inside an array
                                if (isset($settings['testimonials_slide' . $i])) {
                                    foreach ($settings['testimonials_slide' . $i] as $testimonial):
                                        $review_tagline = isset($testimonial['review_tagline']) ? $testimonial['review_tagline'] : '';
                                        $review_description = isset($testimonial['review_description']) ? $testimonial['review_description'] : '';
                                    
                                        ?>
                                        <div class="swiper-slide">
                                            <div class="zasya-slider-content">
                                                <h3><?php echo esc_html($review_tagline); ?></h3>
                                                <div class="stars">
                                                    <?php 
                                                    $rating = isset($testimonial['review_rating']) ? intval($testimonial['review_rating']) : 0;
                                                    $rating = max(0, min(5, $rating));  // Ensure rating is between 0 and 5
                                                    for ($star = 1; $star <= 5; $star++):  // Use a different variable for the star loop
                                                    ?>
                                                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M22.433 10.3126L17.7612 14.8666L18.8645 21.2986C18.8881 21.4365 18.8727 21.5783 18.8199 21.7079C18.7672 21.8375 18.6792 21.9498 18.566 22.032C18.4528 22.1143 18.3188 22.1632 18.1793 22.1733C18.0397 22.1833 17.9001 22.1542 17.7762 22.0891L11.9997 19.0523L6.22396 22.0883C6.1001 22.1534 5.96049 22.1826 5.82092 22.1725C5.68135 22.1624 5.54738 22.1135 5.43416 22.0313C5.32094 21.949 5.23299 21.8368 5.18025 21.7071C5.12751 21.5775 5.11208 21.4357 5.13571 21.2978L6.23896 14.8658L1.56646 10.3126C1.46617 10.2148 1.39524 10.091 1.36169 9.95506C1.32814 9.81911 1.33332 9.67649 1.37664 9.54334C1.41995 9.41018 1.49968 9.29182 1.60679 9.20163C1.71391 9.11145 1.84413 9.05305 1.98271 9.03305L8.43946 8.09555L11.327 2.24405C11.5797 1.7318 12.4197 1.7318 12.6725 2.24405L15.56 8.09555L22.0167 9.03305C22.155 9.05358 22.2848 9.11226 22.3915 9.20251C22.4983 9.29276 22.5778 9.41099 22.621 9.54392C22.6642 9.67685 22.6696 9.81921 22.6363 9.95499C22.6031 10.0908 22.5327 10.2146 22.433 10.3126Z" 
                                                                fill="<?php echo $star <= $rating ? '#F58220' : '#ccc'; ?>"/>
                                                        </svg>
                                                    <?php endfor; ?>
                                                </div>

                                                <p><?php echo esc_html($review_description); ?></p>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                <?php } ?>
                            </div>
                            <div class="swiper-pagination"></div>
                        </div>
                    <?php endfor; ?>
            </div>

        </div>
        <?php
    }
    
    
}
