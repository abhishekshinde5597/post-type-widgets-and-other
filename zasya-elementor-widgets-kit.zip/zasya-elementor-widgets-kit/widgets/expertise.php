<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class expertise extends \Elementor\Widget_Base {

    public function get_name() {
        return 'Element-Expertise';
    }

    public function get_title() {
        return esc_html__( 'Element-Expertise', 'Zasya-Elementor-Widgets-Kit' );
    }

    public function get_style_depends() {
		return [ 'Expertise-style' ];
	}
    
    public function get_icon() {
        return 'eicon-slider-push';
    }

    public function get_keywords() {
        return [ 'card', 'service', 'highlight', 'essential' ];
    }

    protected function register_controls() {
        $this->start_controls_section(
            'content_section',
            [
                'label' => esc_html__( 'Content Section', 'Zasya-Elementor-Widgets-Kit' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );
    
        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'expertise_image',
            [
                'label' => esc_html__( 'Image', 'Zasya-Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
            ]
        );
    
        $repeater->add_control(
            'expertise_title',
            [
                'label' => esc_html__( 'Title', 'Zasya-Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__( 'title' , 'Zasya-Elementor-Widgets-Kit' ),
                'placeholder' => 'Add Your Title Here',
                'label_block' => true,
            ]
        );
    
        $repeater->add_control(
            'expertise_content',
            [
                'label' => esc_html__( 'Content', 'Zasya-Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => esc_html__( 'Description' , 'Zasya-Elementor-Widgets-Kit' ),
                'placeholder' => 'Add Your Content Here',
                'label_block' => true,
            ]
        );
    
        $repeater->add_control(
            'expertise_link',
            [
                'label' => esc_html__( 'Link', 'Zasya-Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::URL,
                'options' => [ 'url', 'is_external', 'nofollow' ],
                'default' => [
                    'url' => '',
                    'is_external' => true,
                    'nofollow' => true,
                ],
                'label_block' => true,
            ]
        );
        
        $repeater->add_control(
            'expertise_button',
            [
                'label' => esc_html__( 'Button Text', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__( 'title' , 'Elementor-Widgets-Kit' ),
                'placeholder' => 'title',
                'label_block' => true,
            ]
        );
    
    
        $this->add_control(
            'expertise_lists',
            [
                'label' => esc_html__( ' List', 'Zasya-Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'expertise_title' => esc_html__( 'Title', 'Zasya-Elementor-Widgets-Kit' ),
                        'expertise_content' => esc_html__( 'Description', 'Zasya-Elementor-Widgets-Kit' ),
                    ],
                    [
                        'expertise_title' => esc_html__( 'Title',  'Zasya-Elementor-Widgets-Kit' ),
                        'expertise_content' => esc_html__( 'Description', 'Zasya-Elementor-Widgets-Kit' ),
                    ],
                ],
                'title_field' => '{{{ expertise_title }}}',
            ]
        );
    
        $this->end_controls_section();
    
        // Slider Settings Section
        
    
    }
    
    protected function render() {
        $settings = $this->get_settings_for_display();
        ?>
            <div class="zasya-four-col-sec">
                <?php if (!empty($settings['expertise_lists'])){ ?>
                    <?php foreach($settings['expertise_lists'] as $expertise_lists) {  ?>
                            <div class="zasya-four-col">
                                <?php if(!empty($expertise_lists['expertise_image']['url'])){ ?>
                                     <img src="<?php echo $expertise_lists['expertise_image']['url']; ?>" alt="<?php echo $expertise_lists['expertise_title']; ?>">
                                <?php } ?>

                                <div class="four-col-content-box">
                                <?php if(!empty($expertise_lists['expertise_image'] && $expertise_lists['expertise_title'] && $expertise_lists['expertise_content'] && $expertise_lists['expertise_button']  && $expertise_lists['expertise_link'])  ){ ?>
                                        <div class="four-col-content">
                                            <h3><?php echo $expertise_lists['expertise_title']; ?></h3>
                                            <div class="para-btn">
                                                <?php if(!empty($expertise_lists['expertise_content'])){ ?>
                                                     <span><?php echo $expertise_lists['expertise_content']; ?></span>
                                               <?php } ?>
                                              
                                                <a href="<?php echo $expertise_lists['expertise_link']['url']; ?>">
                                                    <?php if(!empty($expertise_lists['expertise_button'])){ ?>
                                                        <span><?php echo $expertise_lists['expertise_button']; ?></span>
                                                    <?php } ?>
                                                    <svg width="17" height="16" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M1.25 9.24999H12.4823L8.3661 13.3662C7.87793 13.8542 7.87793 14.6457 8.3661 15.1339C8.61018 15.3779 8.9301 15.5 9.25002 15.5C9.56993 15.5 9.88985 15.3779 10.1339 15.1338L16.3839 8.88382C16.872 8.39574 16.872 7.60424 16.3839 7.11607L10.1339 0.866063C9.64577 0.377979 8.85427 0.377979 8.3661 0.866063C7.87793 1.35415 7.87793 2.14565 8.3661 2.63382L12.4823 6.74999H1.25C0.559667 6.74999 0 7.30966 0 7.99999C0 8.69032 0.559667 9.24999 1.25 9.24999Z" fill="#F58220"/>
                                                    </svg>
                                                </a>
                                            </div>
                                        </div>
                                    <?php } ?>
                                </div>
                            </div>
                <?php } ?>
                <?php } ?>
            </div>
            
       
        <?php
    }
    
    
}


