<?php
use Elementor\Controls_Manager;

class bloglisting extends \Elementor\Widget_Base {

    public function get_name() {
        return 'Blogs';
    }

    public function get_title() {
        return __('Blogs', 'Zasya-Elementor-Widgets-Kit');
    }

    public function get_icon() {
        return 'eicon-archive-posts';
    }

    public function get_style_depends() {
		return [ 'bloglisting-style' ];
	}

    protected function _register_controls() {

        $this->start_controls_section(
            'content_section',
            [
                'label' => __('Query', 'Zasya-Elementor-Widgets-Kit'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

    
        $this->add_control(
            'order',
            [
                'label' => __('Order', 'Zasya-Elementor-Widgets-Kit'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'asc' => __('Ascending', 'Zasya-Elementor-Widgets-Kit'),
                    'desc' => __('Descending', 'Zasya-Elementor-Widgets-Kit'),
                ],
                'default' => 'desc',
            ]
        );

        $this->add_control(
            'orderby',
            [
                'label' => esc_html__('Order by', 'Zasya-Elementor-Widgets-Kit'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'post_date' => esc_html__('Date', 'Zasya-Elementor-Widgets-Kit'),
                    'post_title' => esc_html__('Title', 'Zasya-Elementor-Widgets-Kit'),
                    'menu_order' => esc_html__('Menu Order', 'Zasya-Elementor-Widgets-Kit'),
                    'modified' => esc_html__('Last Modified', 'Zasya-Elementor-Widgets-Kit'),
                    'comment_count' => esc_html__('Comment Count', 'Zasya-Elementor-Widgets-Kit'),
                    'rand' => esc_html__('Random', 'Zasya-Elementor-Widgets-Kit'),
                ],
                'default' => 'post_date',
            ]
        );

        $this->add_control(
            'posts_per_page',
            [
                'label' => esc_html__('Posts Per Page', 'Zasya-Elementor-Widgets-Kit'),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 100,
                'step' => 1,
                'default' => 5,
            ]
        );

        $this->end_controls_section();
    }


    protected function render() {
        $settings = $this->get_settings_for_display();
        $order = $settings['order'];
        $orderby = $settings['orderby'];
        $posts_per_page = $settings['posts_per_page'];
        $paged = isset($_POST['paged']) ? intval($_POST['paged']) : 1;
        $category = get_query_var('roofing');

        $args = [
            'post_type' => 'post',
            'orderby' => $orderby,
            'order' => $order,
            'posts_per_page' => $posts_per_page,
            'paged'          => 1,
        ];
    
        $project_query = new \WP_Query($args);
        ?>   
            
            <div class="loader" style="display: none;"></div>
         
            <div class="zs_blog_filter_container">
                   <?php  $roofing = get_terms('category'); ?>
                    <a href="#" class="filter active" data-title="">All</a>
                    <?php foreach($roofing as $category){ ?>
                        <a href="#" class="filter" data-title ="<?php echo $category->slug; ?>"><?php echo $category->name; ?></a>
                    <?php } ?>
              </div>
             
          
            <div class="zs_blog_listing zs_blog_listing_gridbox">
                <div class="zs_blog_listing_inner">
                    <div class="zs_blog_listing_grid">
                         <?php while ($project_query->have_posts()) { ?>
                            <?php $project_query->the_post(); ?>
                            <?php $categories = get_the_terms(get_the_ID(), 'category'); ?> 
                            <div class="zs_blog_listing_single">
                                <div class="zs_post_thumbnail_date">
                                    <?php if (has_post_thumbnail()) { ?>
                                    <div class="zs_blog_featured_image">
                                        <a href="<?php echo esc_url(get_permalink()); ?>">
                                        <img src="<?php echo esc_url(get_the_post_thumbnail_url()); ?>" alt="<?php echo esc_attr(get_the_title()); ?>">
                                        </a>
                                    </div>
                                    <?php } else { ?>
                                        <div class="zs_blog_featured_image">
                                            <a href="<?php echo esc_url(get_permalink()); ?>">
                                            <img src="<?php echo site_url(); ?>/wp-content/plugins/zasya-elementor-widgets-kit/assets/images/placeholder.png" alt="<?php echo esc_attr(get_the_title()); ?>">
                                            </a>
                                        </div>
                                    <?php } ?>

                                    <div class="zs_post_date">
                                        <span class="zs_date"><?php echo get_the_date('d M Y'); ?></span>
                                    </div>

                                </div>

                                <div class="zs_blog__info">
                                    <div class="project_category_title">
                                        <?php if (!empty($categories)) { ?>
                                        <?php foreach ($categories as $cat) { ?>
                                            <?php $category_name = esc_html($cat->name); ?>
                                            <div class="zs_blog_category">
                                                <a href="<?php echo esc_url(get_category_link($cat->term_id)); ?>">
                                                    <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M12.1429 1.93777V1.39341C12.1429 0.625078 11.5178 0 10.7495 0H6.87419C6.50196 0 6.15207 0.144949 5.88889 0.40816L0.40816 5.88891C0.144949 6.1521 0 6.50202 0 6.87422C0 7.24642 0.144949 7.59634 0.40816 7.85952L0.96507 8.41643C0.941473 8.51881 0.928977 8.62449 0.928977 8.73212C0.928977 9.10432 1.07393 9.45424 1.33714 9.71742L5.21238 13.5926C5.48401 13.8642 5.84084 14 6.19765 14C6.55446 14 6.9113 13.8642 7.18293 13.5925L12.6637 8.11174C12.9269 7.84853 13.0719 7.49864 13.0719 7.12644V3.25128C13.0719 2.64578 12.6835 2.1295 12.1429 1.93777ZM1.06501 7.20264C0.977293 7.11493 0.928949 6.99828 0.928949 6.87419C0.928949 6.75011 0.977293 6.63351 1.06501 6.54574L6.54577 1.06498C6.63351 0.977293 6.75013 0.928949 6.87422 0.928949H10.7495C11.0056 0.928949 11.2139 1.13731 11.2139 1.39341V1.85787H7.80314C7.43091 1.85787 7.08102 2.00282 6.81784 2.26603L1.47317 7.61075L1.06501 7.20264ZM12.0069 7.45489L6.52608 12.9357C6.34493 13.1168 6.0503 13.1167 5.86923 12.9357L1.99396 9.06052C1.90624 8.9728 1.8579 8.85615 1.8579 8.73206C1.8579 8.60798 1.90624 8.49138 1.99396 8.40361L7.47472 2.92283C7.56246 2.83514 7.67908 2.78679 7.80317 2.78679H11.6784C11.9345 2.78679 12.1429 2.99515 12.1429 3.25125V7.12641C12.1429 7.2505 12.0946 7.36714 12.0069 7.45489Z" fill="#F58220"/>
                                                        <path d="M9.81919 3.7157C9.05086 3.7157 8.42578 4.34078 8.42578 5.10911C8.42578 5.87744 9.05086 6.50252 9.81919 6.50252C10.5875 6.50252 11.2126 5.87744 11.2126 5.10911C11.2126 4.34078 10.5875 3.7157 9.81919 3.7157ZM9.81919 5.5736C9.56309 5.5736 9.35473 5.36524 9.35473 5.10914C9.35473 4.85303 9.56309 4.64467 9.81919 4.64467C10.0753 4.64467 10.2837 4.85303 10.2837 5.10914C10.2837 5.36524 10.0753 5.5736 9.81919 5.5736Z" fill="#F58220"/>
                                                    </svg> 
                                                    <h5><?php echo esc_html($category_name); ?></h5>
                                                </a>
                                            </div>
                                            <?php } ?>

                                        <?php } ?>

                                        <a href="<?php echo esc_url(get_permalink()); ?>">
                                            <div class="zs_blog_title">
                                                <h3><?php echo esc_html(get_the_title()); ?></h3>
                                            </div>
                                        </a>

                                        <div class="zs_blog_excert">
                                            <p><?php echo get_the_excerpt(); ?></p>
                                        </div>

                                        <div class="zs_post_link">
                                            <a href="<?php echo esc_url(get_permalink()); ?>">
                                                <span>Read More</span>
                                                <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <g clip-path="url(#clip0_1425_6830)">
                                                        <path d="M14 10L7.38529 17L6 15.534L11.2295 10L6 4.46598L7.38529 3L14 10Z" fill="#F58220"/>
                                                    </g>

                                                    <defs>
                                                        <clipPath id="clip0_1425_6830">
                                                            <rect width="20" height="20" fill="white" transform="matrix(0 -1 1 0 0 20)"/>
                                                        </clipPath>
                                                    </defs>
                                                </svg>
                                            </a>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                        
                    </div>
                    <span class="pagination-data" data-orderby="<?php echo esc_attr($orderby); ?>" data-order="<?php echo esc_attr($order); ?>" data-page="<?php echo esc_attr($posts_per_page); ?>"></span>
                    <?php wp_reset_postdata(); ?>
                </div>
                <?php if( 1 < $project_query->max_num_pages ) { ?>
                <div class="btn__wrapper">
                    <a href="javascript:void(0);" class="zs_btn zs_btn_primary" id="load-more">
                        <span>Load More</span>
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <g clip-path="url(#clip0_1425_6830)">
                                <path d="M14 10L7.38529 17L6 15.534L11.2295 10L6 4.46598L7.38529 3L14 10Z" fill="#F58220"/>
                            </g>

                            <defs>
                                <clipPath id="clip0_1425_6830">
                                    <rect width="20" height="20" fill="white" transform="matrix(0 -1 1 0 0 20)"/>
                                </clipPath>
                            </defs>
                        </svg>
                    </a>
                </div>
                <?php } ?>
            </div>
            <?php
              
               
               
            ?>
            
        <?php
            }
}
?>
