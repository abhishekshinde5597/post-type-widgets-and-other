<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class product_search extends \Elementor\Widget_Base {

    public function get_name() {
        return 'Element-Product-Search';
    }

    public function get_title() {
        return esc_html__( 'Element-Product-search', 'Zasya-Elementor-Widgets-Kit' );
    }

    public function get_icon() {
        return 'eicon-search';
    }

    public function get_keywords() {
        return [ 'card', 'service', 'highlight', 'essential' ];
    }

    protected function render() {
        ?>
       <div class="ny-home-header-search">
            <div class="header-form-search" bis_skin_checked="1">
            <form role="search" method="get" class="search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
                <label>
                <input type="search" id="search-input" class="search-field" placeholder="Type to Search or Enter CAS no or Product Name" value="" autocomplete="off" name="s" title="Search for:">
                <!-- <input type="hidden" name="post_type" value="product"> -->
                <input type="submit" class="search-submit" value="Search">
                <button id="btnClear"></button>
                </label>
                <div class="form-img-main" bis_skin_checked="1">
                    <p class="img-icon-search">
                    <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 26 26" fill="none">
                        <path d="M26 23.9688C26 25.0888 25.0888 26 23.9687 26C23.4412 26 22.941 25.798 22.5603 25.4314C22.558 25.4292 14.8828 17.7629 14.8774 17.7575C13.3125 18.7658 11.5138 19.2969 9.64844 19.2969C4.32824 19.2969 -9.53674e-07 14.9686 -9.53674e-07 9.64844C-9.53674e-07 4.32829 4.32824 0 9.64844 0C14.9686 0 19.2969 4.32829 19.2969 9.64844C19.2969 11.5127 18.7664 13.3103 17.7574 14.8773C25.9824 23.1119 25.3471 22.4758 25.3811 22.5099C25.7802 22.897 26 23.4149 26 23.9688ZM9.64844 1.01563C4.8883 1.01563 1.01562 4.88831 1.01562 9.64844C1.01562 14.4086 4.8883 18.2813 9.64844 18.2813C14.4382 18.2813 18.2812 14.3886 18.2812 9.64844C18.2812 4.88831 14.4086 1.01563 9.64844 1.01563ZM24.6723 23.2372C24.6701 23.2351 19.3578 17.9228 19.3578 17.9228L17.9228 19.3578L23.2679 24.7028C23.458 24.8844 23.7067 24.9844 23.9687 24.9844C24.5288 24.9844 24.9844 24.5288 24.9844 23.9688C24.9844 23.6913 24.8735 23.4315 24.6723 23.2372Z" fill="#223A66"/>
                    </svg>
                    </p>
                </div>
            </form>
            <div id="suggestions" bis_skin_checked="1"></div>
            </div>
        </div>
        
       
    <script type="text/javascript">
        jQuery(document).ready(function($) {  
            jQuery(".img-icon-search").click(function () {
                jQuery(".search-field").toggleClass("active");
                jQuery(".search-field").parents("form").toggleClass("active_search");
                jQuery(".elementor-location-header input[type='text']").focus();
            }); 
            
            jQuery('#btnClear').click(function(e) {
             e.preventDefault();
            jQuery('form.search-form input[type="search"]').val('');
            jQuery('form.search-form #search-input').val('');
            jQuery('form.search-form #searching').val('');
            jQuery('#suggestions').hide();
            jQuery(".img-icon-search").click();
        });
            // Hide the search input and form when clicking outside
            jQuery(document).on('click', 'body', function(e) {
                // Check if the clicked element is not within the search form or related elements
                if (!jQuery(e.target).closest(".search-field, .img-icon-search, .search-form").length) {
                    jQuery(".search-field").removeClass("active");
                    jQuery(".search-field").parents("form").removeClass("active_search");
                }
            });
          
    });


    </script>
   
   
       
        <?php
    }
    
    
}


