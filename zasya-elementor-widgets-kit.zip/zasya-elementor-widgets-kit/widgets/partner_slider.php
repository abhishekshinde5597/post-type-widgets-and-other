<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class partner_slider extends \Elementor\Widget_Base {

    public function get_name() {
        return 'Element-Partner-Slide';
    }

    public function get_title() {
        return esc_html__( 'Element-Partner-Slide', 'Zasya-Elementor-Widgets-Kit' );
    }

    public function get_style_depends() {
		return [ 'parnterslider-style' ];
	}
    
    public function get_icon() {
        return 'eicon-slider-push';
    }

    public function get_keywords() {
        return [ 'card', 'service', 'highlight', 'essential' ];
    }

    protected function register_controls() {
        $this->start_controls_section(
            'content_section',
            [
                'label' => esc_html__( 'Content Section', 'Zasya-Elementor-Widgets-Kit' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );
    
        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'image',
            [
                'label' => esc_html__( 'Icon', 'Zasya-Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
            ]
        );
    
        $repeater->add_control(
            'slider_title',
            [
                'label' => esc_html__( 'Title', 'Zasya-Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__( 'title' , 'Zasya-Elementor-Widgets-Kit' ),
                'placeholder' => 'Add Your Title Here',
                'label_block' => true,
            ]
        );
    
        $repeater->add_control(
            'slider_content',
            [
                'label' => esc_html__( 'Content', 'Zasya-Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::WYSIWYG,
                'default' => esc_html__( 'Description' , 'Zasya-Elementor-Widgets-Kit' ),
                'placeholder' => 'Add Your Content Here',
                'label_block' => true,
            ]
        );
    
        $repeater->add_control(
            'slider_link',
            [
                'label' => esc_html__( 'Link', 'Zasya-Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::URL,
                'options' => [ 'url', 'is_external', 'nofollow' ],
                'default' => [
                    'url' => '',
                    'is_external' => true,
                    'nofollow' => true,
                ],
                'label_block' => true,
            ]
        );
        
        $repeater->add_control(
            'slider_button',
            [
                'label' => esc_html__( 'Button Text', 'Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__( 'title' , 'Elementor-Widgets-Kit' ),
                'placeholder' => 'title',
                'label_block' => true,
            ]
        );
    
    
        $this->add_control(
            'expertise_list',
            [
                'label' => esc_html__( ' List', 'Zasya-Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'slider_title' => esc_html__( 'Title', 'Zasya-Elementor-Widgets-Kit' ),
                        'slider_content' => esc_html__( 'Description', 'Zasya-Elementor-Widgets-Kit' ),
                    ],
                    [
                        'slider_title' => esc_html__( 'Title',  'Zasya-Elementor-Widgets-Kit' ),
                        'slider_content' => esc_html__( 'Description', 'Zasya-Elementor-Widgets-Kit' ),
                    ],
                ],
                'title_field' => '{{{ slider_title }}}',
            ]
        );
    
        $this->end_controls_section();
    
        // Slider Settings Section
        $this->start_controls_section(
            'slider_settings_section',
            [
                'label' => esc_html__( 'Slider Settings', 'Zasya-Elementor-Widgets-Kit' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );
    
        $this->add_control(
            'slides_to_show',
            [
                'label' => esc_html__( 'Slides to Show', 'Zasya-Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 3,
                'min' => 1,
                'max' => 10,
            ]
        );
    
        $this->add_control(
            'slides_to_scroll',
            [
                'label' => esc_html__( 'Slides to Scroll', 'Zasya-Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 1,
                'min' => 1,
                'max' => 10,
            ]
        );
    
        $this->add_control(
            'autoplay',
            [
                'label' => esc_html__( 'Autoplay', 'Zasya-Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Yes', 'Zasya-Elementor-Widgets-Kit' ),
                'label_off' => esc_html__( 'No', 'Zasya-Elementor-Widgets-Kit' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );
    
        $this->add_control(
            'autoplay_speed',
            [
                'label' => esc_html__( 'Autoplay Speed', 'Zasya-Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 3000,
                'min' => 1000,
                'step' => 500,
                'condition' => [
                    'autoplay' => 'yes',
                ],
            ]
        );
        
    
        $this->add_control(
            'infinite',
            [
                'label' => esc_html__( 'Infinite Loop', 'Zasya-Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Yes', 'Zasya-Elementor-Widgets-Kit' ),
                'label_off' => esc_html__( 'No', 'Zasya-Elementor-Widgets-Kit' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );
    
        $this->add_control(
            'dots',
            [
                'label' => esc_html__( 'Dots Navigation', 'Zasya-Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Yes', 'Zasya-Elementor-Widgets-Kit' ),
                'label_off' => esc_html__( 'No', 'Zasya-Elementor-Widgets-Kit' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );
    
        $this->add_control(
            'arrows',
            [
                'label' => esc_html__( 'Arrows Navigation', 'Zasya-Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Yes', 'Zasya-Elementor-Widgets-Kit' ),
                'label_off' => esc_html__( 'No', 'Zasya-Elementor-Widgets-Kit' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );
    
        $this->add_control(
            'slides_to_show_tablet',
            [
                'label' => esc_html__( 'Slides to Show (Tablet)', 'Zasya-Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 2,
                'min' => 1,
                'max' => 10,
            ]
        );
    
        $this->add_control(
            'slides_to_show_mobile',
            [
                'label' => esc_html__( 'Slides to Show (Mobile)', 'Zasya-Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 1,
                'min' => 1,
                'max' => 10,
            ]
        );
    
        $this->add_control(
            'slides_to_show_upto1440',
            [
                'label' => esc_html__( 'Slides to Show (UP 1441)', 'Zasya-Elementor-Widgets-Kit' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 1,
                'min' => 1,
                'max' => 10,
            ]
        );

        $this->end_controls_section();
    
    }
    
    protected function render() {
        $settings = $this->get_settings_for_display();
        $unique_id = uniqid('slider_'); // Generate a unique ID for each slider instance
        ?>
        <div class="zs-partner-post-slider" id="<?php echo esc_attr($unique_id); ?>">
            <?php foreach($settings['expertise_list'] as $item): ?>
                <div class="zs-partner-item-slide-main">
                    <div class="zs-partner-item-slide">
                        <div class="zs-partner-item">
                            <?php if(!empty($item['image']['url'])): ?>
                                <figure class="zs-partner-thumbnail">
                                    <img src="<?php echo esc_url($item['image']['url']); ?>" class="zs-partner-slider-image" alt="<?php echo esc_attr($item['slider_title']); ?>">
                                </figure>
                            <?php endif; ?>

                            <?php if(!empty($item['slider_title'])): ?>
                                <div class="zs-partner-title"><?php echo esc_html($item['slider_title']); ?></div>
                            <?php endif; ?>
                        </div>

                        <?php if(!empty($item['slider_content'])): ?>
                        <div class="zs-partner-content-wrapper" data-mcs-theme="minimal-dark">
                                <div class="zs-partner-content"><?php echo $item['slider_content']; ?></div>
                        </div>
                        <?php endif; ?>

                        <?php if(!empty($item['slider_link']['url'] && $item['slider_button'] )): ?>
                            <div class="zs-partner-post-link">
                                <a href="<?php echo esc_url($item['slider_link']['url']); ?>" class="zs-partner-link">
                                    <?php echo esc_html($item['slider_button']); ?>
                                    <span class="zs_img_arrow">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="8" height="14" viewBox="0 0 8 14" fill="none">
                                            <path d="M8 7L1.38529 14L-4.76837e-07 12.534L5.22945 7L-4.76837e-07 1.46598L1.38529 -1.19209e-07L8 7Z" fill="#F58220"/>
                                    </svg>
                                    </span>
                                </a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
             <?php endforeach; ?>
        </div>
        
       

    <script type="text/javascript">
        jQuery(document).ready(function($) {  
            var sliderId = '<?php echo esc_js($unique_id); ?>';
            var sliderWrapper = jQuery('#' + sliderId).closest('.zs-partner-item-slide');
            jQuery('#' + sliderId).slick({
                slidesToShow: <?php echo $settings['slides_to_show']; ?>,
                rtl: false,
                centerMode: true,
                centerPadding: '272px',
                slidesToScroll: <?php echo $settings['slides_to_scroll']; ?>,
                autoplay:'<?php echo $settings['autoplay'] === 'yes' ? 'true' : 'false'; ?>',
                autoplaySpeed: <?php echo $settings['autoplay_speed'] === 'yes' ? 'true' : 'false';  ?>,
                infinite: <?php echo $settings['infinite'] === 'yes' ? 'true' : 'false'; ?>,
                dots: <?php echo $settings['dots'] === 'yes' ? 'true' : 'false'; ?>,
                arrows: <?php echo $settings['arrows'] === 'yes' ? 'true' : 'false'; ?>,
                prevArrow: '<img class="nosexpertise-arrow-left" src="/wp-content/plugins/Zasya-Elementor-Widgets-Kit/assets/images/Group 208.svg">',
                nextArrow: '<img class="nosexpertise-arrow-right" src="/wp-content/plugins/Zasya-Elementor-Widgets-Kit/assets/images/Group 207.svg">',
                
                
                responsive: [
                    {
                        breakpoint: 1600,
                        settings: {
                            slidesToShow: <?php echo $settings['slides_to_show_upto1440']; ?>,
                            slidesToScroll: 1,
                            dots: true,
                        }
                    },
                    {
                        breakpoint: 1024,
                        settings: {
                            slidesToShow: <?php echo $settings['slides_to_show_tablet']; ?>,
                            slidesToScroll: 1,
                            dots: true,
                            centerPadding : '20%'
                        }
                    },
                    
                    {
                        breakpoint: 768,
                        settings: {
                            slidesToShow: <?php echo $settings['slides_to_show_mobile']; ?>,
                            slidesToScroll: 1,
                            centerMode: false,
                            centerPadding : '20%'
                        }
                    }
                ]
            });

        
            function updateSlideClasses(slider) {
        // Remove all custom classes
                slider.find('.slick-slide').removeClass('prev next current');

                // Add classes to currently visible slides
                slider.find('.slick-active').each(function () {
                    jQuery(this).addClass('current'); // Active slide
                    jQuery(this).prev().addClass('prev'); // Previous slide
                    jQuery(this).next().addClass('next'); // Next slide
                });
            }

            // Bind to the `init` event
            jQuery('#' + sliderId).on('init', function (event, slick) {
                var slider = jQuery(slick.$slider);
                updateSlideClasses(slider);

                // Fallback for the first slide
                if (!slider.find('.slick-active').hasClass('current')) {
                    slider.find('.slick-slide').first().addClass('current');
                    slider.find('.slick-slide').first().next().addClass('next');
                    slider.find('.slick-slide').last().addClass('prev'); // For infinite loop
                }
            });

            // Trigger class updates after each slide change
            jQuery('#' + sliderId).on('afterChange', function (event, slick) {
                var slider = jQuery(slick.$slider);
                updateSlideClasses(slider);
            });

            // Manually trigger `init` if it’s not working
            jQuery('#' + sliderId).slick('setPosition'); // Ensure rendering
            var sliderElement = jQuery('#' + sliderId);
            updateSlideClasses(sliderElement);
    });
    </script>
   
       
        <?php
    }
    
    
}


