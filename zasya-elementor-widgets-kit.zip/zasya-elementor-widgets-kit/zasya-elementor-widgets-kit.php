<?php

/**
 * Plugin Name: Zasya-Elementor-Widgets-Kit
 * Description: Widgets
 * Version:     1.0.0
 * Author:      Zasya-Elementor-Widgets-Kit
 * Author URI:  
 * Text Domain: Zasya-Elementor-Widgets-Kit
 */


 function aquaprox_widgets($widgets_manager)
{

    require_once( __DIR__ . '/widgets/partner_slider.php' );  
    $widgets_manager->register( new \partner_slider() );

    require_once( __DIR__ . '/widgets/bloglisting.php' );  
    $widgets_manager->register( new \bloglisting() );

    require_once( __DIR__ . '/widgets/featuedblogs.php' );  
    $widgets_manager->register( new \featuedblogs() );
    
    require_once( __DIR__ . '/widgets/product_search.php' );  
    $widgets_manager->register( new \product_search() );

    require_once( __DIR__ . '/widgets/expertise.php' );  
    $widgets_manager->register( new \expertise() );

    require_once( __DIR__ . '/widgets/client_testimonial.php' );  
    $widgets_manager->register( new \client_testimonial() );

    require_once( __DIR__ . '/widgets/latest_resources.php' );  
    $widgets_manager->register( new \latest_resources() );

}
add_action('elementor/widgets/register', 'aquaprox_widgets');

function register_widget_styles() {
	wp_register_style( 'parnterslider-style', plugins_url( 'assets/css/parnterslider-style.css', __FILE__ ) );
    wp_register_style( 'bloglisting-style', plugins_url( 'assets/css/bloglisting-style.css', __FILE__ ) );
    wp_register_style( 'featuredblogs-style', plugins_url( 'assets/css/featuredblogs-style.css', __FILE__ ) );
    wp_register_style( 'Expertise-style', plugins_url( 'assets/css/Expertise-style.css', __FILE__ ) );
    wp_register_style( 'clicenttestimonialslider-style', plugins_url( 'assets/css/clicenttestimonialslider-style.css', __FILE__ ) );
}
add_action( 'wp_enqueue_scripts', 'register_widget_styles' );



function plugin_script(){ 
    ?>
    <script>
    jQuery(document).ready(function($) {
        var currntpage = 1; // Define globally to maintain state
       
        // Ajax filter click event
        jQuery(document).on('click', 'a.filter', function(e){
            e.preventDefault();
           
            // Reset page to 1 and update UI
            currntpage = 1;
            jQuery('.filter.active').removeClass('active');
            jQuery(this).addClass('active');

            // Get filter parameters
            var catgoryval = jQuery('a.filter.active').data('title');
            var orderby = jQuery('.pagination-data').data('orderby');
            var post_per_pages = jQuery('.pagination-data').data('page');
            var order = jQuery('.pagination-data').data('order');
          
            // Call AJAX
            blog_listing_ajax(catgoryval, currntpage, orderby, post_per_pages, order);
        });

        // Blog listing AJAX function
        function blog_listing_ajax(catgoryval, currntpage, orderby, post_per_pages, order) {
            jQuery('.loader').show();
            jQuery.ajax({
                url: '<?php echo admin_url('admin-ajax.php'); ?>',
                type: 'POST',
                dataType: 'json',
                data: {
                    action: 'blog_listing_ajax',
                    catgoryval: catgoryval,
                    page: currntpage,
                    orderby: orderby,
                    post_per_page: post_per_pages,
                    order: order
                },
                success: function(response) {
                    // console.log(currntpage + ' currentpage');
                    // console.log(response.max + ' responsemax');

                    // Hide "Load More" if on the last page
                    if (currntpage >= response.max) {
                        jQuery('#load-more').hide();
                    } else {
                        jQuery('#load-more').show(); 
                    }

                    // Replace content for the first page; append for others
                        jQuery('.zs_blog_listing_inner').html(response.html);
               
                    jQuery('.loader').hide();
                },
                error: function(xhr, status, error) {
                    console.log(xhr.responseText); // Log error response
                }
            });
        }
        function loadmore_ajax(catgoryval, currntpage, orderby, post_per_pages, order) {
            jQuery('.loader').show();
            jQuery.ajax({
                url: '<?php echo admin_url('admin-ajax.php'); ?>',
                type: 'POST',
                dataType: 'json',
                data: {
                    action: 'loadmore_ajax',
                    catgoryval: catgoryval,
                    page: currntpage,
                    orderby: orderby,
                    post_per_page: post_per_pages,
                    order: order
                },
                success: function(response) {
                    // console.log(currntpage + ' currentpage');
                    // console.log(response.max + ' responsemax');

                    // Hide "Load More" if on the last page
                    if (currntpage >= response.max) {
                        jQuery('#load-more').hide();
                    } else {
                        jQuery('#load-more').show(); 
                    }

                    // Replace content for the first page; append for others
                     jQuery('.zs_blog_listing_grid').append(response.html); 
                  
                    jQuery('.loader').hide();
                },
                error: function(xhr, status, error) {
                    console.log(xhr.responseText); // Log error response
                }
            });
        }

        // Load more click event
        jQuery('#load-more').on('click', function() {
            currntpage++; // Increment global page counter

            // Get current filter parameters
            var catgoryval = jQuery('a.filter.active').data('title');
            var orderby = jQuery('.pagination-data').data('orderby');
            var post_per_pages = jQuery('.pagination-data').data('page');
            var order = jQuery('.pagination-data').data('order');

            // Call AJAX for next page
            loadmore_ajax(catgoryval, currntpage, orderby, post_per_pages, order);
        });
    });
    </script>
    <?php 
}
add_action('wp_footer', 'plugin_script');


//*ajax ajax action for project listing */ */
add_action('wp_ajax_blog_listing_ajax','blog_listing_ajax');
add_action('wp_ajax_nopriv_blog_listing_ajax','blog_listing_ajax');

function blog_listing_ajax(){

  
    $currentPage = !empty($_POST['page']) ? $_POST['page'] : 1;
    $orderby = !empty($_POST['orderby']) ? $_POST['orderby'] : '';
    $post_per_pages = !empty($_POST['post_per_page']) ? $_POST['post_per_page'] : '';
    $order = !empty($_POST['order']) ? $_POST['order'] : '';
    $category = !empty($_POST['catgoryval']) ? $_POST['catgoryval'] : '';
    
    $args = [
        'post_type' => 'post',
        'orderby' => $orderby,
        'order' => $order,
        'posts_per_page' => $post_per_pages,
        'paged'  => $currentPage,

    ];

    if ($category ) {
        $args['tax_query'] = array(
          array(
            'taxonomy' => 'category',
            'field' => 'slug',
            'terms' => $category,
          ),
        );
      }

    $project_query = new \WP_Query($args);
    $max_pages = $project_query->max_num_pages;

         ?>
        <?php ob_start(); 
        if($project_query->have_posts()) {
        ?>
        <div class="zs_blog_listing_grid">
            <?php while ($project_query->have_posts()) { ?>
                <?php $project_query->the_post(); ?>
                <?php $categories = get_the_terms(get_the_ID(), 'category'); ?> 
                <div class="zs_blog_listing_single">
                    <div class="zs_post_thumbnail_date">
                        <?php if (has_post_thumbnail()) { ?>
                        <div class="zs_blog_featured_image">
                            <a href="<?php echo esc_url(get_permalink()); ?>">
                            <img src="<?php echo esc_url(get_the_post_thumbnail_url()); ?>" alt="<?php echo esc_attr(get_the_title()); ?>">
                            </a>
                        </div>
                        <?php } else { ?>
                            <div class="zs_blog_featured_image">
                                <a href="<?php echo esc_url(get_permalink()); ?>">
                                <img src="<?php echo site_url(); ?>/wp-content/plugins/zasya-elementor-widgets-kit/assets/images/placeholder.png" alt="<?php echo esc_attr(get_the_title()); ?>">
                                </a>
                            </div>
                        <?php } ?>

                        <div class="zs_post_date">
                            <span class="zs_date"><?php echo get_the_date('d M Y'); ?></span>
                        </div>

                    </div>

                    <div class="zs_blog__info">
                        <div class="project_category_title">
                            <?php if (!empty($categories)) { ?>
                            <?php foreach ($categories as $cat) { ?>
                                <?php $category_name = esc_html($cat->name); ?>
                                <div class="zs_blog_category">
                                <a href="<?php echo esc_url(get_category_link($cat->term_id)); ?>"><svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M12.1429 1.93777V1.39341C12.1429 0.625078 11.5178 0 10.7495 0H6.87419C6.50196 0 6.15207 0.144949 5.88889 0.40816L0.40816 5.88891C0.144949 6.1521 0 6.50202 0 6.87422C0 7.24642 0.144949 7.59634 0.40816 7.85952L0.96507 8.41643C0.941473 8.51881 0.928977 8.62449 0.928977 8.73212C0.928977 9.10432 1.07393 9.45424 1.33714 9.71742L5.21238 13.5926C5.48401 13.8642 5.84084 14 6.19765 14C6.55446 14 6.9113 13.8642 7.18293 13.5925L12.6637 8.11174C12.9269 7.84853 13.0719 7.49864 13.0719 7.12644V3.25128C13.0719 2.64578 12.6835 2.1295 12.1429 1.93777ZM1.06501 7.20264C0.977293 7.11493 0.928949 6.99828 0.928949 6.87419C0.928949 6.75011 0.977293 6.63351 1.06501 6.54574L6.54577 1.06498C6.63351 0.977293 6.75013 0.928949 6.87422 0.928949H10.7495C11.0056 0.928949 11.2139 1.13731 11.2139 1.39341V1.85787H7.80314C7.43091 1.85787 7.08102 2.00282 6.81784 2.26603L1.47317 7.61075L1.06501 7.20264ZM12.0069 7.45489L6.52608 12.9357C6.34493 13.1168 6.0503 13.1167 5.86923 12.9357L1.99396 9.06052C1.90624 8.9728 1.8579 8.85615 1.8579 8.73206C1.8579 8.60798 1.90624 8.49138 1.99396 8.40361L7.47472 2.92283C7.56246 2.83514 7.67908 2.78679 7.80317 2.78679H11.6784C11.9345 2.78679 12.1429 2.99515 12.1429 3.25125V7.12641C12.1429 7.2505 12.0946 7.36714 12.0069 7.45489Z" fill="#F58220"></path>
                                                        <path d="M9.81919 3.7157C9.05086 3.7157 8.42578 4.34078 8.42578 5.10911C8.42578 5.87744 9.05086 6.50252 9.81919 6.50252C10.5875 6.50252 11.2126 5.87744 11.2126 5.10911C11.2126 4.34078 10.5875 3.7157 9.81919 3.7157ZM9.81919 5.5736C9.56309 5.5736 9.35473 5.36524 9.35473 5.10914C9.35473 4.85303 9.56309 4.64467 9.81919 4.64467C10.0753 4.64467 10.2837 4.85303 10.2837 5.10914C10.2837 5.36524 10.0753 5.5736 9.81919 5.5736Z" fill="#F58220"></path>
                                                    </svg><h5><?php echo esc_html($category_name); ?></h5></a>
                                </div>
                                <?php } ?>

                            <?php } ?>

                            <a href="<?php echo esc_url(get_permalink()); ?>">
                                <div class="zs_blog_title">
                                    <h3><?php echo esc_html(get_the_title()); ?></h3>
                                </div>
                            </a>

                            <div class="zs_blog_excert">
                                <p><?php echo get_the_excerpt(); ?></p>
                            </div>

                            <div class="zs_post_link">
                                <a href="<?php echo esc_url(get_permalink()); ?>"><span>Read More</span><svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <g clip-path="url(#clip0_1425_6830)">
                                                        <path d="M14 10L7.38529 17L6 15.534L11.2295 10L6 4.46598L7.38529 3L14 10Z" fill="#F58220"></path>
                                                    </g>

                                                    <defs>
                                                        <clipPath id="clip0_1425_6830">
                                                            <rect width="20" height="20" fill="white" transform="matrix(0 -1 1 0 0 20)"></rect>
                                                        </clipPath>
                                                    </defs>
                                                </svg></a>
                            </div>

                        </div>
                    </div>
                </div>
            <?php } ?>
        <?php wp_reset_postdata(); ?>
        </div>
        <span class="pagination-data" data-orderby="<?php echo esc_attr($orderby); ?>" data-order="<?php echo esc_attr($order); ?>" data-page="<?php echo esc_attr($post_per_pages); ?>"></span>

        <?php
        $output = ob_get_contents();
        ob_end_clean();
        } else {
        $response = '';
        }

        $result = [
        'max' => $max_pages,
        'html' => $output,
        ];

        echo json_encode($result);
        exit;
   
}
add_action('wp_ajax_loadmore_ajax','loadmore_ajax');
add_action('wp_ajax_nopriv_loadmore_ajax','loadmore_ajax');

function loadmore_ajax(){

  
    $currentPage = !empty($_POST['page']) ? $_POST['page'] : 1;
    $orderby = !empty($_POST['orderby']) ? $_POST['orderby'] : '';
    $post_per_pages = !empty($_POST['post_per_page']) ? $_POST['post_per_page'] : '';
    $order = !empty($_POST['order']) ? $_POST['order'] : '';
    $category = !empty($_POST['catgoryval']) ? $_POST['catgoryval'] : '';
    
    $args = [
        'post_type' => 'post',
        'orderby' => $orderby,
        'order' => $order,
        'posts_per_page' => $post_per_pages,
        'paged'  => $currentPage,

    ];

    if ($category ) {
        $args['tax_query'] = array(
          array(
            'taxonomy' => 'category',
            'field' => 'slug',
            'terms' => $category,
          ),
        );
      }

    $project_query = new \WP_Query($args);
    $max_pages = $project_query->max_num_pages;

         ?>
        <?php ob_start(); 
        if($project_query->have_posts()) {
        ?>
            <?php while ($project_query->have_posts()) { ?>
                <?php $project_query->the_post(); ?>
                <?php $categories = get_the_terms(get_the_ID(), 'category'); ?> 
                <div class="zs_blog_listing_single">
                    <div class="zs_post_thumbnail_date">
                        <?php if (has_post_thumbnail()) { ?>
                        <div class="zs_blog_featured_image">
                            <a href="<?php echo esc_url(get_permalink()); ?>">
                            <img src="<?php echo esc_url(get_the_post_thumbnail_url()); ?>" alt="<?php echo esc_attr(get_the_title()); ?>">
                            </a>
                        </div>
                        <?php } else { ?>
                            <div class="zs_blog_featured_image">
                                <a href="<?php echo esc_url(get_permalink()); ?>">
                                <img src="<?php echo site_url(); ?>/wp-content/plugins/zasya-elementor-widgets-kit/assets/images/placeholder.png" alt="<?php echo esc_attr(get_the_title()); ?>">
                                </a>
                            </div>
                        <?php } ?>

                        <div class="zs_post_date">
                            <span class="zs_date"><?php echo get_the_date('d M Y'); ?></span>
                        </div>

                    </div>

                    <div class="zs_blog__info">
                        <div class="project_category_title">
                            <?php if (!empty($categories)) { ?>
                            <?php foreach ($categories as $cat) { ?>
                                <?php $category_name = esc_html($cat->name); ?>
                                <div class="zs_blog_category">
                                <a href="<?php echo esc_url(get_category_link($cat->term_id)); ?>"><svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M12.1429 1.93777V1.39341C12.1429 0.625078 11.5178 0 10.7495 0H6.87419C6.50196 0 6.15207 0.144949 5.88889 0.40816L0.40816 5.88891C0.144949 6.1521 0 6.50202 0 6.87422C0 7.24642 0.144949 7.59634 0.40816 7.85952L0.96507 8.41643C0.941473 8.51881 0.928977 8.62449 0.928977 8.73212C0.928977 9.10432 1.07393 9.45424 1.33714 9.71742L5.21238 13.5926C5.48401 13.8642 5.84084 14 6.19765 14C6.55446 14 6.9113 13.8642 7.18293 13.5925L12.6637 8.11174C12.9269 7.84853 13.0719 7.49864 13.0719 7.12644V3.25128C13.0719 2.64578 12.6835 2.1295 12.1429 1.93777ZM1.06501 7.20264C0.977293 7.11493 0.928949 6.99828 0.928949 6.87419C0.928949 6.75011 0.977293 6.63351 1.06501 6.54574L6.54577 1.06498C6.63351 0.977293 6.75013 0.928949 6.87422 0.928949H10.7495C11.0056 0.928949 11.2139 1.13731 11.2139 1.39341V1.85787H7.80314C7.43091 1.85787 7.08102 2.00282 6.81784 2.26603L1.47317 7.61075L1.06501 7.20264ZM12.0069 7.45489L6.52608 12.9357C6.34493 13.1168 6.0503 13.1167 5.86923 12.9357L1.99396 9.06052C1.90624 8.9728 1.8579 8.85615 1.8579 8.73206C1.8579 8.60798 1.90624 8.49138 1.99396 8.40361L7.47472 2.92283C7.56246 2.83514 7.67908 2.78679 7.80317 2.78679H11.6784C11.9345 2.78679 12.1429 2.99515 12.1429 3.25125V7.12641C12.1429 7.2505 12.0946 7.36714 12.0069 7.45489Z" fill="#F58220"></path>
                                                        <path d="M9.81919 3.7157C9.05086 3.7157 8.42578 4.34078 8.42578 5.10911C8.42578 5.87744 9.05086 6.50252 9.81919 6.50252C10.5875 6.50252 11.2126 5.87744 11.2126 5.10911C11.2126 4.34078 10.5875 3.7157 9.81919 3.7157ZM9.81919 5.5736C9.56309 5.5736 9.35473 5.36524 9.35473 5.10914C9.35473 4.85303 9.56309 4.64467 9.81919 4.64467C10.0753 4.64467 10.2837 4.85303 10.2837 5.10914C10.2837 5.36524 10.0753 5.5736 9.81919 5.5736Z" fill="#F58220"></path>
                                                    </svg><h5><?php echo esc_html($category_name); ?></h5></a>
                                </div>
                                <?php } ?>

                            <?php } ?>

                            <a href="<?php echo esc_url(get_permalink()); ?>">
                                <div class="zs_blog_title">
                                    <h3><?php echo esc_html(get_the_title()); ?></h3>
                                </div>
                            </a>

                            <div class="zs_blog_excert">
                                <p><?php echo get_the_excerpt(); ?></p>
                            </div>

                            <div class="zs_post_link">
                                <a href="<?php echo esc_url(get_permalink()); ?>"><span>Read More</span>
                                <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <g clip-path="url(#clip0_1425_6830)">
                                                        <path d="M14 10L7.38529 17L6 15.534L11.2295 10L6 4.46598L7.38529 3L14 10Z" fill="#F58220"></path>
                                                    </g>

                                                    <defs>
                                                        <clipPath id="clip0_1425_6830">
                                                            <rect width="20" height="20" fill="white" transform="matrix(0 -1 1 0 0 20)"></rect>
                                                        </clipPath>
                                                    </defs>
                                                </svg>
                                            </a>
                            </div>

                        </div>
                    </div>
                </div>
            <?php } ?>
        <?php wp_reset_postdata(); ?>
        <span class="pagination-data" data-orderby="<?php echo esc_attr($orderby); ?>" data-order="<?php echo esc_attr($order); ?>" data-page="<?php echo esc_attr($post_per_pages); ?>"></span>

        <?php
        $output = ob_get_contents();
        ob_end_clean();
        } else {
        $response = '';
        }

        $result = [
        'max' => $max_pages,
        'html' => $output,
        ];

        echo json_encode($result);
        exit;
   
}

